import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { FileText, Download, ShieldCheck, DownloadCloud } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

interface PageProps {
    params: {
        slug: string;
    };
    searchParams: {
        docs?: string;
    }
}

export default async function PublicDossierPage({ params, searchParams }: PageProps) {
    const slug = params.slug;
    const docIdsStr = searchParams.docs;

    if (!docIdsStr) {
        return notFound();
    }

    const docIds = docIdsStr.split(',').filter(Boolean);

    if (docIds.length === 0) {
        return notFound();
    }

    // 1. Validate Band
    const band = await prisma.band.findUnique({
        where: { slug }
    });

    if (!band) {
        return notFound();
    }

    // 2. Load requested Documents
    const documents = await prisma.document.findMany({
        where: {
            id: { in: docIds },
            bandId: band.id // Ensures documents actually belong to this band
        },
        orderBy: {
            category: 'asc' // Groups CNDs, CONTRATOS, etc together
        }
    });

    if (documents.length === 0) {
        return notFound();
    }

    return (
        <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 font-sans text-zinc-900 dark:text-zinc-100 selection:bg-secondary/30">
            {/* Header */}
            <header className="border-b border-zinc-200 dark:border-zinc-800 bg-white/50 dark:bg-zinc-900/50 backdrop-blur-md sticky top-0 z-10 px-6 py-4">
                <div className="max-w-4xl mx-auto flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        {band.imageUrl ? (
                            <img src={band.imageUrl} alt={band.name} className="h-10 w-auto rounded-md object-contain" />
                        ) : (
                            <div className="h-10 w-10 flex items-center justify-center bg-secondary text-white font-black text-xl rounded-md">
                                {band.name.charAt(0)}
                            </div>
                        )}
                        <div>
                            <h1 className="font-bold text-lg">{band.name}</h1>
                            <p className="text-xs text-zinc-500">Dossiê de Licitação / Inexigibilidade</p>
                        </div>
                    </div>
                    <div className="hidden sm:flex items-center gap-2 text-xs font-medium text-emerald-600 dark:text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                        <ShieldCheck className="w-4 h-4" />
                        Acesso Verificado
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <main className="max-w-4xl mx-auto px-6 py-12 space-y-8">
                <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-8 shadow-sm text-center">
                    <FileText className="w-12 h-12 text-secondary mx-auto mb-4" />
                    <h2 className="text-2xl font-bold mb-2">Documentação Eletrônica</h2>
                    <p className="text-zinc-500 max-w-lg mx-auto">
                        Este link contém <strong>{documents.length} documentos</strong> disponibilizados pela produção de {band.name}.
                        Os arquivos abaixo são apresentados para fins de habilitação, inexigibilidade ou contratação.
                    </p>
                </div>

                <div className="space-y-4">
                    <h3 className="font-semibold text-lg border-b border-zinc-200 dark:border-zinc-800 pb-2">Arquivos Disponíveis</h3>

                    <div className="grid gap-4">
                        {documents.map(doc => {
                            const isExpired = doc.expiryDate && new Date(doc.expiryDate) < new Date();

                            return (
                                <div key={doc.id} className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all hover:border-zinc-300 dark:hover:border-zinc-700 hover:shadow-sm">
                                    <div className="flex items-start sm:items-center gap-4">
                                        <div className="w-10 h-10 rounded-lg bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center shrink-0">
                                            <FileText className="w-5 h-5 text-zinc-500" />
                                        </div>
                                        <div>
                                            <h4 className="font-bold">{doc.title}</h4>
                                            <div className="flex items-center gap-2 mt-1 text-xs font-medium">
                                                <span className="text-zinc-500 uppercase tracking-wider">{doc.category}</span>
                                                {doc.expiryDate && (
                                                    <>
                                                        <span className="text-zinc-300 dark:text-zinc-700">•</span>
                                                        <span className={isExpired ? "text-red-500" : "text-zinc-500"}>
                                                            {isExpired ? "Vencido em:" : "Válido até:"} {new Date(doc.expiryDate).toLocaleDateString('pt-BR')}
                                                        </span>
                                                    </>
                                                )}
                                            </div>
                                        </div>
                                    </div>

                                    <a
                                        href={doc.fileUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex items-center justify-center gap-2 bg-secondary text-white font-semibold text-sm px-4 py-2 rounded-lg hover:opacity-90 transition-opacity shrink-0"
                                    >
                                        <DownloadCloud className="w-4 h-4" />
                                        Visualizar / Baixar PDF
                                    </a>
                                </div>
                            );
                        })}
                    </div>
                </div>

                <div className="text-center pt-8 border-t border-zinc-200 dark:border-zinc-800">
                    <p className="text-xs text-zinc-400">
                        Documentos gerados via <a href="#" className="hover:text-zinc-600 transition-colors">BAND FLOW</a>.
                    </p>
                </div>
            </main>
        </div>
    );
}
