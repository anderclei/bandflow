"use server"; // touch to reload

import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";

export async function createBand(formData: FormData) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    const user = await prisma.user.findUnique({
        where: { id: session.user.id },
        include: {
            memberships: {
                where: { role: "ADMIN" }
            }
        }
    });

    if (!user) throw new Error("User not found");

    if (user.licenseStatus === "BLOCKED") {
        throw new Error("Sua licença está bloqueada. Entre em contato com o suporte.");
    }

    if (user.memberships.length >= user.maxBands) {
        throw new Error(`Limite de bandas atingido. Seu plano permite ${user.maxBands} banda(s).`);
    }

    const name = formData.get("name") as string;
    const description = formData.get("description") as string;
    const slug = name.toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^\w\s-]/g, "")
        .replace(/\s+/g, "-")
        .trim() + "-" + Math.random().toString(36).substring(2, 6);

    const band = await prisma.band.create({
        data: {
            name,
            description,
            slug,
            members: {
                create: {
                    userId: session.user.id,
                    role: "ADMIN",
                },
            },
        },
    });

    const cookieStore = await cookies();
    cookieStore.set("activeBandId", band.id);

    revalidatePath("/dashboard");
    redirect("/dashboard");
}

export async function switchBand(bandId: string) {
    const cookieStore = await cookies();
    cookieStore.set("activeBandId", bandId);
    revalidatePath("/dashboard");
}

export async function updateBand(formData: FormData) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    const cookieStore = await cookies();
    const activeBandId = cookieStore.get("activeBandId")?.value;

    if (!activeBandId) throw new Error("No active band selected");

    const membership = await prisma.member.findUnique({
        where: {
            userId_bandId: {
                userId: session.user.id,
                bandId: activeBandId,
            }
        }
    });

    // @ts-ignore - Super Admin pode editar qualquer banda via impersonação
    const isSuperAdmin = session.user.isSuperAdmin === true || (session.user as any).isSuperAdmin === 1;

    if (!isSuperAdmin && (!membership || membership.role !== "ADMIN")) {
        throw new Error("Only administrators can update band settings");
    }

    const name = formData.get("name") as string;
    const secondaryColor = formData.get("secondaryColor") as string;
    const imageUrl = formData.get("imageUrl") as string;

    // Novos campos
    const respName = formData.get("respName") as string;
    const respDocument = formData.get("respDocument") as string;
    const addressStreet = formData.get("addressStreet") as string;
    const addressNumber = formData.get("addressNumber") as string;
    const addressNeighborhood = formData.get("addressNeighborhood") as string;
    const addressZipCode = formData.get("addressZipCode") as string;
    const addressCity = formData.get("addressCity") as string;
    const addressState = formData.get("addressState") as string;

    // Usar SQL raw pois o cliente Prisma gerado não está sincronizado com o banco real
    // O banco tem: respName, addressStreet, etc. 
    // O cliente Prisma conhece: respAddress, city, etc. (schema diferente)
    const setClauses: string[] = [];
    const params: any[] = [];

    const addField = (col: string, val: string | null) => {
        if (val !== null && val !== undefined && val !== '') {
            setClauses.push(`${col} = ?`);
            params.push(val);
        }
    };

    addField('name', name);
    addField('secondaryColor', secondaryColor);
    addField('respName', respName);
    addField('respDocument', respDocument);
    addField('addressStreet', addressStreet);
    addField('addressNumber', addressNumber);
    addField('addressNeighborhood', addressNeighborhood);
    addField('addressZipCode', addressZipCode);
    addField('addressCity', addressCity);
    addField('addressState', addressState);
    if (imageUrl) addField('imageUrl', imageUrl);

    // name é obrigatório — garantir que sempre está presente
    if (!setClauses.some(c => c.startsWith('name'))) {
        setClauses.push('name = ?');
        params.push(name);
    }

    params.push(activeBandId);
    await prisma.$executeRawUnsafe(
        `UPDATE Band SET ${setClauses.join(', ')}, updatedAt = datetime('now') WHERE id = ?`,
        ...params
    );







    revalidatePath("/dashboard/settings");
    revalidatePath("/super-admin/tenants"); // Sincronização bidirecional
    revalidatePath(`/band/[slug]`, 'page');
}

export async function updateEpkData(bandId: string, data: { shortBio?: string, videoUrl?: string, socialLinks?: string }) {
    await prisma.band.update({
        where: { id: bandId },
        // @ts-ignore
        data
    });
    revalidatePath(`/dashboard/epk`);
    const band = await prisma.band.findUnique({ where: { id: bandId }, select: { slug: true } });
    if (band?.slug) revalidatePath(`/epk/${band.slug}`);
}
