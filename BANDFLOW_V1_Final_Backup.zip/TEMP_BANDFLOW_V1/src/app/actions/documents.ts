"use server";

import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { revalidatePath } from "next/cache";

export async function createDocument(bandId: string, fileUrl: string, formData: FormData) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    const title = formData.get("title") as string;
    const category = formData.get("category") as string;
    const expiryDateStr = formData.get("expiryDate") as string;
    const memberId = formData.get("memberId") as string;

    if (!title || !category || !fileUrl) {
        throw new Error("Missing required fields");
    }

    await prisma.document.create({
        data: {
            title,
            category,
            fileUrl,
            bandId,
            expiryDate: expiryDateStr ? new Date(expiryDateStr) : null,
            memberId: memberId || null,
        }
    });

    revalidatePath("/dashboard/documents");
    return { success: true };
}

export async function deleteDocument(documentId: string) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    await prisma.document.delete({
        where: { id: documentId }
    });

    revalidatePath("/dashboard/documents");
}
