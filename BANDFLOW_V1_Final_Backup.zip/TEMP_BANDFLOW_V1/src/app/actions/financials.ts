"use server";


import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";
import { getDistanceBetweenCities } from "@/lib/distance";


// --- GIG EXPENSES ---

export async function updateGigExpenses(gigId: string, expenses: { description: string, amount: number, category: string, id?: string }[]) {
    try {
        // Simple strategy: Delete all current expenses and recreate or sync
        // For now, let's use a more robust sync or just handle individuals

        // Let's delete existing and recreate for simplicity in this V1
        await (prisma as any).gigExpense.deleteMany({
            where: { gigId }
        });


        if (expenses.length > 0) {
            await (prisma as any).gigExpense.createMany({
                data: expenses.map(e => ({

                    description: e.description,
                    amount: e.amount,
                    category: e.category,
                    gigId: gigId
                }))
            });
        }

        revalidatePath(`/dashboard/gigs/${gigId}`);
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function calculateFreight(gigId: string, supplierId: string) {
    try {
        const gig = await prisma.gig.findUnique({
            where: { id: gigId },
            include: { band: true }
        });

        const supplier = await (prisma as any).logisticsSupplier.findUnique({
            where: { id: supplierId }
        });


        if (!gig || !supplier) {
            return { success: false, error: "Gig ou Fornecedor não encontrado." };
        }

        const bandCity = (gig.band as any).addressCity;
        const gigLocation = gig.location;

        if (!bandCity || !gigLocation) {
            return { success: false, error: "Cidade da banda ou local do show não definidos." };
        }

        // 1. Calculate distance
        const distanceKm = await getDistanceBetweenCities(bandCity, gigLocation);

        if (distanceKm === null) {
            return { success: false, error: "Não foi possível calcular a distância. Verifique as cidades ou a chave de API." };
        }

        // 2. Calculate amount (KM * Rate)
        const amount = distanceKm * supplier.kmValue;

        // 3. Create or update expense
        // Check if there's already a freight expense for this gig
        const existingFreight = await (prisma as any).gigExpense.findFirst({
            where: {
                gigId,
                description: { contains: "Frete" }
            }
        });

        if (existingFreight) {
            await (prisma as any).gigExpense.update({
                where: { id: existingFreight.id },
                data: {
                    amount,
                    description: `Frete: ${supplier.name} (${distanceKm.toFixed(0)}km)`
                }
            });
        } else {
            await (prisma as any).gigExpense.create({
                data: {
                    gigId,
                    description: `Frete: ${supplier.name} (${distanceKm.toFixed(0)}km)`,
                    amount,
                    category: "TRANSPORT"
                }
            });
        }

        revalidatePath(`/dashboard/gigs/${gigId}`);
        return {
            success: true,
            data: {
                distanceKm,
                amount,
                supplierName: supplier.name
            }
        };
    } catch (error: any) {
        console.error("Error calculating freight:", error);
        return { success: false, error: error.message };
    }
}


// --- GIG FINANCIALS (Commission, Status) ---

export async function updateGigFinancials(gigId: string, data: { commissionRate?: number, status?: string }) {
    try {
        await prisma.gig.update({
            where: { id: gigId },
            data: {
                ...(data.commissionRate !== undefined && { commissionRate: data.commissionRate }),
                ...(data.status && { status: data.status })
            }
        });

        revalidatePath(`/dashboard/gigs/${gigId}`);
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

// --- TRANSACTIONS (Cash Flow) ---

export async function manageTransaction(data: {
    id?: string,
    description: string,
    amount: number,
    type: 'INCOME' | 'EXPENSE',
    status: 'PENDING' | 'PAID' | 'CANCELLED',
    category?: string,
    dueDate?: Date,
    paymentDate?: Date,
    receiptUrl?: string,
    isRecurring?: boolean,
    gigId?: string,
    bandId: string
}) {
    try {
        if (data.id) {
            await prisma.financialTransaction.update({
                where: { id: data.id },
                data: {
                    description: data.description,
                    amount: data.amount,
                    type: data.type,
                    status: data.status,
                    category: data.category,
                    dueDate: data.dueDate,
                    paymentDate: data.paymentDate,
                    receiptUrl: data.receiptUrl,
                    isRecurring: data.isRecurring,
                    gigId: data.gigId
                }
            });
        } else {
            // @ts-ignore
            await prisma.financialTransaction.create({
                data: {
                    description: data.description,
                    amount: data.amount,
                    type: data.type,
                    status: data.status,
                    category: data.category,
                    dueDate: data.dueDate,
                    paymentDate: data.paymentDate,
                    receiptUrl: data.receiptUrl,
                    isRecurring: data.isRecurring || false,
                    gigId: data.gigId,
                    bandId: data.bandId
                }
            });
        }

        revalidatePath('/dashboard/finance');
        return { success: true };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

// --- DRE & ANALYTICS ---

export async function getDREAnalytics(bandId: string, startDate: Date, endDate: Date) {
    try {
        const gigs = await prisma.gig.findMany({
            where: {
                bandId,
                date: {
                    gte: startDate,
                    lte: endDate
                }
            },
            include: {
                expenses: true,
                memberFees: true,
                format: true
            }
        });

        // Basic aggregation
        let totalRevenue = 0;
        let totalExpenses = 0;
        let totalTaxes = 0;
        let totalCommissions = 0;
        let totalMemberFees = 0;

        const cityStats: Record<string, number> = {};
        const formatStats: Record<string, number> = {};

        gigs.forEach((gig: any) => {
            const fee = gig.fee || 0;
            totalRevenue += fee;

            // Expenses
            const gigExpenseTotal = (gig.expenses || []).reduce((sum: number, e: any) => sum + e.amount, 0);
            totalExpenses += gigExpenseTotal;

            // Taxes
            const tax = gig.taxAmount || (fee * (gig.taxRate || 0) / 100);
            totalTaxes += tax;

            // Commission
            const commission = (fee * (gig.commissionRate || 0) / 100);
            totalCommissions += commission;

            // Member Fees
            const membersTotal = (gig.memberFees || []).reduce((sum: number, f: any) => sum + f.amount, 0);
            totalMemberFees += membersTotal;

            // Geo/Format Stats
            const city = gig.location?.split(',')?.pop()?.trim() || "Desconhecido";
            cityStats[city] = (cityStats[city] || 0) + (fee - tax - gigExpenseTotal - commission);

            const format = gig.format?.name || "Padrão";
            formatStats[format] = (formatStats[format] || 0) + (fee - tax - gigExpenseTotal - commission);
        });

        return {
            success: true,
            data: {
                revenue: totalRevenue,
                expenses: totalExpenses,
                taxes: totalTaxes,
                commissions: totalCommissions,
                memberFees: totalMemberFees,
                netProfit: totalRevenue - totalExpenses - totalTaxes - totalCommissions - totalMemberFees,
                cityStats,
                formatStats,
                gigCount: gigs.length
            }
        };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}

export async function getCashFlow(bandId: string) {
    try {
        // @ts-ignore
        const transactions = await prisma.financialTransaction.findMany({
            where: { bandId },
            orderBy: { dueDate: 'asc' }
        });

        return { success: true, transactions };
    } catch (error: any) {
        return { success: false, error: error.message };
    }
}
