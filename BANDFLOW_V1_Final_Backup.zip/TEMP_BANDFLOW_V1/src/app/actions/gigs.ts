"use server";

import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { revalidatePath } from "next/cache";
import { logActivity } from "@/lib/activityLog";

export async function createGig(formData: FormData) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    const title = formData.get("title") as string;
    const date = new Date(formData.get("date") as string);
    const location = formData.get("location") as string;
    const feeStr = formData.get("fee") as string;
    const fee = feeStr ? parseFloat(feeStr) : null;
    const notes = formData.get("notes") as string;
    const setlistId = formData.get("setlistId") as string;

    // New itinerary fields
    const loadInStr = formData.get("loadIn") as string;
    const loadIn = loadInStr ? new Date(loadInStr) : null;
    const soundcheckStr = formData.get("soundcheck") as string;
    const soundcheck = soundcheckStr ? new Date(soundcheckStr) : null;
    const showtimeStr = formData.get("showtime") as string;
    const showtime = showtimeStr ? new Date(showtimeStr) : null;

    const taxRateStr = formData.get("taxRate") as string;
    const taxRate = taxRateStr ? parseFloat(taxRateStr) : null;
    const taxAmountStr = formData.get("taxAmount") as string;
    const taxAmount = taxAmountStr ? parseFloat(taxAmountStr) : null;

    const membership = await prisma.member.findFirst({
        where: { userId: session.user.id },
    });

    if (!membership) throw new Error("No band found");

    await prisma.gig.create({
        data: {
            title,
            date,
            location,
            fee,
            taxRate,
            taxAmount,
            notes,
            bandId: membership.bandId,
            setlistId: setlistId || null,
            loadIn,
            soundcheck,
            showtime,
        },
    });

    revalidatePath("/dashboard/gigs");
    revalidatePath("/dashboard");
    await logActivity("CREATED", "GIG", `Show "${title}" criado`, membership.bandId);
}

export async function updateGig(formData: FormData) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    const id = formData.get("id") as string;
    const title = formData.get("title") as string;
    const date = new Date(formData.get("date") as string);
    const location = formData.get("location") as string;
    const feeStr = formData.get("fee") as string;
    const fee = feeStr ? parseFloat(feeStr) : null;
    const taxRateStr = formData.get("taxRate") as string;
    const taxRate = taxRateStr ? parseFloat(taxRateStr) : null;
    const taxAmountStr = formData.get("taxAmount") as string;
    const taxAmount = taxAmountStr ? parseFloat(taxAmountStr) : null;
    const notes = formData.get("notes") as string;
    const setlistId = formData.get("setlistId") as string;

    const loadInStr = formData.get("loadIn") as string;
    const loadIn = loadInStr ? new Date(loadInStr) : null;
    const soundcheckStr = formData.get("soundcheck") as string;
    const soundcheck = soundcheckStr ? new Date(soundcheckStr) : null;
    const showtimeStr = formData.get("showtime") as string;
    const showtime = showtimeStr ? new Date(showtimeStr) : null;

    await prisma.gig.update({
        where: { id },
        data: {
            title,
            date,
            location,
            fee,
            taxRate,
            taxAmount,
            notes,
            setlistId: setlistId || null,
            loadIn,
            soundcheck,
            showtime,
        },
    });

    revalidatePath("/dashboard/gigs");
    revalidatePath(`/dashboard/gigs/${id}`);
    revalidatePath("/dashboard");
}

export async function deleteGig(gigId: string) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    await prisma.gig.delete({
        where: { id: gigId },
    });

    revalidatePath("/dashboard/gigs");
    revalidatePath("/dashboard");
    const membership = await prisma.member.findFirst({ where: { userId: session.user.id } });
    if (membership) await logActivity("DELETED", "GIG", `Show removido`, membership.bandId);
}

export async function createGigTask(gigId: string, formData: FormData) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    const description = formData.get("description") as string;
    if (!description) return;

    // @ts-ignore
    await prisma.gigTask.create({
        data: {
            description,
            gigId,
        },
    });

    revalidatePath(`/dashboard/gigs/${gigId}`);
}

export async function toggleGigTask(taskId: string, isCompleted: boolean, gigId: string) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    // @ts-ignore
    await prisma.gigTask.update({
        where: { id: taskId },
        data: { isCompleted },
    });

    revalidatePath(`/dashboard/gigs/${gigId}`);
}

export async function deleteGigTask(taskId: string, gigId: string) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    // @ts-ignore
    await prisma.gigTask.delete({
        where: { id: taskId },
    });

    revalidatePath(`/dashboard/gigs/${gigId}`);
}
