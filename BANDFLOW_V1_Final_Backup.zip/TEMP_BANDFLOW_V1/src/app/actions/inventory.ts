"use server";

import { prisma } from "@/lib/prisma";
import { auth } from "@/auth";
import { revalidatePath } from "next/cache";

export async function createEquipment(bandId: string, formData: FormData) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    const name = formData.get("name") as string;
    const category = formData.get("category") as string;
    const brand = formData.get("brand") as string;
    const serialNumber = formData.get("serialNumber") as string;
    const valueStr = formData.get("value") as string;
    const value = valueStr ? parseFloat(valueStr) : null;
    const status = formData.get("status") as string || "AVAILABLE";
    const ownerId = formData.get("ownerId") as string;
    const formatIds = formData.getAll("formats") as string[];

    if (!name || !category || !bandId) return;

    await prisma.equipment.create({
        data: {
            name,
            category,
            brand,
            serialNumber,
            value,
            status,
            ownerId: ownerId === "band" ? null : ownerId,
            bandId,
            formats: {
                connect: formatIds.map((id) => ({ id }))
            }
        },
    });

    revalidatePath(`/dashboard/inventory`);
}

export async function deleteEquipment(equipmentId: string) {
    const session = await auth();
    if (!session?.user?.id) throw new Error("Unauthorized");

    await prisma.equipment.delete({
        where: { id: equipmentId },
    });

    revalidatePath(`/dashboard/inventory`);
}
