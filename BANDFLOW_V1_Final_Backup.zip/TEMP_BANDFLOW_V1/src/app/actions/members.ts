"use server"

import { prisma as db } from "@/lib/prisma"
import { getActiveBand } from "@/lib/getActiveBand"
import { revalidatePath } from "next/cache"
import { z } from "zod"

const memberSchema = z.object({
    name: z.string().min(1, "Nome é obrigatório"),
    rg: z.string().optional().nullable(),
    cpf: z.string().optional().nullable(),
    whatsapp: z.string().optional().nullable(),
    position: z.string().optional().nullable(),
    cache: z.number().optional().nullable(),
    role: z.enum(["ADMIN", "PRODUCER", "FINANCIAL", "ROADIE", "MUSICIAN"]).default("MUSICIAN"),
})

export async function createMember(formData: FormData, selectedFormats: string[]) {
    try {
        const { activeBandId: bandId } = await getActiveBand()
        if (!bandId) {
            return { success: false, error: "Nenhuma banda selecionada" }
        }

        const data = {
            name: formData.get("name") as string,
            rg: formData.get("rg") as string || null,
            cpf: formData.get("cpf") as string || null,
            whatsapp: formData.get("whatsapp") as string || null,
            position: formData.get("position") as string || null,
            cache: formData.get("cache") ? parseFloat(formData.get("cache") as string) : null,
            role: (formData.get("role") as "ADMIN" | "PRODUCER" | "FINANCIAL" | "ROADIE" | "MUSICIAN") || "MUSICIAN",
        }

        const result = memberSchema.safeParse(data)
        if (!result.success) {
            return { success: false, error: (result.error as any).errors[0].message }
        }

        const formatsToConnect = selectedFormats.map(id => ({ id }))

        const member = await db.member.create({
            data: {
                bandId,
                role: result.data.role,
                name: result.data.name,
                rg: result.data.rg,
                cpf: result.data.cpf,
                whatsapp: result.data.whatsapp,
                position: result.data.position,
                cache: result.data.cache,
                formats: {
                    connect: formatsToConnect
                }
            }
        })

        revalidatePath("/dashboard/members")
        return { success: true, data: member }
    } catch (error) {
        console.error("Erro ao criar membro:", error)
        return { success: false, error: "Erro interno ao cadastrar integrante" }
    }
}

export async function updateMember(id: string, formData: FormData, selectedFormats: string[]) {
    try {
        const { activeBandId: bandId } = await getActiveBand()
        if (!bandId) {
            return { success: false, error: "Nenhuma banda selecionada" }
        }

        const existing = await db.member.findUnique({ where: { id } })
        if (!existing || existing.bandId !== bandId) {
            return { success: false, error: "Integrante não encontrado ou sem permissão" }
        }

        const data = {
            name: formData.get("name") as string,
            rg: formData.get("rg") as string || null,
            cpf: formData.get("cpf") as string || null,
            whatsapp: formData.get("whatsapp") as string || null,
            position: formData.get("position") as string || null,
            cache: formData.get("cache") ? parseFloat(formData.get("cache") as string) : null,
            role: (formData.get("role") as "ADMIN" | "PRODUCER" | "FINANCIAL" | "ROADIE" | "MUSICIAN") || existing.role,
        }

        const result = memberSchema.safeParse(data)
        if (!result.success) {
            return { success: false, error: (result.error as any).errors[0].message }
        }

        const formatsToConnect = selectedFormats.map(fId => ({ id: fId }))

        const member = await db.member.update({
            where: { id },
            data: {
                role: result.data.role,
                name: result.data.name,
                rg: result.data.rg,
                cpf: result.data.cpf,
                whatsapp: result.data.whatsapp,
                position: result.data.position,
                cache: result.data.cache,
                formats: {
                    set: [], // Disconnect all first
                    connect: formatsToConnect
                }
            }
        })

        revalidatePath("/dashboard/members")
        return { success: true, data: member }
    } catch (error) {
        console.error("Erro ao atualizar membro:", error)
        return { success: false, error: "Erro interno ao atualizar integrante" }
    }
}

export async function deleteMember(id: string) {
    try {
        const { activeBandId: bandId } = await getActiveBand()
        if (!bandId) { return { success: false, error: "Nenhuma banda ativa" } }

        const existing = await db.member.findUnique({ where: { id } })
        if (!existing || existing.bandId !== bandId) {
            return { success: false, error: "Integrante não encontrado ou sem permissão" }
        }

        await db.member.delete({ where: { id } })

        revalidatePath("/dashboard/members")
        return { success: true }
    } catch (error) {
        return { success: false, error: "Este integrante está atrelado a registros no sistema" }
    }
}
