"use client"

import { useState } from "react"
import { Briefcase, Building2, Plus, Users, Search, MapPin, Phone, Mail, FileText, MoreHorizontal, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ContractorDialog } from "@/components/dashboard/contractors/contractor-dialog"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuTrigger
} from "@/components/ui/dropdown-menu"
import { deleteContractor } from "@/app/actions/contractors"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

interface Contractor {
    id: string;
    name: string;
    document?: string | null;
    email?: string | null;
    phone?: string | null;
    city?: string | null;
    state?: string | null;
    notes?: string | null;
    bandId: string;
}

export function ContractorsClient({ initialContractors }: { initialContractors: Contractor[] }) {
    const router = useRouter();
    const [isDialogOpen, setIsDialogOpen] = useState(false)
    const [searchTerm, setSearchTerm] = useState("")
    const [selectedContractor, setSelectedContractor] = useState<any>(null)
    const [contractors, setContractors] = useState<Contractor[]>(initialContractors)

    const filteredContractors = contractors.filter(c =>
        c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.document?.includes(searchTerm)
    )

    const handleEdit = (contractor: any) => {
        setSelectedContractor(contractor)
        setIsDialogOpen(true)
    }

    const handleNew = () => {
        setSelectedContractor(null)
        setIsDialogOpen(true)
    }

    const handleDelete = async (id: string) => {
        if (!confirm("Excluir este contratante?")) return;
        const res = await deleteContractor(id);
        if (res.success) {
            setContractors(contractors.filter(c => c.id !== id));
            toast.success("Contratante excluído!");
        } else {
            toast.error(res.error || "Erro ao excluir.");
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                        <Briefcase className="h-8 w-8 text-secondary" />
                        Contratantes
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie os clientes, prefeituras e contratantes dos seus shows.
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <Button onClick={handleNew} className="gap-2 bg-secondary text-white hover:bg-secondary/90 border-0">
                        <Plus className="h-4 w-4" />
                        Novo Contratante
                    </Button>
                </div>
            </div>

            <div className="flex items-center space-x-2">
                <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-zinc-500" />
                    <Input
                        type="search"
                        placeholder="Buscar por nome, documento ou cidade..."
                        className="pl-9 bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredContractors.length > 0 ? (
                    filteredContractors.map((contractor) => (
                        <div key={contractor.id} className="group relative rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 hover:ring-primary/30 transition-all flex flex-col gap-4">
                            <div className="flex justify-between items-start">
                                <div className="flex items-center gap-3">
                                    <div className="p-3 rounded-2xl bg-secondary/10 text-secondary">
                                        <Building2 className="h-6 w-6" />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-lg text-foreground leading-tight group-hover:text-secondary transition-colors">
                                            {contractor.name}
                                        </h3>
                                        <p className="text-sm text-zinc-500 flex items-center gap-1 mt-1">
                                            <FileText className="h-3 w-3" />
                                            {contractor.document || "Sem documento"}
                                        </p>
                                    </div>
                                </div>

                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <span className="sr-only">Abrir menu</span>
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end">
                                        <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                        <DropdownMenuItem onClick={() => handleEdit(contractor)}>
                                            Editar
                                        </DropdownMenuItem>
                                        <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(contractor.id)}>
                                            <Trash2 className="mr-2 h-4 w-4" /> Excluir
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </div>

                            <div className="space-y-2 mt-2 pt-4 border-t border-zinc-100 dark:border-zinc-800 text-sm">
                                {contractor.email && (
                                    <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400">
                                        <Mail className="h-4 w-4 text-zinc-400" />
                                        <span className="truncate">{contractor.email}</span>
                                    </div>
                                )}
                                {contractor.phone && (
                                    <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400">
                                        <Phone className="h-4 w-4 text-zinc-400" />
                                        <span>{contractor.phone}</span>
                                    </div>
                                )}
                                {(contractor.city || contractor.state) && (
                                    <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400">
                                        <MapPin className="h-4 w-4 text-zinc-400" />
                                        <span>
                                            {contractor.city}{contractor.city && contractor.state ? " - " : ""}{contractor.state}
                                        </span>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="col-span-full rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <div className="inline-flex p-4 rounded-full bg-secondary/10 text-secondary mb-4">
                            <Users className="h-8 w-8" />
                        </div>
                        <h3 className="text-lg font-bold text-foreground">Nenhum contratante encontrado</h3>
                        <p className="mt-2 text-zinc-500">Cadastre seus clientes para agilizar a criação de contratos.</p>
                    </div>
                )}
            </div>

            <ContractorDialog
                open={isDialogOpen}
                onOpenChange={setIsDialogOpen}
                contractor={selectedContractor}
                onSuccess={() => {
                    setIsDialogOpen(false);
                    router.refresh();
                }}
            />
        </div>
    )
}
