// Página Server Component — busca dados reais do banco
import { getContractors } from "@/app/actions/contractors"
import { ContractorsClient } from "./contractors-client"

export default async function ContractorsPage() {
    const result = await getContractors();
    const contractors = result.success ? (result.data ?? []) : [];
    return <ContractorsClient initialContractors={contractors as any} />;
}
