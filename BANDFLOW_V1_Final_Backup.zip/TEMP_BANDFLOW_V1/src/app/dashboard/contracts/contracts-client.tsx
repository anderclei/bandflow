"use client"

import Link from "next/link"
import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Plus, FileText, Download, Trash2, ShieldCheck, FileSignature } from "lucide-react"
import { CreateContractDialog } from "@/components/dashboard/contracts/create-contract-dialog"
import { ContractDetailsDialog } from "@/components/dashboard/contracts/contract-details-dialog"
import { DigitalSignatureDialog } from "@/components/dashboard/contracts/digital-signature-dialog"
import { deleteContract } from "@/app/actions/contracts"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

type ContractStatus = "Rascunho" | "Enviado" | "Assinado" | "Cancelado" | "Orçamento"

interface Contract {
    id: string
    eventName?: string | null
    date?: string | null
    amount?: number | null
    status?: ContractStatus | null
    clientName?: string | null
    createdAt?: string
    data?: string // JSON original do banco
}

interface Contractor {
    id: string
    name: string
}

const getStatusColor = (status?: string | null) => {
    switch (status) {
        case "Rascunho": return "secondary"
        case "Enviado": return "default"
        case "Assinado": return "outline"
        case "Cancelado": return "destructive"
        default: return "secondary"
    }
}

export function ContractsClient({
    initialContracts,
    contractors,
}: {
    initialContracts: Contract[];
    contractors: Contractor[];
}) {
    const router = useRouter();
    const [isNewContractOpen, setIsNewContractOpen] = useState(false)
    const [selectedContract, setSelectedContract] = useState<Contract | null>(null)
    const [isDetailsOpen, setIsDetailsOpen] = useState(false)
    const [isSignatureOpen, setIsSignatureOpen] = useState(false)
    const [contracts, setContracts] = useState<Contract[]>(initialContracts.map(c => {
        if (c.data) {
            try {
                const parsed = JSON.parse(c.data);
                return {
                    ...c,
                    eventName: parsed.eventName || parsed.venue || "Contrato sem título",
                    clientName: parsed.clientName || "—",
                    date: parsed.date,
                    amount: parsed.amount
                };
            } catch (e) {
                return c;
            }
        }
        return c;
    }))

    const handleViewDetails = (contract: Contract) => {
        setSelectedContract(contract)
        setIsDetailsOpen(true)
    }

    const handleOpenSignature = (contract: Contract) => {
        setSelectedContract(contract)
        setIsSignatureOpen(true)
    }

    const handleDelete = async (id: string) => {
        if (!confirm("Tem certeza que deseja excluir este contrato?")) return
        try {
            await deleteContract(id)
            setContracts(prev => prev.filter(c => c.id !== id))
            toast.success("Contrato excluído")
        } catch (e) {
            toast.error("Erro ao excluir contrato")
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <FileText className="h-8 w-8 text-secondary" />
                        Orçamentos e Contratos
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie suas propostas e contratos de shows.
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" asChild>
                        <Link href="/dashboard/templates">
                            <FileText className="mr-2 h-4 w-4 text-secondary" />
                            Gerenciar Modelos
                        </Link>
                    </Button>
                    <Button onClick={() => setIsNewContractOpen(true)} className="gap-2 bg-secondary text-white hover:bg-secondary/90 border-0">
                        <Plus className="h-4 w-4" />
                        Novo Orçamento/Contrato
                    </Button>
                </div>
            </div>

            <div className="grid gap-4">
                {contracts.length > 0 ? (
                    contracts.map((contract) => (
                        <div key={contract.id} className="group relative rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 hover:ring-primary/30 transition-all flex flex-col sm:flex-row gap-6 items-center">
                            <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-secondary/10 text-secondary min-w-[80px]">
                                <FileText className="h-8 w-8 mb-1" />
                                <span className="text-[10px] uppercase font-bold text-center">
                                    {contract.status === "Orçamento" ? "ORÇ" : "CONT"}
                                </span>
                            </div>

                            <div className="flex-1 space-y-3 w-full">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h3 className="text-xl font-bold text-foreground group-hover:text-secondary transition-colors">{contract.eventName || "Sem título"}</h3>
                                        <p className="text-sm font-medium text-zinc-500">{contract.clientName || "—"}</p>
                                    </div>

                                    <div className="flex items-center gap-4">
                                        <Badge
                                            variant={getStatusColor(contract.status) as any}
                                            className={contract.status === "Assinado" ? "bg-green-500 hover:bg-green-600 text-white border-0" : ""}
                                        >
                                            {contract.status || "Rascunho"}
                                        </Badge>
                                        <DropdownMenu>
                                            <DropdownMenuTrigger asChild>
                                                <Button variant="ghost" className="h-8 w-8 p-0">
                                                    <MoreHorizontal className="h-4 w-4" />
                                                </Button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuLabel>Ações</DropdownMenuLabel>
                                                <DropdownMenuItem onClick={() => handleViewDetails(contract)}>
                                                    <FileText className="mr-2 h-4 w-4" /> Ver Detalhes
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleOpenSignature(contract)}>
                                                    <FileSignature className="mr-2 h-4 w-4 text-secondary" /> Assinatura Digital
                                                </DropdownMenuItem>
                                                <DropdownMenuItem onClick={() => handleDelete(contract.id)} className="text-destructive">
                                                    <Trash2 className="mr-2 h-4 w-4" /> Excluir
                                                </DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </div>
                                </div>

                                <div className="flex flex-wrap items-center gap-6 text-sm text-zinc-600 dark:text-zinc-400">
                                    {contract.date && (
                                        <span>{new Date(contract.date).toLocaleDateString('pt-BR')}</span>
                                    )}
                                    {contract.amount != null && (
                                        <span>{new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(contract.amount)}</span>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <div className="rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <div className="inline-flex p-4 rounded-full bg-secondary/10 text-secondary mb-4">
                            <FileText className="h-8 w-8" />
                        </div>
                        <h3 className="text-lg font-bold text-foreground">Nenhum contrato cadastrado</h3>
                        <p className="mt-2 text-zinc-500">Crie seu primeiro orçamento ou contrato para começar.</p>
                    </div>
                )}
            </div>

            <CreateContractDialog
                open={isNewContractOpen}
                onOpenChange={(open) => {
                    setIsNewContractOpen(open);
                    if (!open) router.refresh();
                }}
            />

            <ContractDetailsDialog
                contract={selectedContract}
                open={isDetailsOpen}
                onOpenChange={setIsDetailsOpen}
            />

            <DigitalSignatureDialog
                contract={selectedContract}
                open={isSignatureOpen}
                onOpenChange={setIsSignatureOpen}
            />
        </div>
    )
}
