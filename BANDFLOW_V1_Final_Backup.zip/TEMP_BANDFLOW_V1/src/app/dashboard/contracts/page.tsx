// Página de Contratos — server component com dados reais do banco
import { getActiveBand } from "@/lib/getActiveBand"
import { ContractsClient } from "./contracts-client"
import { getContractors } from "@/app/actions/contractors"

export default async function ContractsPage() {
    const [{ band }, contractorsResult] = await Promise.all([
        getActiveBand({ generatedContracts: { orderBy: { createdAt: "desc" } } }),
        getContractors(),
    ]);

    const contracts = (band as any)?.generatedContracts || [];
    const contractors = contractorsResult.success ? (contractorsResult.data ?? []) : [];

    return <ContractsClient initialContracts={contracts} contractors={contractors as any} />;
}
