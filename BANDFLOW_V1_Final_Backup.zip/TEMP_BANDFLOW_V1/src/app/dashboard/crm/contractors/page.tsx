import { getActiveBand } from "@/lib/getActiveBand";
import { prisma } from "@/lib/prisma";
import { Contact, Search, Plus, Trash2, Building, Mail, Phone, MapPin } from "lucide-react";
import { redirect } from "next/navigation";
import { createContractor, deleteContractor } from "@/app/actions/crm";
import Link from "next/link";

export default async function ContractorsPage() {
    const { band } = await getActiveBand({
        contractors: {
            orderBy: { name: 'asc' },
            include: { gigs: true }
        }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const contractors = band.contractors || [];

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Contact className="h-8 w-8 text-secondary" />
                        CRM: Contratantes
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie as prefeituras, bares, produtores e clientes da sua banda.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">

                {/* Add Form */}
                <div className="lg:col-span-1">
                    <div className="sticky top-8 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                            <Plus className="h-5 w-5 text-secondary" />
                            Novo Cliente
                        </h2>
                        <form action={createContractor.bind(null, band.id)} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Nome / Razão Social</label>
                                <input
                                    name="name"
                                    required
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="Ex: Prefeitura de SP"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">E-mail</label>
                                <input
                                    name="email"
                                    type="email"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="contato@..."
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Telefone / WhatsApp</label>
                                <input
                                    name="phone"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="(11) 99999-9999"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Cidade</label>
                                    <input
                                        name="city"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Estado (UF)</label>
                                    <input
                                        name="state"
                                        maxLength={2}
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20 uppercase"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Notas / CNPJ</label>
                                <textarea
                                    name="notes"
                                    rows={3}
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="Informações adicionais..."
                                />
                            </div>
                            <button
                                type="submit"
                                className="w-full rounded-xl bg-zinc-900 py-3 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors shadow-sm dark:bg-white dark:text-black dark:hover:bg-zinc-200"
                            >
                                Salvar Contratante
                            </button>
                        </form>
                    </div>
                </div>

                {/* List */}
                <div className="lg:col-span-2 space-y-4">
                    {contractors.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {contractors.map((contractor: any) => (
                                <Link key={contractor.id} href={`/dashboard/crm/contractors/${contractor.id}`} className="group block h-full">
                                    <div className="flex flex-col h-full rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 hover:ring-secondary/50 dark:bg-zinc-900 dark:ring-zinc-800 dark:hover:ring-secondary/50 transition-all">
                                        <div className="flex justify-between items-start mb-4">
                                            <div className="flex items-center gap-3">
                                                <div className="p-3 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 group-hover:bg-secondary/10 group-hover:text-secondary dark:group-hover:bg-secondary/20 transition-colors">
                                                    <Building className="h-5 w-5" />
                                                </div>
                                                <div>
                                                    <h3 className="font-bold text-foreground group-hover:text-secondary transition-colors line-clamp-1">{contractor.name}</h3>
                                                    <p className="text-xs text-zinc-500">
                                                        {contractor.gigs.length} {contractor.gigs.length === 1 ? 'Show Fechado' : 'Shows Fechados'}
                                                    </p>
                                                </div>
                                            </div>
                                            {/* We prevent default to avoid triggering the link wrapper */}
                                            <form action={async (e) => {
                                                "use server";
                                                await deleteContractor(contractor.id);
                                            }} className="z-10 relative">
                                                <button
                                                    type="submit"
                                                    className="p-2 text-zinc-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </button>
                                            </form>
                                        </div>

                                        <div className="space-y-2 mt-auto text-sm text-zinc-600 dark:text-zinc-400">
                                            {contractor.email && (
                                                <div className="flex items-center gap-2">
                                                    <Mail className="h-4 w-4 shrink-0 opacity-50" />
                                                    <span className="truncate">{contractor.email}</span>
                                                </div>
                                            )}
                                            {contractor.phone && (
                                                <div className="flex items-center gap-2">
                                                    <Phone className="h-4 w-4 shrink-0 opacity-50" />
                                                    <span className="truncate">{contractor.phone}</span>
                                                </div>
                                            )}
                                            {(contractor.city || contractor.state) && (
                                                <div className="flex items-center gap-2">
                                                    <MapPin className="h-4 w-4 shrink-0 opacity-50" />
                                                    <span className="truncate">{contractor.city}{contractor.city && contractor.state ? ' - ' : ''}{contractor.state}</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </Link>
                            ))}
                        </div>
                    ) : (
                        <div className="rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <div className="inline-flex p-4 rounded-full bg-zinc-100 dark:bg-zinc-800/50 text-zinc-400 mb-4">
                                <Building className="h-8 w-8" />
                            </div>
                            <h3 className="text-lg font-bold text-foreground">Nenhum contratante cadastrado</h3>
                            <p className="mt-2 text-zinc-500 max-w-sm mx-auto">Comece a adicionar bares, prefeituras e clientes para gerenciar seu histórico de parcerias.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
