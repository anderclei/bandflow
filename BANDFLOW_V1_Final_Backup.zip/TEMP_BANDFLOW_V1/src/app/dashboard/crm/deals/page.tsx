import { getActiveBand } from "@/lib/getActiveBand";
import { prisma } from "@/lib/prisma";
import { Briefcase, Search, Plus } from "lucide-react";
import { redirect } from "next/navigation";
import { KanbanBoard } from "@/components/dashboard/crm/KanbanBoard";

export default async function DealsPage() {
    const { band } = await getActiveBand({
        deals: {
            include: { contractor: true },
            orderBy: { updatedAt: 'desc' }
        },
        contractors: {
            orderBy: { name: 'asc' }
        }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const deals = band.deals || [];
    const contractors = band.contractors || [];

    return (
        <div className="space-y-8 h-[calc(100vh-8rem)] flex flex-col">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between shrink-0">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Briefcase className="h-8 w-8 text-secondary" />
                        CRM: Deals (Booking)
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Acompanhe suas negociações de shows através do funil de vendas.
                    </p>
                </div>
            </div>

            <div className="flex-1 overflow-hidden">
                <KanbanBoard initialDeals={deals} contractors={contractors} bandId={band.id} />
            </div>
        </div>
    );
}
