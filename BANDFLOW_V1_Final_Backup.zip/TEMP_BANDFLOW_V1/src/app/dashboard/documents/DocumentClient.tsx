"use client";

import { useState } from "react";
import { FolderOpen, Upload, FileText, Trash2, AlertCircle, FileKey, ShieldAlert, CreditCard, ChevronDown, Wand2, CheckCircle2 } from "lucide-react";
import { createDocument, deleteDocument } from "@/app/actions/documents";
import { generateEcadRepertoire } from "@/app/actions/ecad-gen";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

interface Document {
    id: string;
    title: string;
    category: string;
    fileUrl: string;
    expiryDate: Date | null;
    member?: { user: { name: string } } | null;
}

interface Member {
    id: string;
    user: { name: string };
}

interface DocumentClientProps {
    initialDocuments: Document[];
    members: Member[];
    bandId: string;
    setlists?: any[];
}

export function DocumentClient({ initialDocuments, members, bandId, setlists = [] }: DocumentClientProps) {
    const [documents, setDocuments] = useState(initialDocuments);
    const [isUploading, setIsUploading] = useState(false);
    const [isGenerating, setIsGenerating] = useState(false);
    const [genResult, setGenResult] = useState<any>(null);

    // Form state
    const [title, setTitle] = useState("");
    const [category, setCategory] = useState("CND");
    const [memberId, setMemberId] = useState("");
    const [expiryDate, setExpiryDate] = useState("");
    const [file, setFile] = useState<File | null>(null);

    const isExpired = (date: Date | null) => {
        if (!date) return false;
        return new Date(date) < new Date();
    };

    const isExpiringSoon = (date: Date | null) => {
        if (!date) return false;
        const diffTime = Math.abs(new Date(date).getTime() - new Date().getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays <= 30 && diffDays > 0;
    };

    const handleUpload = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!file || !title) return;

        setIsUploading(true);

        try {
            // 1. Upload file to local API
            const formData = new FormData();
            formData.append("file", file);
            formData.append("type", "document");

            const uploadRes = await fetch("/api/upload", {
                method: "POST",
                body: formData,
            });

            if (!uploadRes.ok) throw new Error("Upload failed");

            const { url } = await uploadRes.json();

            // 2. Save Document object
            const docFormData = new FormData();
            docFormData.append("title", title);
            docFormData.append("category", category);
            if (expiryDate) docFormData.append("expiryDate", expiryDate);
            if (memberId) docFormData.append("memberId", memberId);

            await createDocument(bandId, url, docFormData);

            // Reset form
            setTitle("");
            setFile(null);
            setExpiryDate("");
            setMemberId("");

            // Note: Since we use Server Actions, Next.js revalidatePath will refresh the page data
            window.location.reload();

        } catch (error) {
            console.error("Error creating document", error);
            alert("Erro ao enviar documento");
        } finally {
            setIsUploading(false);
        }
    };

    const handleDelete = async (id: string) => {
        if (confirm("Tem certeza que deseja excluir este documento?")) {
            await deleteDocument(id);
            setDocuments(documents.filter(d => d.id !== id));
        }
    };

    const handleGenerateEcad = async (type: "FULL" | "SETLIST", setlistId?: string) => {
        setIsGenerating(true);
        try {
            const res = await generateEcadRepertoire({ type, setlistId });
            setGenResult(res);
        } catch (error) {
            console.error("Error generating ECAD", error);
            alert("Erro ao gerar documento");
        } finally {
            setIsGenerating(false);
        }
    };

    const getCategoryIcon = (cat: string) => {
        switch (cat) {
            case 'CND': return <ShieldAlert className="h-5 w-5 text-blue-500" />;
            case 'IDENTIFICACAO': return <CreditCard className="h-5 w-5 text-indigo-500" />;
            case 'CONTRATO': return <FileKey className="h-5 w-5 text-amber-500" />;
            case 'ECAD': return <FileText className="h-5 w-5 text-green-500" />;
            default: return <FileText className="h-5 w-5 text-zinc-500" />;
        }
    };

    const getCategoryName = (cat: string) => {
        switch (cat) {
            case 'CND': return 'Certidão Negativa (CND)';
            case 'IDENTIFICACAO': return 'Identificação (RG/CPF)';
            case 'CONTRATO': return 'Contrato / Estatuto';
            case 'RIDER_CAMARIM': return 'Rider de Camarim';
            case 'ECAD': return 'Documentação ECAD';
            default: return 'Outros';
        }
    };

    return (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
            {genResult && (
                <div className="lg:col-span-3 mb-4 rounded-3xl bg-green-50 dark:bg-green-500/10 p-6 border border-green-200 dark:border-green-500/20 flex flex-col md:flex-row items-center justify-between gap-6 animate-in fade-in slide-in-from-top-4">
                    <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center text-green-600">
                            <CheckCircle2 className="h-6 w-6" />
                        </div>
                        <div>
                            <h4 className="font-bold text-green-800 dark:text-green-400">Documento Gerado!</h4>
                            <p className="text-sm text-green-700 dark:text-green-500/80">
                                {genResult.message} ({genResult.itemCount} músicas processadas).
                            </p>
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <Button
                            variant="outline"
                            className="bg-white dark:bg-zinc-900 border-green-200 dark:border-green-500/30 text-green-700 dark:text-green-400"
                            onClick={() => setGenResult(null)}
                        >
                            Fechar
                        </Button>
                        <Button className="bg-green-600 hover:bg-green-700 text-white border-0">
                            Baixar Relação de Obras
                        </Button>
                    </div>
                </div>
            )}

            {/* Generative Tools */}
            <div className="lg:col-span-3">
                <div className="rounded-3xl bg-gradient-to-r from-secondary/10 to-transparent p-6 border border-secondary/20 flex flex-col md:flex-row items-center justify-between gap-6">
                    <div className="flex items-center gap-4 text-left">
                        <div className="h-14 w-14 rounded-2xl bg-secondary flex items-center justify-center text-white shadow-lg shadow-secondary/20 shrink-0">
                            <Wand2 className="h-7 w-7" />
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-foreground">Geração Inteligente de Documentos</h3>
                            <p className="text-sm text-zinc-500 max-w-xl">
                                Gere automaticamente a **Relação de Obras (ECAD)** e as cartas de autorização usando os dados ISWC e códigos de obra do seu repertório.
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <Button disabled={isGenerating} size="lg" className="bg-secondary text-white hover:bg-secondary/90 border-0 gap-2 h-14 px-8 rounded-2xl">
                                    {isGenerating ? "Gerando..." : "Gerar Documento ECAD"}
                                    <ChevronDown className="h-4 w-4" />
                                </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-64 rounded-xl p-2">
                                <DropdownMenuLabel>Selecione a fonte de dados</DropdownMenuLabel>
                                <DropdownMenuItem className="rounded-lg py-3 cursor-pointer" onClick={() => handleGenerateEcad("FULL")}>
                                    <FileText className="mr-2 h-4 w-4" />
                                    Catálogo Completo
                                </DropdownMenuItem>
                                {setlists.length > 0 && (
                                    <>
                                        <div className="h-px bg-zinc-100 dark:bg-zinc-800 my-1" />
                                        <DropdownMenuLabel className="text-[10px] uppercase font-bold text-zinc-400 mt-2">Por Setlist Ativo</DropdownMenuLabel>
                                        {setlists.slice(0, 5).map(s => (
                                            <DropdownMenuItem key={s.id} className="rounded-lg py-3 cursor-pointer" onClick={() => handleGenerateEcad("SETLIST", s.id)}>
                                                <FolderOpen className="mr-2 h-4 w-4" />
                                                {s.title}
                                            </DropdownMenuItem>
                                        ))}
                                    </>
                                )}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>
                </div>
            </div>

            {/* Upload Form */}
            <div className="lg:col-span-1">
                <form onSubmit={handleUpload} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 sticky top-6">
                    <h2 className="text-xl font-bold text-foreground mb-6">Novo Documento</h2>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Título</label>
                            <input
                                type="text"
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                required
                                placeholder="Ex: CND Federal 2026"
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Categoria</label>
                            <select
                                value={category}
                                onChange={(e) => setCategory(e.target.value)}
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                            >
                                <option value="CND">Certidão Negativa (CND)</option>
                                <option value="IDENTIFICACAO">Documento Pessoal (RG/CNH)</option>
                                <option value="CONTRATO">Contrato / Estatuto</option>
                                <option value="RIDER_CAMARIM">Rider de Camarim</option>
                                <option value="ECAD">Documentação ECAD</option>
                                <option value="OUTROS">Outros</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Membro (Opcional)</label>
                            <select
                                value={memberId}
                                onChange={(e) => setMemberId(e.target.value)}
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                            >
                                <option value="">Pertence à Banda</option>
                                {members.map(m => (
                                    <option key={m.id} value={m.id}>{m.user.name}</option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Data de Validade (Opcional)</label>
                            <input
                                type="date"
                                value={expiryDate}
                                onChange={(e) => setExpiryDate(e.target.value)}
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Arquivo PDF/Imagem</label>
                            <input
                                type="file"
                                onChange={(e) => setFile(e.target.files?.[0] || null)}
                                required
                                accept=".pdf,.jpg,.jpeg,.png"
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2 text-sm outline-none file:mr-4 file:rounded-xl file:border-0 file:bg-secondary/10 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-secondary hover:file:bg-secondary/20"
                            />
                        </div>

                        <button
                            type="submit"
                            disabled={isUploading || !file}
                            className="w-full flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-sm font-semibold text-white hover:opacity-90 transition-colors mt-2 disabled:opacity-50"
                        >
                            <Upload className="h-4 w-4" />
                            {isUploading ? "Enviando..." : "Enviar Documento"}
                        </button>
                    </div>
                </form>
            </div>

            <div className="lg:col-span-2 space-y-4">
                {documents.length === 0 ? (
                    <div className="rounded-3xl bg-white p-12 text-center text-zinc-500 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <FolderOpen className="mx-auto h-12 w-12 text-zinc-300 dark:text-zinc-700 mb-4" />
                        <h3 className="font-medium text-lg text-foreground mb-1">Seu Drive está vazio</h3>
                        <p>Faça upload de CNDs e documentos da banda.</p>
                    </div>
                ) : (
                    [...documents].sort((a, b) => {
                        const aExpired = isExpired(a.expiryDate);
                        const bExpired = isExpired(b.expiryDate);
                        const aExpiring = isExpiringSoon(a.expiryDate);
                        const bExpiring = isExpiringSoon(b.expiryDate);

                        if (aExpired && !bExpired) return -1;
                        if (!aExpired && bExpired) return 1;
                        if (aExpiring && !bExpiring) return -1;
                        if (!aExpiring && bExpiring) return 1;

                        // If both have dates but aren't urgent, sort by soonest
                        if (a.expiryDate && b.expiryDate) {
                            return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
                        }
                        return 0;
                    }).map(doc => {
                        const expired = isExpired(doc.expiryDate);
                        const expiring = isExpiringSoon(doc.expiryDate);

                        return (
                            <div key={doc.id} className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all hover:shadow-md">
                                <div className="flex items-center gap-4">
                                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 shrink-0">
                                        {getCategoryIcon(doc.category)}
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-foreground pr-4 flex items-center gap-2">
                                            <a href={doc.fileUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">
                                                {doc.title}
                                            </a>
                                            {doc.member && (
                                                <span className="text-xs font-normal bg-zinc-100 dark:bg-zinc-800 text-zinc-500 px-2 py-0.5 rounded-full">
                                                    {doc.member.user.name}
                                                </span>
                                            )}
                                        </h3>
                                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                                            <span className="text-xs font-medium text-zinc-500 uppercase tracking-wider">
                                                {getCategoryName(doc.category)}
                                            </span>

                                            {doc.expiryDate && (
                                                <>
                                                    <span className="text-zinc-300 dark:text-zinc-700">•</span>
                                                    <span className={`text-xs font-semibold flex items-center gap-1
                                                        ${expired ? 'text-red-500' : expiring ? 'text-amber-500' : 'text-secondary'}
                                                    `}>
                                                        {(expired || expiring) && <AlertCircle className="h-3 w-3" />}
                                                        {expired ? 'Vencido' : 'Vence em'}: {new Date(doc.expiryDate).toLocaleDateString('pt-BR')}
                                                    </span>
                                                </>
                                            )}
                                        </div>
                                    </div>
                                </div>

                                <div className="flex items-center gap-2 shrink-0">
                                    <a
                                        href={doc.fileUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="rounded-xl px-4 py-2 bg-zinc-100 dark:bg-zinc-800 text-sm font-semibold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                                    >
                                        Abrir / PDF
                                    </a>
                                    <button
                                        onClick={() => handleDelete(doc.id)}
                                        className="rounded-xl p-2 text-zinc-400 hover:bg-zinc-100 hover:text-red-500 dark:hover:bg-zinc-800 transition-colors"
                                        title="Excluir documento"
                                    >
                                        <Trash2 className="h-5 w-5" />
                                    </button>
                                </div>
                            </div>
                        );
                    })
                )}
            </div>
        </div>
    );
}
