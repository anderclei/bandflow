"use client"

import { useState } from "react"
import { Globe, Save, Instagram, Youtube, Music, Link as LinkIcon, Camera, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { updateEpkData } from "@/app/actions/bands"
import { useRouter } from "next/navigation"

export default function EpkEditorClient({ band }: { band: any }) {
    const router = useRouter()
    const [isSaving, setIsSaving] = useState(false)
    const [copied, setCopied] = useState(false)

    const parsedLinks = band.socialLinks ? JSON.parse(band.socialLinks) : { instagram: '', youtube: '', spotify: '' }

    const [formData, setFormData] = useState({
        shortBio: band.shortBio || "",
        videoUrl: band.videoUrl || "",
        instagram: parsedLinks.instagram || "",
        youtube: parsedLinks.youtube || "",
        spotify: parsedLinks.spotify || ""
    })

    const epkUrl = typeof window !== 'undefined' ? `${window.location.origin}/epk/${band.slug}` : `/epk/${band.slug}`

    const handleCopy = () => {
        navigator.clipboard.writeText(epkUrl)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
    }

    const handleSave = async () => {
        setIsSaving(true)
        const socialLinks = JSON.stringify({
            instagram: formData.instagram,
            youtube: formData.youtube,
            spotify: formData.spotify
        })

        await updateEpkData(band.id, {
            shortBio: formData.shortBio,
            videoUrl: formData.videoUrl,
            socialLinks
        })

        setIsSaving(false)
        router.refresh()
    }

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between bg-zinc-100 dark:bg-zinc-900 p-6 rounded-3xl ring-1 ring-zinc-200 dark:ring-zinc-800">
                <div>
                    <h2 className="text-sm font-bold tracking-widest uppercase text-zinc-500 mb-1">Seu Link Público</h2>
                    <div className="flex items-center gap-2">
                        <code className="text-secondary font-bold text-lg">{epkUrl}</code>
                    </div>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" onClick={handleCopy} className="gap-2">
                        {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
                        {copied ? "Copiado!" : "Copiar Link"}
                    </Button>
                    <a href={epkUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 h-10 px-4 py-2 bg-secondary text-white hover:brightness-90 gap-2">
                        <Globe className="h-4 w-4" />
                        Acessar EPK
                    </a>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Sobre / Release */}
                <div className="space-y-6">
                    <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                            <Camera className="h-5 w-5 text-secondary" />
                            Apresentação & Release
                        </h2>

                        <div className="space-y-6">
                            <div className="space-y-2">
                                <Label>Biografia Resumida (Release)</Label>
                                <Textarea
                                    className="min-h-[150px] bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700"
                                    placeholder="Escreva um breve resumo sobre a banda, estilo musical e conquistas..."
                                    value={formData.shortBio}
                                    onChange={(e) => setFormData({ ...formData, shortBio: e.target.value })}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label>Vídeo de Destaque (Link do YouTube)</Label>
                                <Input
                                    className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700"
                                    placeholder="https://youtube.com/watch?v=..."
                                    value={formData.videoUrl}
                                    onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                                />
                                <p className="text-xs text-zinc-500">Cole o link completo do vídeo mais profissional da banda.</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Redes Sociais */}
                <div className="space-y-6">
                    <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                            <LinkIcon className="h-5 w-5 text-amber-500" />
                            Redes Sociais & Perfis
                        </h2>

                        <div className="space-y-4">
                            <div className="space-y-2">
                                <Label className="flex items-center gap-2">
                                    <Instagram className="h-4 w-4 text-pink-500" /> Instagram
                                </Label>
                                <Input
                                    className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 font-mono text-sm"
                                    placeholder="https://instagram.com/suabanda"
                                    value={formData.instagram}
                                    onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label className="flex items-center gap-2">
                                    <Youtube className="h-4 w-4 text-red-500" /> Canal do YouTube
                                </Label>
                                <Input
                                    className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 font-mono text-sm"
                                    placeholder="https://youtube.com/@suabanda"
                                    value={formData.youtube}
                                    onChange={(e) => setFormData({ ...formData, youtube: e.target.value })}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label className="flex items-center gap-2">
                                    <Music className="h-4 w-4 text-emerald-500" /> Perfil no Spotify
                                </Label>
                                <Input
                                    className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 font-mono text-sm"
                                    placeholder="Link do perfil do artista"
                                    value={formData.spotify}
                                    onChange={(e) => setFormData({ ...formData, spotify: e.target.value })}
                                />
                            </div>
                        </div>

                        <Button
                            onClick={handleSave}
                            disabled={isSaving}
                            className="w-full mt-8 bg-zinc-900 text-white hover:bg-zinc-800 h-12 rounded-xl font-bold gap-2 dark:bg-white dark:text-black dark:hover:bg-zinc-200"
                        >
                            {isSaving ? "Salvando..." : <><Save className="h-4 w-4" /> Salvar Configurações do EPK</>}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}
