import { getActiveBand } from "@/lib/getActiveBand";
import { createExpense, deleteExpense } from "@/app/actions/expenses";
import { DollarSign, Plus, Trash2, TrendingUp, TrendingDown, PiggyBank, Calendar as CalendarIcon, BarChart3, Download, ListTodo, Wallet, Calculator } from "lucide-react";
import { redirect } from "next/navigation";
import { FinanceChart } from "@/components/dashboard/FinanceChart";
import { getDREAnalytics, getCashFlow } from "@/app/actions/financials";
import { DREDashboard } from "@/components/dashboard/financial/DREDashboard";
import { TransactionList } from "@/components/dashboard/financial/TransactionList";
import { SplitCalculator } from "@/components/dashboard/financial/SplitCalculator";
import { AccountsDashboard } from "@/components/dashboard/financial/AccountsDashboard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default async function FinancePage() {
    const { band } = await getActiveBand({
        gigs: true,
        expenses: { orderBy: { date: 'desc' } }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const gigs = band?.gigs || [];
    const expenses = (band as any)?.expenses || [];

    // --- Analytics for DRE ---
    const now = new Date();
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    const dreRes = await getDREAnalytics(band.id, firstDayOfMonth, lastDayOfMonth);
    const cashFlowRes = await getCashFlow(band.id);

    const grossIncome = gigs.reduce((acc: number, gig: any) => acc + (gig.fee || 0), 0);
    const totalTaxes = gigs.reduce((acc: number, gig: any) => {
        const rateTax = gig.fee && gig.taxRate ? gig.fee * (gig.taxRate / 100) : 0;
        const fixedTax = gig.taxAmount || 0;
        return acc + rateTax + fixedTax;
    }, 0);
    const netIncome = grossIncome - totalTaxes;
    const totalExpenses = expenses.reduce((acc: number, expense: any) => acc + expense.amount, 0);

    const balance = netIncome - totalExpenses;

    const formatCurrency = (value: number) => {
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    // Prepare chart data (group by Month)
    const monthlyData: Record<string, { Entradas: number; Saídas: number }> = {};

    // Process Gigs (Income)
    gigs.forEach((gig: any) => {
        if (!gig.fee) return;
        const month = new Date(gig.date).toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
        if (!monthlyData[month]) monthlyData[month] = { Entradas: 0, Saídas: 0 };
        const rateTax = gig.fee && gig.taxRate ? gig.fee * (gig.taxRate / 100) : 0;
        const fixedTax = gig.taxAmount || 0;
        monthlyData[month].Entradas += (gig.fee - rateTax - fixedTax);
    });

    // Process Expenses
    expenses.forEach((expense: any) => {
        const month = new Date(expense.date).toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
        if (!monthlyData[month]) monthlyData[month] = { Entradas: 0, Saídas: 0 };
        monthlyData[month].Saídas += expense.amount;
    });

    const chartData = Object.entries(monthlyData)
        .map(([name, data]) => ({ name, ...data }))
        .sort((a, b) => new Date(`1 ${a.name}`).getTime() - new Date(`1 ${b.name}`).getTime());


    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <DollarSign className="h-8 w-8 text-secondary" />
                        Gestão Financeira
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Acompanhe lucros e despesas de {band.name}.
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <a
                        href={`/api/bands/${band.id}/finance/export`}
                        download
                        className="inline-flex items-center gap-2 rounded-xl bg-zinc-900 px-4 py-2 text-sm font-bold text-white hover:bg-zinc-800 transition-all dark:bg-white dark:text-black dark:hover:bg-zinc-200"
                    >
                        <Download className="h-4 w-4" />
                        Exportar CSV
                    </a>
                </div>
            </div>

            <div className="flex bg-white/50 dark:bg-zinc-900/50 p-1.5 rounded-2xl w-fit self-center sm:self-start ring-1 ring-zinc-200 dark:ring-zinc-800">
                <p className="px-4 py-2 text-sm font-bold text-secondary">Controladoria BandFlow</p>
            </div>

            <Tabs defaultValue="overview" className="space-y-8">
                <TabsList className="bg-white dark:bg-zinc-900 p-1 rounded-2xl border border-zinc-200 dark:border-zinc-800 h-auto gap-1">
                    <TabsTrigger value="overview" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-secondary data-[state=active]:text-white">
                        Visão Geral
                    </TabsTrigger>
                    <TabsTrigger value="dre" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-secondary data-[state=active]:text-white">
                        DRE Estratégico
                    </TabsTrigger>
                    <TabsTrigger value="accounts" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-secondary data-[state=active]:text-white">
                        Contas a Pagar/Receber
                    </TabsTrigger>
                    <TabsTrigger value="expenses" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-secondary data-[state=active]:text-white">
                        Lançamentos
                    </TabsTrigger>
                    <TabsTrigger value="splits" className="rounded-xl px-6 py-2.5 data-[state=active]:bg-secondary data-[state=active]:text-white">
                        Calculadora de Splits
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-8">
                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <div className="flex items-center gap-x-3">
                                <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                                    <TrendingUp className="h-5 w-5" />
                                </div>
                                <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">Cachês Totais</p>
                            </div>
                            <p className="mt-4 text-3xl font-bold text-foreground">{formatCurrency(grossIncome)}</p>
                            <p className="text-[10px] text-zinc-500 mt-1 uppercase font-bold tracking-wider italic opacity-60">Histórico Acumulado</p>
                        </div>

                        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <div className="flex items-center gap-x-3">
                                <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-950/30 text-amber-600">
                                    <DollarSign className="h-5 w-5" />
                                </div>
                                <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">Despesas & Taxas</p>
                            </div>
                            <p className="mt-4 text-3xl font-bold text-foreground">{formatCurrency(totalTaxes + totalExpenses)}</p>
                            <p className="text-[10px] text-zinc-500 mt-1 uppercase font-bold tracking-wider italic opacity-60">Operacional + Administrativo</p>
                        </div>

                        <div className="rounded-3xl bg-secondary/10 p-6 shadow-sm ring-1 ring-secondary/20">
                            <div className="flex items-center gap-x-3 text-secondary">
                                <div className="p-2 rounded-xl bg-secondary/20 text-secondary">
                                    <PiggyBank className="h-5 w-5" />
                                </div>
                                <p className="text-sm font-semibold opacity-80">Lucro Real Disponível</p>
                            </div>
                            <p className="mt-4 text-3xl font-bold text-foreground">{formatCurrency(balance)}</p>
                            <p className="text-[10px] text-secondary mt-1 uppercase font-bold tracking-wider">Margem: {((balance / (grossIncome || 1)) * 100).toFixed(1)}%</p>
                        </div>
                    </div>

                    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <div className="flex items-center justify-between mb-6">
                            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                                <BarChart3 className="h-5 w-5 text-emerald-500" />
                                Rendimento Mensal (Saldo Líquido)
                            </h2>
                        </div>
                        <FinanceChart data={chartData} />
                    </div>
                </TabsContent>

                <TabsContent value="dre" className="space-y-8 animate-in fade-in duration-500">
                    <div className="flex items-center justify-between mb-2">
                        <div>
                            <h2 className="text-2xl font-bold flex items-center gap-2">
                                <BarChart3 className="h-6 w-6 text-secondary" />
                                DRE Estratégico
                            </h2>
                            <p className="text-sm text-zinc-500">Lucratividade real baseada em todos os custos e comissões.</p>
                        </div>
                        <div className="text-right">
                            <p className="text-xs font-bold text-zinc-400 uppercase">Mês Atual</p>
                            <p className="text-sm font-bold text-foreground">{now.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</p>
                        </div>
                    </div>
                    {dreRes.data && <DREDashboard data={dreRes.data} />}
                </TabsContent>

                <TabsContent value="accounts" className="space-y-8 animate-in fade-in duration-500">
                    {cashFlowRes.transactions && (
                        <AccountsDashboard transactions={cashFlowRes.transactions as any[]} bandId={band.id} />
                    )}
                </TabsContent>

                <TabsContent value="expenses" className="space-y-8 animate-in fade-in duration-500">
                    <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
                        <div className="lg:col-span-1">
                            <div className="sticky top-8 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                                <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                                    <Plus className="h-5 w-5 text-secondary" />
                                    Nova Despesa
                                </h2>
                                <form action={createExpense} className="space-y-4">
                                    <div>
                                        <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Descrição</label>
                                        <input
                                            name="description"
                                            required
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                            placeholder="Ex: Combustível Van"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Valor (R$)</label>
                                        <input
                                            name="amount"
                                            type="number"
                                            step="0.01"
                                            required
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                            placeholder="0.00"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Data</label>
                                        <input
                                            name="date"
                                            type="date"
                                            required
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Categoria (Opcional)</label>
                                        <input
                                            name="category"
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                            placeholder="Ex: Logística"
                                        />
                                    </div>
                                    <button
                                        type="submit"
                                        className="w-full rounded-xl bg-zinc-900 py-3 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors shadow-sm dark:bg-white dark:text-black dark:hover:bg-zinc-200"
                                    >
                                        Registrar Despesa
                                    </button>
                                </form>
                            </div>
                        </div>

                        <div className="lg:col-span-2 space-y-4">
                            <h2 className="text-xl font-bold text-foreground">Geral de Movimentações</h2>
                            {expenses.length > 0 ? (
                                <div className="rounded-3xl bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 overflow-hidden">
                                    <table className="w-full text-left font-medium">
                                        <thead className="bg-zinc-50 dark:bg-zinc-800/50 text-zinc-500 dark:text-zinc-400 text-xs uppercase font-bold">
                                            <tr>
                                                <th className="px-6 py-4">Descrição</th>
                                                <th className="px-6 py-4">Data</th>
                                                <th className="px-6 py-4 text-right">Valor</th>
                                                <th className="px-6 py-4"></th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
                                            {expenses.map((expense: any) => (
                                                <tr key={expense.id} className="group hover:bg-zinc-50 dark:hover:bg-zinc-800/30 transition-colors">
                                                    <td className="px-6 py-4">
                                                        <div className="flex flex-col">
                                                            <span className="text-foreground">{expense.description}</span>
                                                            {expense.category && <span className="text-[10px] uppercase text-zinc-400">{expense.category}</span>}
                                                        </div>
                                                    </td>
                                                    <td className="px-6 py-4 text-zinc-500 dark:text-zinc-400 text-sm">
                                                        {new Date(expense.date).toLocaleDateString('pt-BR')}
                                                    </td>
                                                    <td className="px-6 py-4 text-red-600 dark:text-red-400 text-sm text-right font-bold">
                                                        -{formatCurrency(expense.amount)}
                                                    </td>
                                                    <td className="px-6 py-4 text-right">
                                                        <form action={async () => {
                                                            "use server";
                                                            await deleteExpense(expense.id);
                                                        }}>
                                                            <button className="p-2 text-zinc-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
                                                                <Trash2 className="h-4 w-4" />
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : (
                                <div className="rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                                    <div className="inline-flex p-4 rounded-full bg-zinc-100 dark:bg-zinc-800/50 text-zinc-400 mb-4">
                                        <DollarSign className="h-8 w-8" />
                                    </div>
                                    <h3 className="text-lg font-bold text-foreground">Nenhuma despesa registrada</h3>
                                </div>
                            )}
                        </div>
                    </div>
                </TabsContent>

                <TabsContent value="splits" className="space-y-8 animate-in fade-in duration-500">
                    <div className="flex items-center justify-between mb-4">
                        <div>
                            <h2 className="text-2xl font-bold flex items-center gap-2">
                                <Calculator className="h-6 w-6 text-secondary" />
                                Calculadora de Splits
                            </h2>
                            <p className="text-sm text-zinc-500">Simule a divisão de cachês e lucro entre a equipe.</p>
                        </div>
                    </div>
                    <SplitCalculator />
                </TabsContent>
            </Tabs>
        </div>
    );
}
