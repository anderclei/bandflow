import { getActiveBand } from "@/lib/getActiveBand";
import { createGig, deleteGig } from "@/app/actions/gigs";
import { Calendar as CalendarIcon, MapPin, Plus, Trash2, Clock, DollarSign, FileText, Beaker } from "lucide-react";
import { redirect } from "next/navigation";
import Link from "next/link";
import { GigContract } from "@/components/dashboard/GigContract";
import { createTestGig } from "@/app/actions/test-data";
import { FreightCalculator } from "@/components/dashboard/FreightCalculator";
import { prisma } from "@/lib/prisma";

export default async function GigsPage() {
    const { band } = await getActiveBand({
        gigs: { orderBy: { date: 'asc' } },
        setlists: { orderBy: { title: 'asc' } }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const gigs = (band as any).gigs || [];
    const setlists = (band as any).setlists || [];

    // Buscar fornecedores de logística e cidade base da banda
    const suppliers = await (prisma as any).logisticsSupplier.findMany({
        where: { bandId: band.id },
        orderBy: { name: 'asc' },
    });
    const [bandRaw] = await prisma.$queryRawUnsafe<any[]>(
        `SELECT addressCity FROM Band WHERE id = ? LIMIT 1`, band.id
    );
    const bandCity: string = bandRaw?.addressCity || "";

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                        <CalendarIcon className="h-8 w-8 text-secondary" />
                        Agenda de Shows
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie suas datas, locais e cachês em um só lugar.
                    </p>
                </div>
                <div className="flex gap-3">
                    <form action={createTestGig}>
                        <button
                            type="submit"
                            className="flex items-center gap-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 px-4 py-2.5 text-sm font-bold hover:bg-secondary/10 hover:text-secondary transition-all ring-1 ring-zinc-200 dark:ring-zinc-700 hover:ring-secondary/30"
                        >
                            <Beaker className="h-4 w-4" />
                            Gerar Show de Teste
                        </button>
                    </form>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
                {/* Form to add gig */}
                <div className="lg:col-span-1">
                    <div className="sticky top-8 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                            <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                                <Plus className="h-4 w-4" />
                            </div>
                            Novo Evento
                        </h2>
                        <form action={createGig} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Título do Evento</label>
                                <input
                                    name="title"
                                    required
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                    placeholder="Ex: Show no SESC"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Data</label>
                                <input
                                    name="date"
                                    type="datetime-local"
                                    required
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Local</label>
                                <input
                                    name="location"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                    placeholder="Ex: Rua das Flores, 123"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Cachê Bruto (R$)</label>
                                    <input
                                        name="fee"
                                        type="number"
                                        step="0.01"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                        placeholder="0.00"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Imposto (%)</label>
                                    <input
                                        name="taxRate"
                                        type="number"
                                        step="0.1"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                        placeholder="6.0"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Dedução Fixa (R$)</label>
                                <input
                                    name="taxAmount"
                                    type="number"
                                    step="0.01"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                    placeholder="0.00"
                                />
                            </div>

                            <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800">
                                <h4 className="text-sm font-bold text-foreground mb-4">Cronograma (Opcional)</h4>
                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-xs font-medium text-zinc-500 mb-1">Horário de Chegada (Load-in)</label>
                                        <input
                                            name="loadIn"
                                            type="datetime-local"
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-medium text-zinc-500 mb-1">Passagem de Som</label>
                                        <input
                                            name="soundcheck"
                                            type="datetime-local"
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-medium text-zinc-500 mb-1">Início do Show (Showtime)</label>
                                        <input
                                            name="showtime"
                                            type="datetime-local"
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                        />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Setlist Associado</label>
                                <select
                                    name="setlistId"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                                >
                                    <option value="">Nenhum</option>
                                    {setlists.map((s: any) => (
                                        <option key={s.id} value={s.id}>{s.title}</option>
                                    ))}
                                </select>
                            </div>
                            <button
                                type="submit"
                                className="w-full rounded-xl bg-secondary text-white py-3 font-semibold hover:bg-secondary/90 transition-colors shadow-sm"
                            >
                                Agendar Evento
                            </button>
                        </form>
                    </div>

                    {/* Calculadora de Frete */}
                    <FreightCalculator
                        suppliers={suppliers as any}
                        bandCity={bandCity}
                    />
                </div>

                {/* List of gigs */}
                <div className="lg:col-span-2 space-y-4">
                    {gigs.length > 0 ? (
                        <div className="grid gap-4">
                            {gigs.map((gig: any) => (
                                <div key={gig.id} className="group relative rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 hover:ring-primary/30 transition-all">
                                    <div className="flex flex-col sm:flex-row gap-6">
                                        <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-secondary/10 text-secondary min-w-[80px]">
                                            <span className="text-2xl font-black">{new Date(gig.date).getDate()}</span>
                                            <span className="text-xs uppercase font-bold">{new Date(gig.date).toLocaleDateString('pt-BR', { month: 'short' })}</span>
                                            <span className="text-[10px] mt-1 opacity-60">{new Date(gig.date).getFullYear()}</span>
                                        </div>
                                        <div className="flex-1 space-y-3">
                                            <div className="flex items-start justify-between">
                                                <Link href={`/dashboard/gigs/${gig.id}`} className="block group/title">
                                                    <h3 className="text-xl font-bold text-foreground group-hover/title:text-secondary transition-colors">{gig.title}</h3>
                                                </Link>
                                                <div className="flex gap-2">
                                                    <GigContract gig={gig} bandName={band?.name as string} />
                                                    <form action={async () => {
                                                        "use server";
                                                        await deleteGig(gig.id);
                                                    }}>
                                                        <button className="p-2 text-zinc-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                                                            <Trash2 className="h-4 w-4" />
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-4 text-sm">
                                                <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400">
                                                    <Clock className="h-4 w-4 text-secondary" />
                                                    {new Date(gig.date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                                                </div>
                                                <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400">
                                                    <MapPin className="h-4 w-4 text-secondary" />
                                                    <span className="truncate">{gig.location || "Local não definido"}</span>
                                                </div>
                                                <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400">
                                                    <DollarSign className="h-4 w-4 text-secondary" />
                                                    {gig.fee ? `R$ ${gig.fee.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : "Cachê não definido"}
                                                </div>
                                                <div className="flex items-center gap-2 text-zinc-600 dark:text-zinc-400">
                                                    <FileText className="h-4 w-4 text-secondary" />
                                                    {gig.setlistId ? "Setlist vinculado" : "Sem setlist"}
                                                </div>
                                            </div>

                                            {/* Itinerary Section */}
                                            {(gig.loadIn || gig.soundcheck || gig.showtime || gig.notes) && (
                                                <div className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-800">
                                                    <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-3">Cronograma & Notas</h4>
                                                    <div className="flex flex-wrap gap-4 text-sm">
                                                        {gig.loadIn && (
                                                            <div className="flex items-center gap-2">
                                                                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                                                                <span className="text-zinc-500">Load-in:</span>
                                                                <span className="font-medium text-foreground">{new Date(gig.loadIn).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                                                            </div>
                                                        )}
                                                        {gig.soundcheck && (
                                                            <div className="flex items-center gap-2">
                                                                <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                                                                <span className="text-zinc-500">Passagem de som:</span>
                                                                <span className="font-medium text-foreground">{new Date(gig.soundcheck).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                                                            </div>
                                                        )}
                                                        {gig.showtime && (
                                                            <div className="flex items-center gap-2">
                                                                <span className="w-2 h-2 rounded-full bg-secondary"></span>
                                                                <span className="text-zinc-500">Showtime:</span>
                                                                <span className="font-medium text-foreground">{new Date(gig.showtime).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                                                            </div>
                                                        )}
                                                    </div>
                                                    {gig.notes && (
                                                        <p className="mt-3 text-sm text-zinc-600 dark:text-zinc-400 bg-zinc-50 dark:bg-zinc-800/50 p-3 rounded-xl">
                                                            {gig.notes}
                                                        </p>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>

                            ))}
                        </div>
                    ) : (
                        <div className="rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <div className="inline-flex p-4 rounded-full bg-secondary/10 text-secondary mb-4">
                                <CalendarIcon className="h-8 w-8" />
                            </div>
                            <h3 className="text-lg font-bold text-foreground">Agenda vazia</h3>
                            <p className="mt-2 text-zinc-500">Agende seu primeiro show para começar a gerenciar sua banda.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
