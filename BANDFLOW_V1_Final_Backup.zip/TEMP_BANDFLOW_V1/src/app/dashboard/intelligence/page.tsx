import { getActiveBand } from "@/lib/getActiveBand";
import { getBIAnalytics, getCommercialFunnel, getGeographicDistribution } from "@/app/actions/analytics";
import { getRehiringRecommendations } from "@/app/actions/crm";
import { BarChart3, TrendingUp, Users, MapPin, Target, ArrowUpRight, Award, Briefcase, Globe, MessageSquare, Sparkles, FileSearch, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

export default async function IntelligencePage() {
    const { band } = await getActiveBand();

    if (!band) return null;

    const biRes = await getBIAnalytics(band.id);
    const funnelRes = await getCommercialFunnel(band.id);
    const geoRes = await getGeographicDistribution(band.id);
    const recommendations = await getRehiringRecommendations(band.id);


    const formatCurrency = (value: number) => {
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    return (
        <div className="space-y-8 animate-in fade-in duration-700 pb-12">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Target className="h-8 w-8 text-secondary" />
                        Inteligência Comercial & BI
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Insights estratégicos sobre performance, cidades e funil de vendas.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <p className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Ticket Médio (Ganhos)</p>
                    <p className="text-2xl font-black text-foreground">{formatCurrency(funnelRes.data?.averageTicket || 0)}</p>
                    <div className="mt-2 flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded-full w-fit">
                        <TrendingUp className="h-3 w-3" />
                        ALTA PERFORMANCE
                    </div>
                </div>

                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <p className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Taxa de Conversão</p>
                    <p className="text-2xl font-black text-foreground">{(funnelRes.data?.conversionRate || 0).toFixed(1)}%</p>
                    <p className="text-[10px] text-zinc-400 mt-1 uppercase font-bold">Propostas vs Fechados</p>
                </div>

                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <p className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Total de Leads</p>
                    <p className="text-2xl font-black text-foreground">{funnelRes.data?.LEAD || 0}</p>
                    <p className="text-[10px] text-zinc-400 mt-1 uppercase font-bold">Oportunidades Ativas</p>
                </div>

                <div className="rounded-3xl bg-secondary/10 p-6 shadow-sm ring-1 ring-secondary/20">
                    <p className="text-xs font-bold text-secondary opacity-80 uppercase tracking-wider mb-2">Volume Comercial</p>
                    <p className="text-2xl font-black text-foreground">{formatCurrency(funnelRes.data?.totalValue || 0)}</p>
                    <p className="text-[10px] text-secondary opacity-70 mt-1 uppercase font-bold">Pipeline Total</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Ranking de Cidades */}
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <MapPin className="h-5 w-5 text-secondary" />
                        Top Cidades (Lucro Real)
                    </h2>
                    <div className="space-y-4">
                        {biRes.data?.topCities.map((city, index) => (
                            <div key={city.name} className="flex items-center justify-between p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 hover:scale-[1.02] transition-transform">
                                <div className="flex items-center gap-3">
                                    <span className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-white text-xs font-bold">
                                        #{index + 1}
                                    </span>
                                    <div>
                                        <p className="text-sm font-bold text-foreground">{city.name}</p>
                                        <p className="text-xs text-zinc-500">{city.count} Shows</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm font-bold text-emerald-600">{formatCurrency(city.netProfit)}</p>
                                    <p className="text-[10px] uppercase font-bold text-zinc-400">Lucro Líquido</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Ranking de Formatos */}
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <Award className="h-5 w-5 text-amber-500" />
                        Formatos Mais Rentáveis
                    </h2>
                    <div className="space-y-4">
                        {biRes.data?.topFormats.map((format, index) => (
                            <div key={format.name} className="flex items-center justify-between p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 hover:scale-[1.02] transition-transform">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-950/30 text-amber-600">
                                        <BarChart3 className="h-4 w-4" />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-foreground">{format.name}</p>
                                        <p className="text-xs text-zinc-500">Média: {formatCurrency(format.netProfit / format.count)} / show</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm font-bold text-foreground">{formatCurrency(format.netProfit)}</p>
                                    <p className="text-[10px] uppercase font-bold text-zinc-400">Lucro Total</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Ranking de Contratantes */}
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <Briefcase className="h-5 w-5 text-indigo-500" />
                        Melhores Contratantes
                    </h2>
                    <div className="space-y-4">
                        {biRes.data?.topContractors.map((contractor, index) => (
                            <div key={contractor.name} className="flex items-center justify-between p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 hover:scale-[1.02] transition-transform">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 rounded-xl bg-indigo-100 dark:bg-indigo-950/30 text-indigo-600">
                                        <Users className="h-4 w-4" />
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-foreground truncate max-w-[120px]">{contractor.name}</p>
                                        <p className="text-xs text-zinc-500">{contractor.count} Contratos</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-sm font-bold text-indigo-600">{formatCurrency(contractor.revenue)}</p>
                                    <p className="text-[10px] uppercase font-bold text-zinc-400">Total Transacionado</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Heatmap/Geo Simplified */}
                <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                        <Globe className="h-5 w-5 text-blue-500" />
                        Distribuição Geográfica (Estados)
                    </h2>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                        {Object.entries(geoRes.data || {}).sort((a, b) => (b[1] as any) - (a[1] as any)).map(([state, count]) => (
                            <div key={state} className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 text-center">
                                <p className="text-2xl font-black text-secondary">{state}</p>
                                <p className="text-[10px] font-bold text-zinc-400 uppercase">{count as any} Shows</p>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Funil Visual (Simplified) */}
                <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2 text-center justify-center">
                        Fluxo de Conversão Comercial
                    </h2>
                    <div className="flex flex-col items-center gap-2">
                        <div className="w-full bg-zinc-100 dark:bg-zinc-800 rounded-2xl p-4 text-center relative overflow-hidden group">
                            <div className="relative z-10 flex items-center justify-between px-8">
                                <span className="font-bold text-zinc-500">Leads</span>
                                <span className="text-xl font-black">{funnelRes.data?.LEAD}</span>
                            </div>
                            <div className="absolute inset-0 bg-secondary/5 group-hover:bg-secondary/10 transition-colors"></div>
                        </div>
                        <div className="w-[85%] bg-zinc-100 dark:bg-zinc-800 rounded-2xl p-4 text-center relative overflow-hidden group">
                            <div className="relative z-10 flex items-center justify-between px-8">
                                <span className="font-bold text-zinc-500">Negociação</span>
                                <span className="text-xl font-black">{funnelRes.data?.NEGOTIATING}</span>
                            </div>
                            <div className="absolute inset-0 bg-secondary/10 group-hover:bg-secondary/20 transition-colors"></div>
                        </div>
                        <div className="w-[70%] bg-secondary rounded-2xl p-4 text-center shadow-lg shadow-secondary/20 relative overflow-hidden">
                            <div className="relative z-10 flex items-center justify-between px-8 text-white">
                                <span className="font-bold">Ganhos</span>
                                <span className="text-2xl font-black">{funnelRes.data?.WON}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* CRM Proativo / IA Section */}
            <div className="rounded-3xl bg-secondary/5 dark:bg-secondary/10 p-8 shadow-sm ring-1 ring-secondary/20 border-l-4 border-secondary overflow-hidden relative group">
                <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Sparkles className="h-32 w-32 text-secondary" />
                </div>

                <div className="relative z-10">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2 rounded-xl bg-secondary/20 text-secondary">
                            <Sparkles className="h-6 w-6" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold text-foreground">CRM Proativo: IA de Recontratação</h2>
                            <p className="text-sm text-zinc-500 dark:text-zinc-400">Clientes que não contratam há mais de 6 meses.</p>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                        {recommendations.length === 0 ? (
                            <div className="col-span-full p-8 text-center bg-white dark:bg-zinc-800 rounded-2xl border border-secondary/20 text-zinc-500">
                                Nenhuma recomendação de recontratação no momento. Sua base está ativa!
                            </div>
                        ) : (
                            recommendations.map((rec: any) => (
                                <div key={rec.id} className="p-5 rounded-2xl bg-white dark:bg-zinc-800 border border-secondary/20 hover:border-secondary/50 transition-all group/item shadow-sm">
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h3 className="font-bold text-foreground text-lg">{rec.name}</h3>
                                            <p className="text-xs text-secondary font-bold uppercase tracking-widest">Inativo há {Math.floor((new Date().getTime() - new Date(rec.lastGigDate).getTime()) / (1000 * 60 * 60 * 24 * 30))} meses</p>
                                        </div>
                                    </div>

                                    <div className="space-y-2 mb-6 text-sm text-zinc-600 dark:text-zinc-400">
                                        <p className="flex items-center gap-2 italic">
                                            "Último show realizado em {new Date(rec.lastGigDate).toLocaleDateString('pt-BR')}"
                                        </p>
                                    </div>

                                    <div className="flex gap-2">
                                        <a
                                            href={`https://wa.me/${rec.phone?.replace(/\D/g, '')}`}
                                            target="_blank"
                                            className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-2 text-xs font-bold text-white hover:opacity-90 transition-opacity"
                                        >
                                            <MessageSquare className="h-3 w-3" />
                                            Gerar Proposta
                                        </a>
                                        <button className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary/10 text-secondary hover:bg-secondary/20 transition-colors">
                                            <ArrowUpRight className="h-4 w-4" />
                                        </button>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>

            {/* IA de Análise de Contratos Section */}
            <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 border-t-4 border-secondary overflow-hidden relative group">
                <div className="flex flex-col lg:flex-row gap-8">
                    <div className="flex-1">
                        <div className="flex items-center gap-3 mb-6">
                            <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                                <FileSearch className="h-6 w-6" />
                            </div>
                            <div>
                                <h2 className="text-2xl font-bold text-foreground">Análise de Contratos Externos via IA</h2>
                                <p className="text-sm text-zinc-500">Faça upload de contratos de terceiros (PDF/DOC) para identificar riscos e cláusulas abusivas.</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div className="p-12 border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-3xl flex flex-col items-center justify-center text-center group-hover:border-secondary/50 transition-colors">
                                <FileSearch className="h-12 w-12 text-zinc-300 mb-4" />
                                <p className="text-sm font-medium text-zinc-600 dark:text-zinc-400">Arraste o arquivo aqui ou <span className="text-secondary font-bold cursor-pointer">selecione do computador</span></p>
                                <p className="text-[10px] text-zinc-400 mt-2 uppercase font-bold tracking-widest">Suporta PDF, DOCX e Imagens</p>
                            </div>
                        </div>
                    </div>

                    <div className="w-full lg:w-[400px] space-y-4">
                        <div className="p-6 rounded-2xl bg-secondary/5 border border-secondary/10 h-full">
                            <h3 className="text-sm font-bold uppercase tracking-widest text-secondary mb-4 flex items-center gap-2">
                                <ShieldAlert className="h-4 w-4" />
                                Insights Blindagem Jurídica
                            </h3>
                            <div className="space-y-4">
                                <div className="p-3 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-100 dark:border-zinc-700">
                                    <p className="text-xs font-bold text-foreground">Cláusula de Rescisão</p>
                                    <p className="text-[10px] text-zinc-500 mt-1">Detectada multa abusiva acima de 30%.</p>
                                </div>
                                <div className="p-3 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-100 dark:border-zinc-700">
                                    <p className="text-xs font-bold text-foreground">Responsabilidade Civil</p>
                                    <p className="text-[10px] text-zinc-500 mt-1">Ausência de cláusula de limitação de danos técnicos.</p>
                                </div>
                                <div className="p-3 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-100 dark:border-zinc-700">
                                    <p className="text-xs font-bold text-foreground">Direito de Imagem</p>
                                    <p className="text-[10px] text-zinc-500 mt-1">Concessão perpétua detectada. Sugerimos limitação.</p>
                                </div>
                            </div>

                            <Button className="w-full mt-6 bg-secondary hover:brightness-90 text-white rounded-xl h-12 gap-2 shadow-lg shadow-secondary/20 border-0">
                                <Sparkles className="h-4 w-4" />
                                Analisar com BandAI Premium
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
