import { getActiveBand } from "@/lib/getActiveBand";
import { prisma } from "@/lib/prisma";
import { Plus, Trash2, Box, Guitar, Mic, Settings2, Cable, Package } from "lucide-react";
import { redirect } from "next/navigation";
import { createEquipment, deleteEquipment } from "@/app/actions/inventory";
import { cn } from "@/lib/utils";

const CategoryIcon = ({ type, className }: { type: string, className?: string }) => {
    switch (type) {
        case "Instrument": return <Guitar className={className} />;
        case "Microphone": return <Mic className={className} />;
        case "PA": return <Settings2 className={className} />;
        case "Cable": return <Cable className={className} />;
        default: return <Box className={className} />;
    }
};

export default async function InventoryPage() {
    const { band } = await getActiveBand({
        equipment: {
            include: { owner: { include: { user: true } }, formats: true },
            orderBy: { category: 'asc' }
        },
        members: {
            include: { user: true }
        },
        formats: true
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const equipment = (band.equipment as any[]) || [];
    const members = (band.members as any[]) || [];
    const formats = (band.formats as any[]) || [];

    const totalValue = equipment.reduce((acc, eq) => acc + (eq.value || 0), 0);

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Package className="h-8 w-8 text-secondary" />
                        Inventário & Patrimônio
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie os ativos da banda, números de série e valores segurados.
                    </p>
                </div>

                <div className="flex gap-4">
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl px-4 py-2 ring-1 ring-zinc-200 dark:ring-zinc-800 shadow-sm text-center">
                        <p className="text-xs text-zinc-500 font-medium">Itens</p>
                        <p className="text-xl font-bold">{equipment.length}</p>
                    </div>
                    <div className="bg-white dark:bg-zinc-900 rounded-2xl px-4 py-2 ring-1 ring-zinc-200 dark:ring-zinc-800 shadow-sm text-center">
                        <p className="text-xs text-zinc-500 font-medium">Patrimônio Total</p>
                        <p className="text-xl font-bold text-secondary">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalValue)}
                        </p>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
                {/* Form to add new equipment */}
                <div className="lg:col-span-1">
                    <div className="sticky top-8 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                            <Plus className="h-5 w-5 text-secondary" />
                            Novo Equipamento
                        </h2>

                        <form action={createEquipment.bind(null, band.id)} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Nome / Descrição</label>
                                <input
                                    name="name"
                                    required
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="Ex: Fender Stratocaster"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Categoria</label>
                                    <select
                                        name="category"
                                        required
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    >
                                        <option value="Instrument">Instrumento</option>
                                        <option value="Microphone">Microfone</option>
                                        <option value="Cable">Cabo</option>
                                        <option value="PA">P.A. / Monitor</option>
                                        <option value="Other">Outro</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Marca</label>
                                    <input
                                        name="brand"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="Ex: Shure"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Nº de Série</label>
                                    <input
                                        name="serialNumber"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="Opcional"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Valor (R$)</label>
                                    <input
                                        name="value"
                                        type="number"
                                        step="0.01"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="0.00"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Propriedade / Dono</label>
                                <select
                                    name="ownerId"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                >
                                    <option value="band">Banda (Coletivo)</option>
                                    {members.map(m => (
                                        <option key={m.id} value={m.id}>
                                            Pessoal ({m.user?.name})
                                        </option>
                                    ))}
                                </select>
                            </div>

                            {formats.length > 0 && (
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-2">Quais formatos usam este equipamento?</label>
                                    <div className="space-y-2 max-h-32 overflow-y-auto p-2 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl">
                                        {formats.map((f: any) => (
                                            <label key={f.id} className="flex items-center gap-2 text-sm text-zinc-700 dark:text-zinc-300">
                                                <input type="checkbox" name="formats" value={f.id} className="rounded border-zinc-300 text-secondary focus:ring-secondary/20" />
                                                <span>{f.name}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <button
                                type="submit"
                                className="w-full rounded-xl bg-zinc-900 py-3 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors shadow-sm dark:bg-white dark:text-black dark:hover:bg-zinc-200"
                            >
                                Adicionar
                            </button>
                        </form>
                    </div>
                </div>

                {/* List of equipment */}
                <div className="lg:col-span-2 space-y-4">
                    {
                        equipment.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {equipment.map((item: any) => (
                                    <div key={item.id} className="group flex flex-col h-full rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 hover:ring-secondary/50 dark:bg-zinc-900 dark:ring-zinc-800 dark:hover:ring-secondary/50 transition-all">
                                        <div className="flex justify-between items-start mb-4">
                                            <div className="flex items-center gap-3">
                                                <div className={`p-3 rounded-2xl ${item.status === 'AVAILABLE' ? 'bg-secondary/10 text-secondary' : 'bg-amber-100 text-amber-600 dark:bg-amber-900/30'}`}>
                                                    <CategoryIcon type={item.category} className="h-5 w-5" />
                                                </div>
                                                <div>
                                                    <h3 className="font-bold text-foreground group-hover:text-secondary transition-colors line-clamp-1">{item.name}</h3>
                                                    <div className="flex items-center gap-2 text-xs text-zinc-500 mt-0.5">
                                                        {item.brand && <span>{item.brand}</span>}
                                                        {item.brand && item.serialNumber && <span>•</span>}
                                                        {item.serialNumber && <span>SN: {item.serialNumber}</span>}
                                                    </div>
                                                </div>
                                            </div>

                                            <form action={async () => {
                                                "use server";
                                                await deleteEquipment(item.id);
                                            }}>
                                                <button
                                                    type="submit"
                                                    className="p-2 text-zinc-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                                                >
                                                    <Trash2 className="h-4 w-4" />
                                                </button>
                                            </form>
                                        </div>

                                        <div className="mt-auto space-y-3">
                                            {item.formats && item.formats.length > 0 && (
                                                <div className="flex flex-wrap gap-1 mb-2">
                                                    {item.formats.map((f: any) => (
                                                        <span key={f.id} className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-secondary/10 text-secondary dark:bg-secondary/20 dark:text-secondary">
                                                            {f.name}
                                                        </span>
                                                    ))}
                                                </div>
                                            )}
                                            <div className="flex items-center justify-between text-sm">
                                                <span className="text-zinc-500">Valor</span>
                                                <span className="font-medium text-foreground">
                                                    {item.value ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.value) : '--'}
                                                </span>
                                            </div>
                                            <div className="flex items-center justify-between text-sm">
                                                <span className="text-zinc-500">Dono</span>
                                                <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md bg-zinc-100 dark:bg-zinc-800 text-xs font-medium">
                                                    {item.owner ? item.owner.user.name : 'Banda'}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                                <div className="inline-flex p-4 rounded-full bg-zinc-100 dark:bg-zinc-800/50 text-zinc-400 mb-4">
                                    <Box className="h-8 w-8" />
                                </div>
                                <h3 className="text-lg font-bold text-foreground">Inventário Vazio</h3>
                                <p className="mt-2 text-zinc-500 max-w-sm mx-auto">Adicione instrumentos, cabos e equipamentos da banda para começar a organizar sua logística.</p>
                            </div>
                        )
                    }
                </div>
            </div>
        </div>
    );
}
