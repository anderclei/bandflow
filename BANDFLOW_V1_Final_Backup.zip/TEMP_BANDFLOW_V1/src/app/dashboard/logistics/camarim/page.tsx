import { Coffee } from "lucide-react"
import { getActiveBand } from "@/lib/getActiveBand"
import { prisma } from "@/lib/prisma"
import { CateringList } from "@/components/dashboard/logistics/CateringList"

export default async function CamarimLogisticsPage() {
    const { band } = await getActiveBand()

    const gigs = await prisma.gig.findMany({
        where: { bandId: band?.id },
        orderBy: { date: 'asc' },
        include: { cateringItems: true }
    })

    return (
        <div className="flex-1 space-y-8 p-8 pt-6 animate-in fade-in duration-500">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Coffee className="h-8 w-8 text-secondary" />
                        Logística de Camarim
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Lista de compras interativa para a produção.
                    </p>
                </div>
            </div>
            <CateringList gigs={gigs as any} />
        </div>
    )
}
