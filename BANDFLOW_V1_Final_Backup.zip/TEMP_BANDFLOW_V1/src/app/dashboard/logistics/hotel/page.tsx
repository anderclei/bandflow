import { Hotel } from "lucide-react"
import { getTrips } from "@/app/actions/trips"
import { getActiveBand } from "@/lib/getActiveBand"
import { RoomingList } from "@/components/dashboard/logistics/RoomingList"

export default async function HotelLogisticsPage() {
    const [trips, { band }] = await Promise.all([
        getTrips(),
        getActiveBand({ members: true })
    ]);
    const members = (band as any)?.members || [];

    return (
        <div className="flex-1 space-y-8 p-8 pt-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Hotel className="h-8 w-8 text-secondary" />
                        Logística de Hotelaria
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie a alocação de quartos para a equipe e banda.
                    </p>
                </div>
            </div>
            <RoomingList initialTrips={trips as any} members={members} />
        </div>
    )
}
