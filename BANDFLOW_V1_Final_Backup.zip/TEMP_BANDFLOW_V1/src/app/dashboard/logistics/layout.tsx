"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Clock, Hotel, Plane, Coffee, Truck } from "lucide-react"

const logisticsTabs = [
    { name: "Cronograma", href: "/dashboard/logistics/schedule", icon: Clock },
    { name: "Hotel", href: "/dashboard/logistics/hotel", icon: Hotel },
    { name: "Viagens", href: "/dashboard/logistics/travel", icon: Plane },
    { name: "Camarim", href: "/dashboard/logistics/camarim", icon: Coffee },
    { name: "Fornecedores", href: "/dashboard/logistics/suppliers", icon: Truck },
]

export default function LogisticsLayout({
    children,
}: {
    children: React.ReactNode
}) {
    const pathname = usePathname()

    return (
        <div className="flex-1 space-y-4 p-8 pt-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground">Logística & Produção</h1>
                    <p className="mt-2 text-sm text-zinc-500">
                        Gerencie viagens, hotéis, camarim e o cronograma do dia.
                    </p>
                </div>
            </div>

            <div className="border-b border-border">
                <nav className="-mb-px flex space-x-6 overflow-x-auto" aria-label="Tabs">
                    {logisticsTabs.map((tab) => {
                        const isActive = pathname === tab.href
                        const Icon = tab.icon

                        return (
                            <Link
                                key={tab.name}
                                href={tab.href}
                                className={cn(
                                    isActive
                                        ? "border-secondary text-secondary"
                                        : "border-transparent text-zinc-500 hover:border-zinc-300 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-300",
                                    "group inline-flex items-center border-b-2 py-4 px-1 text-sm font-medium whitespace-nowrap transition-colors"
                                )}
                            >
                                <Icon
                                    className={cn(
                                        isActive ? "text-secondary" : "text-zinc-400 group-hover:text-zinc-500 dark:group-hover:text-zinc-300",
                                        "mr-2 h-4 w-4"
                                    )}
                                    aria-hidden="true"
                                />
                                {tab.name}
                            </Link>
                        )
                    })}
                </nav>
            </div>

            {/* Injeta a página selecionada */}
            <div className="pt-4">
                {children}
            </div>
        </div>
    )
}
