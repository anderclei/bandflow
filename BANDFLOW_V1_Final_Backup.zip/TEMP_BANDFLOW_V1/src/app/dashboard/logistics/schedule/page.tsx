import { getActiveBand } from "@/lib/getActiveBand";
import { redirect } from "next/navigation";
import { Clock, Plus } from "lucide-react";

export default async function SchedulePage() {
    const { band } = await getActiveBand();

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    return (
        <ScheduleClient bandName={band.name} />
    );
}

import { ScheduleClient } from "./schedule-client";
