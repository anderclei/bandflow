"use client"

import { useState } from "react"
import { Clock, Plus, Share2, Trash2, MapPin, Music } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

interface ScheduleItem {
    id: string
    time: string
    activity: string
    location?: string
    type: "LOGISTICS" | "SOUNDCHECK" | "SHOW" | "OTHER"
}

const itemTypeStyles = {
    LOGISTICS: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    SOUNDCHECK: "bg-orange-500/10 text-orange-500 border-orange-500/20",
    SHOW: "bg-secondary/10 text-secondary border-secondary/20",
    OTHER: "bg-zinc-500/10 text-zinc-500 border-zinc-500/20",
}

export function ScheduleClient({ bandName }: { bandName: string }) {
    const [items, setItems] = useState<ScheduleItem[]>([
        { id: "1", time: "14:00", activity: "Saída da Sede", type: "LOGISTICS", location: "Base da Banda" },
        { id: "2", time: "16:00", activity: "Chegada no Local e Montagem", type: "LOGISTICS" },
        { id: "3", time: "17:30", activity: "Passagem de Som", type: "SOUNDCHECK" },
        { id: "4", time: "21:00", activity: "Início do Show", type: "SHOW" },
        { id: "5", time: "23:00", activity: "Desmontagem e Retorno", type: "LOGISTICS" },
    ])

    const shareOnWhatsApp = () => {
        const header = `*CRONOGRAMA - ${bandName.toUpperCase()}*\n\n`
        const body = items
            .sort((a, b) => a.time.localeCompare(b.time))
            .map(item => `⏰ ${item.time} - ${item.activity}${item.location ? ` (@ ${item.location})` : ""}`)
            .join("\n")

        const footer = "\n\n_Gerado por BAND FLOW_"
        const text = encodeURIComponent(header + body + footer)
        window.open(`https://wa.me/?text=${text}`, "_blank")
        toast.success("Abrindo WhatsApp...")
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Clock className="h-8 w-8 text-secondary" />
                        Cronograma do Dia
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        O roteiro minuto a minuto da banda na estrada.
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" onClick={shareOnWhatsApp} className="gap-2">
                        <Share2 className="h-4 w-4" /> Compartilhar WhatsApp
                    </Button>
                    <Button className="gap-2 bg-secondary text-white hover:bg-secondary/90 border-0">
                        <Plus className="h-4 w-4" /> Novo Item
                    </Button>
                </div>
            </div>

            <div className="relative space-y-0 pb-12">
                {/* Linha vertical da timeline */}
                <div className="absolute left-6 top-2 bottom-0 w-px bg-zinc-200 dark:bg-zinc-800" />

                <div className="space-y-8">
                    {items.sort((a, b) => a.time.localeCompare(b.time)).map((item, index) => (
                        <div key={item.id} className="relative pl-12 group">
                            {/* Ponto na timeline */}
                            <div className={cn(
                                "absolute left-4 top-1.5 h-4 w-4 rounded-full border-2 border-white dark:border-zinc-900 z-10 transition-transform group-hover:scale-125",
                                item.type === "SHOW" ? "bg-secondary animate-pulse" : "bg-zinc-300 dark:bg-zinc-700"
                            )} />

                            <div className="bg-white dark:bg-zinc-900 rounded-3xl p-6 ring-1 ring-zinc-200 dark:ring-zinc-800 shadow-sm transition-all hover:ring-secondary/30">
                                <div className="flex items-start justify-between">
                                    <div className="space-y-1">
                                        <div className="flex items-center gap-3">
                                            <span className="text-xl font-black text-foreground">{item.time}</span>
                                            <Badge variant="outline" className={cn("text-[10px] uppercase font-bold", itemTypeStyles[item.type])}>
                                                {item.type}
                                            </Badge>
                                        </div>
                                        <h3 className="text-lg font-bold text-foreground leading-tight">{item.activity}</h3>
                                        {item.location && (
                                            <div className="flex items-center gap-1.5 text-sm text-zinc-500">
                                                <MapPin className="h-3.5 w-3.5" />
                                                {item.location}
                                            </div>
                                        )}
                                    </div>
                                    <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-destructive">
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}
