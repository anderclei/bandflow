"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, Building, Edit, Trash2 } from "lucide-react"
import { toast } from "sonner"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table"
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createLogisticsSupplier, updateLogisticsSupplier, deleteLogisticsSupplier } from "@/app/actions/logistics-suppliers"

interface Supplier {
    id: string;
    name: string;
    contact: string | null;
    kmValue: number;
}

export function SuppliersClient({ initialSuppliers }: { initialSuppliers: Supplier[] }) {
    const [suppliers, setSuppliers] = useState(initialSuppliers)
    const [isAddOpen, setIsAddOpen] = useState(false)
    const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null)
    const [formData, setFormData] = useState({ name: "", contact: "", kmValue: 0 })
    const [isLoading, setIsLoading] = useState(false)

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setIsLoading(true)
        try {
            if (editingSupplier) {
                await updateLogisticsSupplier(editingSupplier.id, {
                    name: formData.name,
                    contact: formData.contact,
                    kmValue: Number(formData.kmValue)
                })
                setSuppliers(suppliers.map(s => s.id === editingSupplier.id ? { ...s, name: formData.name, contact: formData.contact, kmValue: Number(formData.kmValue) } : s))
                toast.success("Fornecedor atualizado com sucesso!")
            } else {
                const res = await createLogisticsSupplier({
                    name: formData.name,
                    contact: formData.contact,
                    kmValue: Number(formData.kmValue)
                })
                setSuppliers([res.supplier as Supplier, ...suppliers])
                toast.success("Fornecedor cadastrado com sucesso!")
            }
            setIsAddOpen(false)
            setEditingSupplier(null)
            setFormData({ name: "", contact: "", kmValue: 0 })
        } catch (error) {
            toast.error("Erro ao salvar")
        } finally {
            setIsLoading(false)
        }
    }

    const handleDelete = async (id: string) => {
        if (!confirm("Tem certeza que deseja excluir?")) return
        try {
            await deleteLogisticsSupplier(id)
            setSuppliers(suppliers.filter(s => s.id !== id))
            toast.success("Fornecedor removido!")
        } catch (error) {
            toast.error("Erro ao excluir")
        }
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Building className="h-8 w-8 text-secondary" />
                        Fornecedores de Logística
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie vans, ônibus e empresas de transporte e seus valores por KM.
                    </p>
                </div>
                <Dialog open={isAddOpen || !!editingSupplier} onOpenChange={(open) => {
                    if (!open) {
                        setIsAddOpen(false)
                        setEditingSupplier(null)
                        setFormData({ name: "", contact: "", kmValue: 0 })
                    } else setIsAddOpen(true)
                }}>
                    <DialogTrigger asChild>
                        <Button className="bg-secondary text-white hover:bg-secondary/90 gap-2">
                            <Plus className="h-4 w-4" /> Novo Fornecedor
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>{editingSupplier ? "Editar Fornecedor" : "Novo Fornecedor"}</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                            <div className="space-y-2">
                                <Label>Nome da Empresa / Fornecedor</Label>
                                <Input
                                    required
                                    value={formData.name}
                                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                                    placeholder="Ex: Viação Cometa, João Van"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Contato (Telefone / Email)</Label>
                                <Input
                                    value={formData.contact}
                                    onChange={e => setFormData({ ...formData, contact: e.target.value })}
                                    placeholder="Ex: (11) 99999-9999"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Valor por KM (R$)</Label>
                                <Input
                                    required
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={formData.kmValue}
                                    onChange={e => setFormData({ ...formData, kmValue: Number(e.target.value) })}
                                    placeholder="0.00"
                                />
                            </div>
                            <Button type="submit" disabled={isLoading} className="w-full bg-secondary text-white hover:brightness-90">
                                {isLoading ? "Salvando..." : "Salvar"}
                            </Button>
                        </form>
                    </DialogContent>
                </Dialog>
            </div>

            <div className="rounded-3xl bg-card text-card-foreground shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-800 overflow-hidden">
                {suppliers.length > 0 ? (
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Nome</TableHead>
                                <TableHead>Contato</TableHead>
                                <TableHead>Valor KM</TableHead>
                                <TableHead className="w-[100px] text-right">Ações</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {suppliers.map(supplier => (
                                <TableRow key={supplier.id}>
                                    <TableCell className="font-medium">{supplier.name}</TableCell>
                                    <TableCell>{supplier.contact || "-"}</TableCell>
                                    <TableCell>
                                        {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(supplier.kmValue)} / KM
                                    </TableCell>
                                    <TableCell className="text-right flex items-center justify-end gap-2">
                                        <Button variant="ghost" size="icon" onClick={() => {
                                            setFormData({ name: supplier.name, contact: supplier.contact || "", kmValue: supplier.kmValue })
                                            setEditingSupplier(supplier)
                                        }}>
                                            <Edit className="h-4 w-4" />
                                        </Button>
                                        <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => handleDelete(supplier.id)}>
                                            <Trash2 className="h-4 w-4" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                ) : (
                    <div className="p-8 text-center text-zinc-500">
                        Nenhum fornecedor cadastrado.
                    </div>
                )}
            </div>
        </div>
    )
}
