import { Plane } from "lucide-react"
import { getActiveBand } from "@/lib/getActiveBand"
import { prisma } from "@/lib/prisma"
import { FlightList } from "@/components/dashboard/logistics/FlightList"

export default async function TravelLogisticsPage() {
    const { band } = await getActiveBand()

    const tripsWithFlights = await prisma.trip.findMany({
        where: { bandId: band?.id },
        orderBy: { createdAt: 'desc' },
        include: { flights: true }
    })

    return (
        <div className="flex-1 space-y-8 p-8 pt-6 animate-in fade-in duration-500">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Plane className="h-8 w-8 text-secondary" />
                        Logística de Voos
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerenciamento de passagens aéreas e localizadores.
                    </p>
                </div>
            </div>
            <FlightList trips={tripsWithFlights as any} />
        </div>
    )
}
