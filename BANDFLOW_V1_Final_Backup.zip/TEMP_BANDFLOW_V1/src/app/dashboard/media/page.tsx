import { getActiveBand } from "@/lib/getActiveBand";
import { redirect } from "next/navigation";
import { Camera, Plus, Image as ImageIcon } from "lucide-react";

export default async function MediaPage() {
    const { band } = await getActiveBand();

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Camera className="h-8 w-8 text-secondary" />
                        Central de Mídia
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Kits de VJ, LED, fotos oficiais e press kit para a imprensa.
                    </p>
                </div>
                <button className="inline-flex items-center gap-2 rounded-xl bg-zinc-950 px-4 py-2 text-sm font-bold text-white hover:bg-zinc-800 transition-all dark:bg-white dark:text-black">
                    <Plus className="h-4 w-4" /> Upload de Mídia
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 flex flex-col items-center">
                    <div className="p-4 rounded-2xl bg-secondary/10 text-secondary mb-4">
                        <Camera className="h-8 w-8" />
                    </div>
                    <h4 className="font-bold">Fotos de Imprensa</h4>
                    <p className="text-xs text-zinc-500 text-center mt-2">Fotos oficiais em alta resolução.</p>
                </div>
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 flex flex-col items-center">
                    <div className="p-4 rounded-2xl bg-secondary/10 text-secondary mb-4">
                        <ImageIcon className="h-8 w-8" />
                    </div>
                    <h4 className="font-bold">Kits VJ / LED</h4>
                    <p className="text-xs text-zinc-500 text-center mt-2">Arquivos de vídeo e loops para o show.</p>
                </div>
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 flex flex-col items-center">
                    <div className="p-4 rounded-2xl bg-secondary/10 text-secondary mb-4">
                        <Plus className="h-8 w-8" />
                    </div>
                    <h4 className="font-bold">Novo Kit</h4>
                    <p className="text-xs text-zinc-500 text-center mt-2">Crie uma nova pasta de assets.</p>
                </div>
            </div>
        </div>
    );
}
