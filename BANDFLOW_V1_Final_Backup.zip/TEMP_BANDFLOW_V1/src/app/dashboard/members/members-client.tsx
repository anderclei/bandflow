"use client"

import { useState } from "react"
import { Users, Mail, Shield, UserCircle, Plus, Send, Clock, Trash2, Edit } from "lucide-react"
import { MemberDialog } from "@/components/dashboard/members/member-dialog"

export function MembersClient({ members, formats, bandName }: { members: any[], formats: any[], bandName: string }) {
    const [isDialogOpen, setIsDialogOpen] = useState(false)
    const [selectedMember, setSelectedMember] = useState<any>(null)

    const handleEdit = (member: any) => {
        setSelectedMember(member)
        setIsDialogOpen(true)
    }

    const handleNew = () => {
        setSelectedMember(null)
        setIsDialogOpen(true)
    }

    return (
        <div className="space-y-12">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Users className="h-8 w-8 text-secondary" />
                        Integrantes & Músicos
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie quem faz parte de {bandName}, seus cargos, informações de logística e cachês.
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={handleNew} className="rounded-xl px-4 py-2 text-sm font-semibold bg-secondary text-white hover:opacity-90 transition-opacity flex items-center gap-2">
                        <Plus className="h-4 w-4" />
                        Cadastrar Integrante
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
                {/* Members List */}
                <div className="lg:col-span-2 space-y-6">
                    <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                        <Users className="h-5 w-5 text-secondary" />
                        Equipe Atual
                    </h2>
                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                        {members?.map((member: any) => (
                            <div key={member.id} className="group relative rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 hover:ring-secondary/30 transition-all flex flex-col justify-between">
                                <div className="absolute top-4 right-4">
                                    <button onClick={() => handleEdit(member)} className="p-2 text-zinc-400 hover:text-secondary bg-zinc-50 dark:bg-zinc-800 rounded-full transition-colors opacity-0 group-hover:opacity-100">
                                        <Edit className="h-4 w-4" />
                                    </button>
                                </div>
                                <div className="flex items-start gap-4">
                                    <div className="relative">
                                        {member.user?.image ? (
                                            <img src={member.user.image} alt={member.name || member.user.name || ""} className="h-14 w-14 rounded-2xl object-cover" />
                                        ) : (
                                            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-400">
                                                <UserCircle className="h-8 w-8" />
                                            </div>
                                        )}
                                        {member.role === "ADMIN" && (
                                            <div className="absolute -right-1 -top-1 rounded-full bg-secondary p-1 text-white ring-2 ring-white dark:ring-zinc-900">
                                                <Shield className="h-3 w-3" />
                                            </div>
                                        )}
                                    </div>
                                    <div className="flex-1 min-w-0 pr-6">
                                        <h3 className="font-bold text-foreground truncate">{member.name || member.user?.name || "Músico Anônimo"}</h3>
                                        {member.position && (
                                            <p className="text-sm rounded-full bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 mt-1 inline-block text-zinc-600 dark:text-zinc-400">
                                                {member.position}
                                            </p>
                                        )}
                                        {member.user?.email && (
                                            <div className="flex items-center gap-1.5 mt-2 text-xs text-zinc-500">
                                                <Mail className="h-3.5 w-3.5" />
                                                <span className="truncate">{member.user.email}</span>
                                            </div>
                                        )}



                                        {member.cache && member.cache > 0 && (
                                            <div className="mt-1 text-xs text-zinc-500">
                                                Cachê: R$ {member.cache.toFixed(2)}
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {member.formats && member.formats.length > 0 && (
                                    <div className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-800/50">
                                        <div className="flex flex-wrap gap-1">
                                            {member.formats.map((f: any) => (
                                                <span key={f.id} className="inline-flex items-center rounded-md bg-secondary/10 px-2 py-1 text-[10px] font-medium text-secondary ring-1 ring-inset ring-secondary/20 uppercase tracking-wider">
                                                    {f.name}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>

                </div>
            </div>

            <MemberDialog
                open={isDialogOpen}
                onOpenChange={setIsDialogOpen}
                member={selectedMember}
                formats={formats}
            />
        </div>
    )
}
