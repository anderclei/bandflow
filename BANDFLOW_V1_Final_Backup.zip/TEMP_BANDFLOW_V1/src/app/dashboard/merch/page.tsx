import { getActiveBand } from "@/lib/getActiveBand";
import { redirect } from "next/navigation";
import { Store, Plus, Trash2, Package, TrendingUp } from "lucide-react";
import { createMerchItem, deleteMerchItem, updateMerchStock } from "@/app/actions/merch";
import Link from "next/link";

export default async function MerchPage() {
    const { band } = await getActiveBand({
        merchItems: { orderBy: { category: 'asc' } },
        merchSales: {
            include: {
                items: { include: { item: true } },
                gig: true
            },
            orderBy: { date: 'desc' },
            take: 5
        }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const items = (band.merchItems as any[]) || [];
    const sales = (band.merchSales as any[]) || [];

    const totalRevenue = sales.reduce((acc, sale) => acc + sale.totalAmount, 0);
    const totalItemsInStock = items.reduce((acc, item) => acc + item.stock, 0);

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Store className="h-8 w-8 text-secondary" />
                        Lojinha & Merchandising
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie os produtos físicos da banda e acompanhe o estoque.
                    </p>
                </div>

                <Link
                    href="/dashboard/merch/pos"
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-sm font-semibold text-white hover:opacity-90 transition-colors shadow-lg shadow-secondary/20"
                >
                    <Package className="h-4 w-4" />
                    Abrir Frente de Caixa (PDV)
                </Link>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Total em Estoque (Unidades)</p>
                    <p className="mt-2 text-3xl font-bold text-foreground">{totalItemsInStock}</p>
                </div>
                <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Vendas Realizadas (R$)</p>
                    <p className="mt-2 text-3xl font-bold text-foreground">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalRevenue)}
                    </p>
                </div>
                <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <p className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Produtos Cadastrados</p>
                    <p className="mt-2 text-3xl font-bold text-foreground">{items.length}</p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
                {/* Form to add new product */}
                <div className="lg:col-span-1">
                    <form action={createMerchItem.bind(null, band.id)} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 sticky top-6">
                        <h2 className="text-xl font-bold text-foreground mb-6">Novo Produto</h2>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Nome do Produto</label>
                                <input
                                    type="text"
                                    name="name"
                                    required
                                    placeholder="Ex: Camiseta Preta M"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Categoria</label>
                                <select
                                    name="category"
                                    required
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                >
                                    <option value="Vestuário">Vestuário (Camisetas, Bonés)</option>
                                    <option value="Físico">Mídia Física (CD, Vinil)</option>
                                    <option value="Acessório">Acessórios (Bótons, Adesivos)</option>
                                    <option value="Outro">Outro</option>
                                </select>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Preço (Venda)</label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        name="price"
                                        required
                                        placeholder="R$ 50,00"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Preço (Custo)</label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        name="costPrice"
                                        placeholder="Ex: 25,00"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Estoque Inicial</label>
                                <input
                                    type="number"
                                    name="stock"
                                    required
                                    defaultValue={0}
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                />
                            </div>

                            <button
                                type="submit"
                                className="w-full flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-sm font-semibold text-white hover:opacity-90 transition-colors mt-2"
                            >
                                <Plus className="h-4 w-4" />
                                Cadastrar Produto
                            </button>
                        </div>
                    </form>
                </div>

                {/* List of Products */}
                <div className="lg:col-span-2">
                    <div className="rounded-3xl bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 overflow-hidden">
                        <div className="p-6 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                            <h2 className="text-xl font-bold text-foreground">Estoque Atual</h2>
                        </div>

                        <div className="divide-y divide-zinc-100 dark:divide-zinc-800 flex flex-col">
                            {items.length === 0 ? (
                                <div className="p-12 text-center text-zinc-500">
                                    <Store className="mx-auto h-12 w-12 text-zinc-300 dark:text-zinc-700 mb-4" />
                                    Nenhum produto cadastrado na lojinha ainda.
                                </div>
                            ) : (
                                items.map((item) => (
                                    <div key={item.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors">
                                        <div className="flex items-center gap-4">
                                            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 shrink-0">
                                                <Store className="h-6 w-6" />
                                            </div>
                                            <div>
                                                <h3 className="font-semibold text-foreground">{item.name}</h3>
                                                <div className="flex items-center gap-2 text-sm text-zinc-500 mt-1">
                                                    <span className="rounded-full bg-zinc-100 dark:bg-zinc-800 px-2.5 py-0.5 text-xs font-medium">
                                                        {item.category}
                                                    </span>
                                                    <span>
                                                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.price)}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-6">
                                            <div className="text-center">
                                                <span className="block text-xs uppercase text-zinc-500 font-bold mb-1">Estoque</span>
                                                <div className="flex items-center gap-2">
                                                    {/* We could add + / - buttons here in the future calling updateMerchStock */}
                                                    <span className={`font-mono text-lg font-bold ${item.stock <= 5 ? 'text-red-500' : 'text-secondary'}`}>
                                                        {item.stock}
                                                    </span>
                                                </div>
                                            </div>

                                            <form action={deleteMerchItem.bind(null, item.id)}>
                                                <button
                                                    type="submit"
                                                    title="Excluir produto"
                                                    className="rounded-xl p-2.5 text-zinc-400 hover:bg-zinc-100 hover:text-red-500 dark:hover:bg-zinc-800 transition-colors"
                                                >
                                                    <Trash2 className="h-5 w-5" />
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>

                {/* Recent Sales History */}
                <div className="lg:col-span-2">
                    <div className="rounded-3xl bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 overflow-hidden">
                        <div className="p-6 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <TrendingUp className="h-5 w-5 text-secondary" />
                                <h2 className="text-xl font-bold text-foreground">Vendas Recentes</h2>
                            </div>
                        </div>

                        <div className="divide-y divide-zinc-100 dark:divide-zinc-800">
                            {sales.length === 0 ? (
                                <div className="p-12 text-center text-zinc-500">
                                    Nenhuma venda registrada recentemente.
                                </div>
                            ) : (
                                sales.map((sale: any) => (
                                    <div key={sale.id} className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                        <div className="space-y-1">
                                            <div className="flex items-center gap-2">
                                                <span className="font-bold text-foreground">
                                                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(sale.totalAmount)}
                                                </span>
                                                <span className="text-xs px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-500 font-medium">
                                                    {sale.paymentMethod}
                                                </span>
                                                {sale.gig && (
                                                    <span className="text-xs text-secondary font-bold">
                                                        • Show: {sale.gig.title}
                                                    </span>
                                                )}
                                            </div>
                                            <div className="text-sm text-zinc-500">
                                                {sale.items.map((si: any) => `${si.quantity}x ${si.item.name}`).join(', ')}
                                            </div>
                                            <div className="text-[10px] text-zinc-400 uppercase font-bold">
                                                {new Date(sale.date).toLocaleString('pt-BR')}
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
