"use client";

import { useState } from "react";
import { Store, ShoppingCart, Plus, Minus, CreditCard, Banknote, QrCode, ArrowLeft, Loader2, CheckCircle2 } from "lucide-react";
import { registerMerchSale } from "@/app/actions/merch";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { PixPaymentModal } from "./PixPaymentModal";

interface MerchItem {
    id: string;
    name: string;
    category: string;
    price: number;
    stock: number;
}

interface Gig {
    id: string;
    title: string;
    date: Date;
}

interface CartItem extends MerchItem {
    quantity: number;
}

export function POSClient({ items, gigs, bandId }: { items: MerchItem[], gigs: Gig[], bandId: string }) {
    const router = useRouter();
    const [cart, setCart] = useState<CartItem[]>([]);
    const [selectedGigId, setSelectedGigId] = useState<string>("");
    const [isProcessing, setIsProcessing] = useState(false);
    const [successMessage, setSuccessMessage] = useState("");
    const [isPixModalOpen, setIsPixModalOpen] = useState(false);

    const addToCart = (item: MerchItem) => {
        setCart(prev => {
            const existing = prev.find(i => i.id === item.id);
            if (existing) {
                if (existing.quantity >= item.stock) return prev; // Cannot exceed stock
                return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
            }
            return [...prev, { ...item, quantity: 1 }];
        });
    };

    const removeFromCart = (itemId: string) => {
        setCart(prev => {
            const existing = prev.find(i => i.id === itemId);
            if (existing && existing.quantity > 1) {
                return prev.map(i => i.id === itemId ? { ...i, quantity: i.quantity - 1 } : i);
            }
            return prev.filter(i => i.id !== itemId);
        });
    };

    const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

    const handleCheckout = async (method: string) => {
        if (cart.length === 0) return;

        if (method === "PIX" && !isPixModalOpen) {
            setIsPixModalOpen(true);
            return;
        }

        setIsPixModalOpen(false);
        setIsProcessing(true);

        try {
            const formattedCart = cart.map(item => ({
                itemId: item.id,
                quantity: item.quantity,
                unitPrice: item.price
            }));

            const result = await registerMerchSale(
                bandId,
                formattedCart,
                method,
                selectedGigId || undefined
            );

            if (result?.success) {
                setCart([]);
                setSuccessMessage(`Venda de ${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cartTotal)} registrada com sucesso!`);
                setTimeout(() => {
                    setSuccessMessage("");
                    router.refresh();
                }, 3000);
            }
        } catch (error) {
            console.error(error);
            alert("Erro ao processar venda");
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <div className="flex h-full flex-col lg:flex-row gap-6">
            {/* Left side - Products Grid */}
            <div className="flex-1 flex flex-col bg-white dark:bg-zinc-900 rounded-3xl shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-800 overflow-hidden">
                <div className="p-6 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <Link href="/dashboard/merch" className="p-2 rounded-xl text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors">
                            <ArrowLeft className="h-5 w-5" />
                        </Link>
                        <div>
                            <h2 className="text-xl font-bold text-foreground">Frente de Caixa (PDV)</h2>
                            <p className="text-sm text-zinc-500 mt-1">Toque nos itens para adicionar ao carrinho</p>
                        </div>
                    </div>
                    {gigs.length > 0 && (
                        <select
                            value={selectedGigId}
                            onChange={(e) => setSelectedGigId(e.target.value)}
                            className="bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 rounded-xl p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20 max-w-[200px]"
                        >
                            <option value="">Venda Avulsa (Nenhum show)</option>
                            {gigs.map(g => (
                                <option key={g.id} value={g.id}>Show: {g.title}</option>
                            ))}
                        </select>
                    )}
                </div>

                <div className="flex-1 p-6 overflow-y-auto">
                    {items.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-zinc-500">
                            <Store className="h-16 w-16 mb-4 text-zinc-300 dark:text-zinc-700" />
                            <p className="font-medium text-lg">Sem produtos em estoque</p>
                            <Link href="/dashboard/merch" className="text-secondary hover:underline mt-2">
                                Vá para o Lojinha para cadastrar estoque
                            </Link>
                        </div>
                    ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
                            {items.map(item => {
                                const inCart = cart.find(i => i.id === item.id)?.quantity || 0;
                                const isSoldOut = inCart >= item.stock;

                                return (
                                    <button
                                        key={item.id}
                                        onClick={() => addToCart(item)}
                                        disabled={isSoldOut}
                                        className={`relative p-4 rounded-2xl border-2 text-left transition-all overflow-hidden group
                                            ${isSoldOut
                                                ? 'border-zinc-100 dark:border-zinc-800 opacity-50 cursor-not-allowed'
                                                : 'border-zinc-100 dark:border-zinc-800 hover:border-secondary/50 hover:shadow-md'
                                            }
                                            ${inCart > 0 ? 'ring-2 ring-secondary bg-secondary/5 dark:bg-secondary/10' : 'bg-white dark:bg-zinc-900'}
                                        `}
                                    >
                                        <div className="font-bold text-foreground mb-1 pr-6">{item.name}</div>
                                        <div className="text-sm font-medium text-zinc-500">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.price)}</div>

                                        <div className="absolute top-4 right-4 text-xs font-bold bg-zinc-100 dark:bg-zinc-800 text-zinc-500 px-2 py-1 rounded-lg">
                                            {item.stock - inCart} left
                                        </div>

                                        {inCart > 0 && (
                                            <div className="absolute top-0 right-0 w-8 h-8 bg-secondary text-white rounded-bl-2xl flex items-center justify-center font-bold text-sm">
                                                {inCart}
                                            </div>
                                        )}
                                    </button>
                                );
                            })}
                        </div>
                    )}
                </div>
            </div>

            {/* Right side - Cart / Checkout */}
            <div className="w-full lg:w-96 flex flex-col bg-white dark:bg-zinc-900 rounded-3xl shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-800 overflow-hidden shrink-0">
                <div className="p-6 border-b border-zinc-100 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50">
                    <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
                        <ShoppingCart className="h-5 w-5 text-secondary" />
                        Carrinho
                    </h2>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-4 relative">
                    {/* Success Overlay moves here so it covers the cart content not just buttons */}
                    {successMessage && (
                        <div className="absolute inset-0 z-10 bg-secondary flex flex-col items-center justify-center text-white font-bold p-6 text-center animate-in fade-in zoom-in duration-300">
                            <CheckCircle2 className="h-12 w-12 mb-2" />
                            {successMessage}
                        </div>
                    )}

                    {cart.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-zinc-400">
                            <ShoppingCart className="h-12 w-12 mb-4 opacity-50" />
                            <p>O carrinho está vazio</p>
                        </div>
                    ) : (
                        cart.map(item => (
                            <div key={item.id} className="flex items-center justify-between gap-4 py-2 border-b border-zinc-100 dark:border-zinc-800 last:border-0">
                                <div className="flex-1 leading-tight">
                                    <div className="font-bold text-sm truncate">{item.name}</div>
                                    <div className="text-xs text-zinc-500">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.price)} uni</div>
                                </div>

                                <div className="flex items-center gap-3 bg-zinc-50 dark:bg-zinc-800 rounded-xl p-1">
                                    <button onClick={() => removeFromCart(item.id)} className="p-1.5 hover:bg-white dark:hover:bg-zinc-700 rounded-lg text-zinc-500 transition-colors">
                                        <Minus className="h-4 w-4" />
                                    </button>
                                    <span className="font-bold w-4 text-center text-sm">{item.quantity}</span>
                                    <button onClick={() => addToCart(item)} className="p-1.5 hover:bg-white dark:hover:bg-zinc-700 rounded-lg text-zinc-500 transition-colors disabled:opacity-30" disabled={item.quantity >= item.stock}>
                                        <Plus className="h-4 w-4" />
                                    </button>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                <div className="p-6 bg-zinc-50 dark:bg-zinc-900/80 border-t border-zinc-100 dark:border-zinc-800">
                    <div className="flex items-center justify-between mb-6">
                        <span className="text-zinc-500 font-medium">Total ({cartCount} itens)</span>
                        <span className="text-3xl font-black text-foreground">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cartTotal)}
                        </span>
                    </div>

                    <div className="grid grid-cols-3 gap-3">
                        <button
                            onClick={() => handleCheckout("PIX")}
                            disabled={cart.length === 0 || isProcessing}
                            className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-white border border-secondary/20 text-secondary hover:bg-secondary/5 hover:border-secondary shadow-sm p-4 font-bold transition-all disabled:opacity-50"
                        >
                            {isProcessing ? <Loader2 className="h-6 w-6 animate-spin" /> : <QrCode className="h-6 w-6" />}
                            <span className="text-xs uppercase">Pix</span>
                        </button>

                        <button
                            onClick={() => handleCheckout("CREDIT")}
                            disabled={cart.length === 0 || isProcessing}
                            className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-white border border-zinc-200 text-zinc-600 hover:bg-zinc-50 hover:border-zinc-400 shadow-sm p-4 font-bold transition-all disabled:opacity-50"
                        >
                            {isProcessing ? <Loader2 className="h-6 w-6 animate-spin" /> : <CreditCard className="h-6 w-6" />}
                            <span className="text-xs uppercase">Cartão</span>
                        </button>

                        <button
                            onClick={() => handleCheckout("CASH")}
                            disabled={cart.length === 0 || isProcessing}
                            className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-white border border-zinc-200 text-zinc-600 hover:bg-zinc-50 hover:border-zinc-400 shadow-sm p-4 font-bold transition-all disabled:opacity-50"
                        >
                            {isProcessing ? <Loader2 className="h-6 w-6 animate-spin" /> : <Banknote className="h-6 w-6" />}
                            <span className="text-xs uppercase">Dinheiro</span>
                        </button>
                    </div>
                </div>
            </div>
            {isPixModalOpen && (
                <PixPaymentModal
                    total={cartTotal}
                    onConfirm={() => handleCheckout("PIX")}
                    onClose={() => setIsPixModalOpen(false)}
                />
            )}
        </div>
    );
}
