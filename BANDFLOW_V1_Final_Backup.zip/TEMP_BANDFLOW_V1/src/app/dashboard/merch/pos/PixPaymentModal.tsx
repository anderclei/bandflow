"use client";

import { QrCode, X, Copy, CheckCircle2 } from "lucide-react";
import { useState } from "react";

interface PixPaymentModalProps {
    total: number;
    onConfirm: () => void;
    onClose: () => void;
}

export function PixPaymentModal({ total, onConfirm, onClose }: PixPaymentModalProps) {
    const [copied, setCopied] = useState(false);

    const pixKey = "financeiro@bandmanager.com.br"; // Exemplo de chave
    const pixCopyPaste = "00020126580014BR.GOV.BCB.PIX0114" + pixKey.replace(/[@.]/g, '') + "5204000053039865404" + total.toFixed(2) + "5802BR5913BANDFLOW00006008BRASILIA62070503***6304";

    const handleCopy = () => {
        navigator.clipboard.writeText(pixCopyPaste);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
            <div className="bg-white dark:bg-zinc-900 w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in duration-300">
                <div className="p-6 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                    <h3 className="text-xl font-bold text-foreground">Pagamento via PIX</h3>
                    <button onClick={onClose} className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-xl transition-colors">
                        <X className="h-5 w-5" />
                    </button>
                </div>

                <div className="p-8 flex flex-col items-center text-center">
                    <div className="text-3xl font-black text-foreground mb-2">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(total)}
                    </div>
                    <p className="text-zinc-500 text-sm mb-8">Escaneie o QR Code abaixo para pagar</p>

                    <div className="relative group">
                        <div className="absolute -inset-4 bg-secondary/20 rounded-[2rem] blur-xl opacity-50 group-hover:opacity-100 transition-opacity" />
                        <div className="relative bg-white p-4 rounded-2xl shadow-inner border-4 border-zinc-50">
                            <QrCode className="h-48 w-48 text-zinc-900" />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 backdrop-blur-[2px]">
                                <span className="text-xs font-bold text-zinc-900 uppercase tracking-widest">QR Code Demonstrativo</span>
                            </div>
                        </div>
                    </div>

                    <div className="mt-8 w-full space-y-3">
                        <button
                            onClick={handleCopy}
                            className="w-full flex items-center justify-center gap-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 py-3 text-sm font-bold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                        >
                            {copied ? <CheckCircle2 className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                            {copied ? "Copiado!" : "Copiar Pix Copia e Cola"}
                        </button>

                        <button
                            onClick={onConfirm}
                            className="w-full rounded-xl bg-secondary py-4 text-white font-bold shadow-lg shadow-secondary/30 hover:opacity-90 active:scale-[0.98] transition-all"
                        >
                            Confirmar Recebimento
                        </button>
                    </div>
                </div>

                <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 text-center">
                    <p className="text-[10px] text-zinc-400 uppercase tracking-widest font-bold">
                        O estoque será atualizado após a confirmação
                    </p>
                </div>
            </div>
        </div>
    );
}
