import { getActiveBand } from "@/lib/getActiveBand";
import { redirect } from "next/navigation";
import Calendar from "@/components/dashboard/Calendar";
import Link from "next/link";
import { ExecutiveCharts } from "@/components/dashboard/ExecutiveCharts";
import { DateRangePicker } from "@/components/dashboard/DateRangePicker";
import { prisma } from "@/lib/prisma";
import { Trash2, Target, Plus, LayoutDashboard, TrendingUp, CalendarCheck, DollarSign, Package, Car, Wrench } from "lucide-react";
import { createGoal, deleteGoal, updateGoalProgress } from "@/app/actions/goals";
import { Suspense } from "react";
import { Button } from "@/components/ui/button";

import { QuickActions } from "@/components/dashboard/QuickActions";
import { DashboardStatCard } from "@/components/dashboard/stat-card";
import { DashboardOverviewChart } from "@/components/dashboard/overview-chart";
import { UpcomingEventsList, UpcomingEvent } from "@/components/dashboard/upcoming-events";
import { RecentActivityFeed, ActivityItem } from "@/components/dashboard/recent-activity";

export default async function DashboardPage({
    searchParams,
}: {
    searchParams: Promise<{ from?: string; to?: string }>;
}) {
    const params = await searchParams;
    const { band, session } = await getActiveBand({
        gigs: {
            include: { contractor: true }
        },
        songs: {
            include: { payments: true }
        },
        equipment: true,
        merchSales: {
            include: { items: { include: { item: true } } }
        },
        expenses: true,
        contractors: {
            include: { gigs: true }
        },
        goals: { orderBy: { createdAt: 'desc' } },
        activityLogs: {
            orderBy: { createdAt: 'desc' },
            take: 8
        },
        contracts: true,
        trips: {
            include: { rooms: { include: { assignments: true } } },
            orderBy: { createdAt: 'desc' },
            take: 1
        }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    // Date range filter
    const fromDate = params.from ? new Date(params.from) : null;
    const toDate = params.to ? new Date(params.to) : null;

    const gigs = (band as any).gigs || [];
    const songs = (band as any).songs || [];
    const equipment = (band as any).equipment || [];
    const merchSales = (band as any).merchSales || [];
    const expenses = (band as any).expenses || [];
    const goals = (band as any).goals || [];
    const activityLogs = (band as any).activityLogs || [];
    const contracts = (band as any).contracts || [];
    const recentTrip = (band as any).trips?.[0] || null;

    // Filter by date range if provided
    const filteredGigs = fromDate || toDate
        ? gigs.filter((g: any) => {
            const d = new Date(g.date);
            if (fromDate && d < fromDate) return false;
            if (toDate && d > toDate) return false;
            return true;
        })
        : gigs;

    const filteredExpenses = fromDate || toDate
        ? expenses.filter((e: any) => {
            const d = new Date(e.date);
            if (fromDate && d < fromDate) return false;
            if (toDate && d > toDate) return false;
            return true;
        })
        : expenses;

    // 1. Technical Equity
    const technicalEquity = equipment.reduce((acc: number, item: any) => acc + (item.value || 0), 0);

    // 2. Total Royalties
    const totalRoyalties = songs.reduce((acc: number, song: any) => {
        return acc + song.payments.reduce((pAcc: number, p: any) => pAcc + p.amount, 0);
    }, 0);

    // 3. Merch Revenue
    const merchRevenue = merchSales.reduce((acc: number, sale: any) => acc + sale.totalAmount, 0);

    // 4. Net Fee
    const netFee = filteredGigs.reduce((acc: number, gig: any) => {
        const fee = gig.fee || 0;
        const tax = (fee * ((gig.taxRate || 0) / 100)) + (gig.taxAmount || 0);
        return acc + (fee - tax);
    }, 0);

    // 5. Ranking Contratantes
    const contractorRanking = ((band as any).contractors || [])
        .map((c: any) => ({
            name: c.name,
            total: (c.gigs || []).reduce((acc: number, g: any) => acc + (g.fee || 0), 0)
        }))
        .sort((a: any, b: any) => b.total - a.total)
        .slice(0, 5);


    // 6. Chart Data
    const monthlyStats: Record<string, { month: string; Gross: number; Taxes: number; Expenses: number }> = {};
    filteredGigs.forEach((gig: any) => {
        const gigDate = new Date(gig.date);
        const month = gigDate.toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
        if (!monthlyStats[month]) monthlyStats[month] = { month, Gross: 0, Taxes: 0, Expenses: 0 };
        const fee = gig.fee || 0;
        const tax = (fee * ((gig.taxRate || 0) / 100)) + (gig.taxAmount || 0);
        monthlyStats[month].Gross += fee;
        monthlyStats[month].Taxes += tax;
    });
    filteredExpenses.forEach((expense: any) => {
        const month = new Date(expense.date).toLocaleDateString('pt-BR', { month: 'short', year: 'numeric' });
        if (!monthlyStats[month]) monthlyStats[month] = { month, Gross: 0, Taxes: 0, Expenses: 0 };
        monthlyStats[month].Expenses += expense.amount;
    });
    const profitabilityData = Object.values(monthlyStats).sort((a, b) =>
        new Date(`1 ${a.month}`).getTime() - new Date(`1 ${b.month}`).getTime()
    );

    // Activity icons
    const activityIcons: Record<string, string> = {
        CREATED: "Novo", UPDATED: "Atualizou", DELETED: "Removeu",
    };

    // Adapters for new components
    const overviewChartData = profitabilityData.map(d => ({
        name: d.month,
        total: d.Gross
    }));

    const upcomingEventsData: UpcomingEvent[] = gigs
        .filter((g: any) => new Date(g.date) >= new Date())
        .sort((a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .map((g: any) => {
            const d = new Date(g.date);
            const dateStr = `${d.getDate().toString().padStart(2, '0')}/${d.toLocaleDateString('pt-BR', { month: 'short' }).toUpperCase()}`;
            return {
                id: g.id,
                title: g.title,
                date: dateStr,
                location: g.location || 'A definir',
                status: g.contractUrl ? 'confirmed' : 'pending' as any
            };
        }).slice(0, 5);

    const recentActivityData: ActivityItem[] = activityLogs.map((log: any) => ({
        id: log.id,
        user: "Membro", // ActivityLog in schema doesn't have User relation yet
        action: activityIcons[log.action] || log.action,
        target: log.details || "Ação no sistema",
        date: new Date(log.createdAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
    }));

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <LayoutDashboard className="h-8 w-8 text-secondary" />
                        Olá, {session?.user?.name || "Músico"}! 👋
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        {band ? `Gerenciando agora: ${band.name}` : "Aqui está o que está acontecendo hoje."}
                    </p>
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                    <Suspense fallback={null}>
                        <DateRangePicker />
                    </Suspense>
                    <a
                        href={`/api/bands/${band.id}/report`}
                        download
                        className="inline-flex items-center gap-2 rounded-xl bg-zinc-900 px-4 py-2 text-xs font-bold text-white hover:bg-zinc-800 transition-all dark:bg-white dark:text-black dark:hover:bg-zinc-200"
                    >
                        📄 Relatório PDF
                    </a>
                </div>
            </div>

            <QuickActions bandId={band.id} />

            {(fromDate || toDate) && (
                <div className="rounded-2xl bg-red-50 dark:bg-red-950/20 px-4 py-2 text-xs font-bold text-red-700 dark:text-red-400">
                    📊 Filtrando dados de {fromDate ? fromDate.toLocaleDateString('pt-BR') : '...'} até {toDate ? toDate.toLocaleDateString('pt-BR') : 'hoje'}
                </div>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <DashboardStatCard
                    title="Receita (Shows Filtrados)"
                    value={netFee.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    description={fromDate ? "Período selecionado" : "Total histórico"}
                    icon={<DollarSign className="h-4 w-4" />}
                    trend="up"
                    trendValue="Estável"
                />
                <DashboardStatCard
                    title="Shows Confirmados"
                    value={upcomingEventsData.length.toString()}
                    description="Próximos agendados"
                    icon={<CalendarCheck className="h-4 w-4" />}
                    trend="up"
                    trendValue="+1"
                />
                <DashboardStatCard
                    title="Patrimônio Técnico"
                    value={technicalEquity.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    description={`${equipment.length} itens cadastrados`}
                    icon={<Package className="h-4 w-4" />}
                />
                <DashboardStatCard
                    title="Novos Leads (Merch/Royalties)"
                    value={(merchSales.length + songs.length).toString()}
                    description="Vendas e Músicas"
                    icon={<TrendingUp className="h-4 w-4" />}
                />
            </div>

            {/* Goals */}
            {goals.length > 0 && (
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="text-lg font-bold text-foreground flex items-center gap-2"><Target className="h-5 w-5 text-secondary" /> Metas da Banda</h2>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {goals.map((goal: any) => {
                            const progress = goal.targetValue > 0 ? Math.min((goal.currentValue / goal.targetValue) * 100, 100) : 0;
                            return (
                                <div key={goal.id} className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 space-y-2">
                                    <div className="flex items-center justify-between">
                                        <p className="text-sm font-bold text-foreground">{goal.title}</p>
                                        <form action={async () => { "use server"; await deleteGoal(goal.id); }}>
                                            <button className="p-1 text-zinc-400 hover:text-red-500"><Trash2 className="h-3 w-3" /></button>
                                        </form>
                                    </div>
                                    <div className="h-2 bg-zinc-200 dark:bg-zinc-700 rounded-full overflow-hidden">
                                        <div className="h-full bg-secondary transition-all duration-500" style={{ width: `${progress}%` }} />
                                    </div>
                                    <div className="flex items-center justify-between text-[10px] text-zinc-500">
                                        <span>{goal.currentValue.toLocaleString('pt-BR')} / {goal.targetValue.toLocaleString('pt-BR')} {goal.unit}</span>
                                        <span className="font-bold text-secondary">{progress.toFixed(0)}%</span>
                                    </div>
                                    <form action={updateGoalProgress} className="flex gap-2">
                                        <input type="hidden" name="id" value={goal.id} />
                                        <input name="currentValue" type="number" step="0.01" placeholder="Atualizar" className="flex-1 px-2 py-1 text-[10px] rounded-lg border border-zinc-200 bg-white dark:bg-zinc-900 dark:border-zinc-700 outline-none" />
                                        <button type="submit" className="px-2 py-1 text-[10px] font-bold rounded-lg bg-red-600 text-white">OK</button>
                                    </form>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* Add Goal Form */}
            <details className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                <summary className="cursor-pointer text-sm font-bold text-zinc-600 dark:text-zinc-400 flex items-center gap-2">
                    <Plus className="h-4 w-4" /> Adicionar Meta
                </summary>
                <form action={createGoal} className="mt-4 grid grid-cols-1 sm:grid-cols-4 gap-4">
                    <input type="hidden" name="bandId" value={band.id} />
                    <input name="title" required placeholder="Ex: Faturar R$ 50.000" className="px-3 py-2 text-sm rounded-xl border border-zinc-200 bg-zinc-50 dark:bg-zinc-800 dark:border-zinc-700 outline-none" />
                    <input name="targetValue" type="number" step="0.01" required placeholder="Meta (valor)" className="px-3 py-2 text-sm rounded-xl border border-zinc-200 bg-zinc-50 dark:bg-zinc-800 dark:border-zinc-700 outline-none" />
                    <select name="unit" className="px-3 py-2 text-sm rounded-xl border border-zinc-200 bg-zinc-50 dark:bg-zinc-800 dark:border-zinc-700 outline-none">
                        <option value="BRL">R$ (Reais)</option>
                        <option value="GIGS">Shows</option>
                        <option value="SALES">Vendas</option>
                    </select>
                    <button type="submit" className="px-4 py-2 text-sm font-bold rounded-xl bg-red-600 text-white hover:bg-red-500 transition-colors">Criar Meta</button>
                </form>
            </details>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-7">
                <div className="lg:col-span-4 space-y-6">
                    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-lg font-bold text-foreground mb-1">Visão Geral de Receita</h2>
                        <p className="text-xs text-zinc-500 mb-6">Faturamento dos últimos shows.</p>
                        <DashboardOverviewChart data={overviewChartData} />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Logistics Widget */}
                        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                                <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                                    <Car className="h-4 w-4" />
                                </div>
                                Próxima Logística
                            </h2>
                            {recentTrip ? (
                                <div className="space-y-4">
                                    <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50">
                                        <p className="text-sm font-bold text-zinc-900 dark:text-zinc-100">{recentTrip.eventName}</p>
                                        <p className="text-[10px] text-zinc-500">{recentTrip.city} • {recentTrip.date || "Data a definir"}</p>
                                        <div className="mt-2 flex items-center gap-2">
                                            <span className="text-[10px] px-2 py-0.5 bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 rounded-full font-bold">
                                                🏨 {recentTrip.hotel || "Sem hotel"}
                                            </span>
                                            <span className="text-[10px] px-2 py-0.5 bg-secondary/10 text-secondary dark:bg-red-900/30 dark:text-red-400 rounded-full font-bold">
                                                👥 {recentTrip.rooms.length} quartos
                                            </span>
                                        </div>
                                    </div>
                                    <Link href="/dashboard/logistics/hotel">
                                        <Button variant="outline" className="w-full text-xs h-8 rounded-xl">Ver Detalhes</Button>
                                    </Link>
                                </div>
                            ) : (
                                <div className="text-center py-4 space-y-2">
                                    <p className="text-xs text-zinc-500">Sem viagens agendadas.</p>
                                    <Link href="/dashboard/logistics/hotel">
                                        <Button variant="ghost" className="text-xs h-8">Criar Logística</Button>
                                    </Link>
                                </div>
                            )}
                        </div>

                        {/* Inventory/Tech Widget */}
                        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                                <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                                    <Wrench className="h-4 w-4" />
                                </div>
                                Status Técnico
                            </h2>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50">
                                    <div>
                                        <p className="text-[10px] font-bold text-zinc-500 uppercase">Patrimônio</p>
                                        <p className="text-lg font-black text-foreground">{technicalEquity.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-[10px] font-bold text-zinc-500 uppercase">Itens</p>
                                        <p className="text-lg font-black text-foreground">{equipment.length}</p>
                                    </div>
                                </div>
                                <div className="flex gap-2">
                                    <Link href="/dashboard/inventory" className="flex-1">
                                        <Button variant="outline" className="w-full text-xs h-8 rounded-xl">Inventário</Button>
                                    </Link>
                                    <Link href="/dashboard/rider/stage-plot" className="flex-1">
                                        <Button variant="outline" className="w-full text-xs h-8 rounded-xl">Mapa Palco</Button>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-lg font-bold text-foreground mb-1">Status da Banda</h2>
                        <p className="text-xs text-zinc-500 mb-6">Integridade dos equipamentos e preparativos.</p>

                        <div className="space-y-5">
                            <div>
                                <div className="flex items-center justify-between mb-1">
                                    <span className="text-sm font-bold text-foreground">Inventário Técnico</span>
                                    <span className="text-xs font-bold text-secondary">100% Operacional</span>
                                </div>
                                <div className="h-2 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-secondary w-full" />
                                </div>
                            </div>
                            <div>
                                <div className="flex items-center justify-between mb-1">
                                    <span className="text-sm font-bold text-foreground">Logística (Próximo Show)</span>
                                    <span className="text-xs font-bold text-amber-500">{recentTrip ? "Em andamento" : "Pendente"}</span>
                                </div>
                                <div className="h-2 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                                    <div className={`h-full bg-amber-500 ${recentTrip ? 'w-[75%]' : 'w-[20%]'}`} />
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div className="lg:col-span-3 space-y-6">
                    <Calendar gigs={gigs} bandId={band.id} />

                    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-lg font-bold text-foreground mb-1">Próximos Eventos</h2>
                        <p className="text-xs text-zinc-500 mb-6">Agenda confirmada para os próximos dias.</p>
                        <UpcomingEventsList data={upcomingEventsData} />
                    </div>

                    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-lg font-bold text-foreground mb-1">Atividade Recente</h2>
                        <p className="text-xs text-zinc-500 mb-6">Ações da equipe e atualizações do sistema.</p>
                        <RecentActivityFeed data={recentActivityData} />
                    </div>

                    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-lg font-bold text-foreground mb-4">Top Contratantes</h2>
                        {contractorRanking.length > 0 ? (
                            <div className="space-y-3">
                                {contractorRanking.map((c: any, i: number) => (
                                    <div key={i} className="flex items-center gap-3">
                                        <span className="text-[10px] font-bold text-zinc-500 w-4">{i + 1}.</span>
                                        <span className="text-xs font-semibold truncate flex-shrink-0 max-w-[100px]">{c.name}</span>
                                        <div className="h-1.5 flex-1 bg-zinc-800 rounded-full overflow-hidden">
                                            <div className="h-full bg-secondary" style={{ width: `${(c.total / contractorRanking[0].total) * 100}%` }} />
                                        </div>
                                        <span className="text-[10px] font-bold text-secondary flex-shrink-0">
                                            {c.total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 })}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-xs text-zinc-500 italic">Cadastre contratantes no CRM.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
