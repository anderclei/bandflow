import { getActiveBand } from "@/lib/getActiveBand";
import { prisma } from "@/lib/prisma";
import { Copyright, Music, Plus, TrendingUp, DollarSign, Info } from "lucide-react";
import { redirect } from "next/navigation";
import { SongPublishingDetails } from "@/components/dashboard/SongPublishingDetails";
import Link from "next/link";

export default async function PublishingPage({
    searchParams,
}: {
    searchParams: Promise<{ songId?: string }>;
}) {
    const selectedSongId = (await searchParams).songId;

    const { band } = await getActiveBand({
        songs: {
            include: {
                splits: {
                    include: { member: { include: { user: true } } }
                },
                payments: true
            },
            orderBy: { title: 'asc' }
        },
        members: {
            include: { user: true }
        }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const songs = (band as any).songs || [];
    const members = (band as any).members || [];
    const selectedSong = songs.find((s: any) => s.id === selectedSongId);

    const totalRoyalties = songs.reduce((acc: number, song: any) => {
        return acc + song.payments.reduce((pAcc: number, p: any) => pAcc + p.amount, 0);
    }, 0);

    const formatCurrency = (value: number) => {
        return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    };

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                        <Copyright className="h-8 w-8 text-secondary" />
                        Gestão de Direitos (Publishing)
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Controle seus códigos ISRC, ISWC e a divisão de royalties da banda.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <div className="flex items-center gap-x-3">
                        <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                            <TrendingUp className="h-5 w-5" />
                        </div>
                        <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">Total Arrecadado</p>
                    </div>
                    <p className="mt-4 text-3xl font-bold text-foreground">{formatCurrency(totalRoyalties)}</p>
                    <p className="mt-1 text-xs text-zinc-500">Soma de todos os relatórios processados</p>
                </div>

                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <div className="flex items-center gap-x-3">
                        <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-950/30 text-blue-600">
                            <Music className="h-5 w-5" />
                        </div>
                        <p className="text-sm font-semibold text-zinc-600 dark:text-zinc-400">Obras no Catálogo</p>
                    </div>
                    <p className="mt-4 text-3xl font-bold text-foreground">{songs.length}</p>
                    <p className="mt-1 text-xs text-zinc-500">Músicas com metadados vinculados</p>
                </div>

                <div className="rounded-3xl bg-secondary/10 p-6 shadow-sm ring-1 ring-secondary/20">
                    <div className="flex items-center gap-x-3 text-secondary">
                        <div className="p-2 rounded-xl bg-secondary/20 text-secondary">
                            <Info className="h-5 w-5" />
                        </div>
                        <p className="text-sm font-semibold opacity-80">Próximo Passo</p>
                    </div>
                    <p className="mt-4 text-lg font-bold text-foreground">Vincule seus ISRCs</p>
                    <p className="mt-1 text-xs text-secondary opacity-80">Mantenha os códigos em dia para facilitar o rateio automático.</p>
                </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 items-start">
                <div className="xl:col-span-2 rounded-3xl bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 overflow-hidden">
                    <table className="w-full text-left">
                        <thead className="bg-zinc-50 dark:bg-zinc-800/50 text-zinc-500 dark:text-zinc-400 text-xs uppercase font-bold">
                            <tr>
                                <th className="px-6 py-4">Obra / Título</th>
                                <th className="px-6 py-4">ISRC</th>
                                <th className="px-6 py-4">Splits</th>
                                <th className="px-6 py-4 text-right">Total Gerado</th>
                                <th className="px-6 py-4"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
                            {songs.map((song: any) => (
                                <tr key={song.id} className={`group hover:bg-zinc-50 dark:hover:bg-zinc-800/30 transition-colors ${selectedSongId === song.id ? 'bg-secondary/10' : ''}`}>
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded-lg bg-secondary/10 shadow-sm text-secondary">
                                                <Music className="h-4 w-4" />
                                            </div>
                                            <div>
                                                <span className="font-semibold text-foreground block">{song.title}</span>
                                                <span className="text-[10px] text-zinc-500 uppercase font-bold">{song.artist || "---"}</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-[11px] font-mono text-zinc-500">
                                        {song.isrc || "---"}
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex -space-x-2 overflow-hidden">
                                            {song.splits.map((split: any) => (
                                                <div
                                                    key={split.id}
                                                    className="inline-block h-6 w-6 rounded-full ring-2 ring-white dark:ring-zinc-900 bg-secondary text-white flex items-center justify-center text-[8px] font-bold"
                                                    title={`${split.member.user.name}: ${split.percentage}%`}
                                                >
                                                    {split.member.user.name?.charAt(0)}
                                                </div>
                                            ))}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-right font-bold text-foreground text-sm">
                                        {formatCurrency(song.payments.reduce((acc: number, p: any) => acc + p.amount, 0))}
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <Link
                                            href={`/dashboard/publishing?songId=${song.id}`}
                                            className={`text-xs font-black uppercase transition-colors ${selectedSongId === song.id ? 'text-secondary' : 'text-zinc-400 hover:text-secondary/80'}`}
                                        >
                                            {selectedSongId === song.id ? 'Selecionado' : 'Gerenciar'}
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="xl:col-span-1">
                    {selectedSong ? (
                        <div className="sticky top-8 rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <div className="flex items-center justify-between mb-8">
                                <h2 className="text-xl font-bold text-foreground">{selectedSong.title}</h2>
                                <Link href="/dashboard/publishing" className="text-xs text-zinc-400 hover:text-zinc-600 underline">Fechar</Link>
                            </div>
                            <SongPublishingDetails song={selectedSong} members={members} />
                        </div>
                    ) : (
                        <div className="rounded-3xl bg-zinc-50/50 p-12 text-center border-2 border-dashed border-zinc-200 dark:bg-zinc-900/50 dark:border-zinc-800">
                            <Info className="h-8 w-8 text-zinc-400 mx-auto mb-4" />
                            <h3 className="text-sm font-bold text-zinc-600">Nenhuma música selecionada</h3>
                            <p className="mt-2 text-xs text-zinc-500">Selecione uma música ao lado para gerenciar splits e pagamentos.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
