import { PlusCircle, Music2, ListMusic } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SongList } from "@/components/dashboard/repertoire/SongList"
import { SetlistBuilder } from "@/components/dashboard/repertoire/SetlistBuilder"
import { getActiveBand } from "@/lib/getActiveBand"
import { redirect } from "next/navigation"
import { AddSongDialog } from "@/components/dashboard/repertoire/AddSongDialog"

export default async function RepertoirePage() {
    const { band } = await getActiveBand({
        songs: {
            orderBy: { createdAt: 'desc' }
        },
        setlists: {
            include: { items: { include: { song: true } } },
            orderBy: { createdAt: 'desc' }
        }
    });

    if (!band) {
        redirect("/dashboard");
    }

    const songs = (band as any).songs || [];

    return (
        <div className="flex-1 space-y-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Music2 className="h-8 w-8 text-secondary" />
                        Gerenciamento de Repertório
                    </h1>
                    <p className="mt-1 text-zinc-500">
                        Catálogo de músicas e montagem de setlists inteligentes.
                    </p>
                </div>
                <AddSongDialog />
            </div>

            <Tabs defaultValue="songs" className="space-y-6">
                <TabsList className="bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800">
                    <TabsTrigger value="songs" className="data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-800 font-bold">
                        <Music2 className="mr-2 h-4 w-4" />
                        Biblioteca Musical
                    </TabsTrigger>
                    <TabsTrigger value="setlists" className="data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-800 font-bold">
                        <ListMusic className="mr-2 h-4 w-4" />
                        Construtor de Setlists
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="songs" className="space-y-4">
                    <Card className="border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950/40">
                        <CardHeader>
                            <CardTitle className="text-xl font-bold">Todas as Músicas</CardTitle>
                            <CardDescription>
                                Visualize e gerencie o repertório completo da sua banda.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <SongList initialSongs={songs} />
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="setlists" className="space-y-4">
                    <SetlistBuilder songs={songs} />
                </TabsContent>
            </Tabs>
        </div>
    )
}
