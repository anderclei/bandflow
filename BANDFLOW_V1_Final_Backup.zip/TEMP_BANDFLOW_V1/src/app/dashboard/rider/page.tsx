import { getActiveBand } from "@/lib/getActiveBand";
import { AudioLines } from "lucide-react";
import { redirect } from "next/navigation";
import { TechnicalRiderManager } from "@/components/dashboard/TechnicalRiderManager";

export default async function RiderPage() {
    const { band } = await getActiveBand({
        formats: {
            orderBy: { name: 'asc' }
        }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const formats = (band.formats as any[]) || [];

    return (
        <div className="space-y-8 pb-20">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between px-4 lg:px-0">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <AudioLines className="h-8 w-8 text-secondary" />
                        Rider & Doc Técnica
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie o mapa de palco, lista de canais e exigências técnicas de forma independente para cada formato de show.
                        Tudo em um só lugar, gerado automaticamente em PDF.
                    </p>
                </div>
            </div>

            <div className="px-4 lg:px-0">
                <TechnicalRiderManager formats={formats} bandId={band.id} bandName={band.name} />
            </div>
        </div>
    );
}
