import { getActiveBand } from "@/lib/getActiveBand";
import { createSetlist, deleteSetlist } from "@/app/actions/setlists";
import SetlistManager from "@/components/dashboard/SetlistManager";
import { Music, Plus, Trash2, Calendar as CalendarIcon, Maximize2 } from "lucide-react";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function SetlistsPage({
    searchParams,
}: {
    searchParams: Promise<{ id?: string }>;
}) {
    const selectedId = (await searchParams).id;

    const { band } = await getActiveBand({
        setlists: {
            orderBy: { updatedAt: 'desc' },
            include: { items: { include: { song: true }, orderBy: { position: 'asc' } } }
        },
        songs: { orderBy: { title: 'asc' } }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const setlists = (band as any).setlists || [];
    const availableSongs = (band as any).songs || [];

    const selectedSetlist = setlists.find((s: any) => s.id === selectedId) || setlists[0];

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Music className="h-8 w-8 text-secondary" />
                        Setlists & Programação
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Organize a ordem das músicas para seus shows.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
                {/* Setlist List */}
                <div className="lg:col-span-1 space-y-4">
                    <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-lg font-bold text-foreground mb-4">Seus Setlists</h2>
                        <div className="space-y-2">
                            {setlists.map((setlist: any) => (
                                <div key={setlist.id} className="group relative">
                                    <a
                                        href={`/dashboard/setlists?id=${setlist.id}`}
                                        className={`block w-full text-left p-3 rounded-xl transition-all ${selectedId === setlist.id || (!selectedId && setlist.id === setlists[0]?.id)
                                            ? "bg-secondary/10 text-secondary dark:bg-secondary/20 dark:text-secondary font-semibold ring-1 ring-secondary/20"
                                            : "hover:bg-zinc-50 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400"
                                            }`}
                                    >
                                        <div className="flex items-center gap-2">
                                            <CalendarIcon className="h-4 w-4" />
                                            <span className="truncate">{setlist.title}</span>
                                        </div>
                                    </a>
                                    <form action={async () => {
                                        "use server";
                                        await deleteSetlist(setlist.id);
                                    }} className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button className="p-1.5 text-zinc-400 hover:text-red-500">
                                            <Trash2 className="h-3.5 w-3.5" />
                                        </button>
                                    </form>
                                </div>
                            ))}
                        </div>

                        <div className="mt-6 pt-6 border-t border-zinc-100 dark:border-zinc-800">
                            <form action={createSetlist} className="space-y-3">
                                <input
                                    name="title"
                                    required
                                    placeholder="Nome do Novo Setlist"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                />
                                <button
                                    type="submit"
                                    className="w-full flex items-center justify-center gap-2 rounded-xl bg-zinc-900 py-2.5 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors dark:bg-white dark:text-black dark:hover:bg-zinc-200"
                                >
                                    <Plus className="h-4 w-4" />
                                    Novo Setlist
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                {/* Manager Area */}
                <div className="lg:col-span-3">
                    {selectedSetlist ? (
                        <div className="space-y-6">
                            <div className="flex items-center gap-3 p-4 rounded-3xl bg-secondary/5 ring-1 ring-secondary/20">
                                <div className="p-3 rounded-2xl bg-secondary text-white shadow-lg shadow-secondary/20">
                                    <Music className="h-6 w-6" />
                                </div>
                                <div>
                                    <h2 className="text-2xl font-bold text-foreground">{selectedSetlist.title}</h2>
                                    <p className="text-sm text-zinc-500">{selectedSetlist.items.length} músicas em ordem</p>
                                </div>
                                <div className="ml-auto">
                                    <Link
                                        href={`/dashboard/setlists/${selectedSetlist.id}/stage`}
                                        className="inline-flex items-center gap-2 rounded-xl bg-zinc-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-zinc-800 transition-all dark:bg-white dark:text-black dark:hover:bg-zinc-200 shadow-lg shadow-zinc-900/10"
                                    >
                                        <Maximize2 className="h-4 w-4" />
                                        Abrir no Palco
                                    </Link>
                                </div>
                            </div>

                            <SetlistManager
                                setlist={selectedSetlist}
                                availableSongs={availableSongs}
                            />
                        </div>
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center rounded-3xl border-2 border-dashed border-zinc-200 dark:border-zinc-800 p-12 text-center text-zinc-500">
                            <Music className="h-12 w-12 mb-4 opacity-20" />
                            <h3 className="text-lg font-bold text-foreground mb-2">Selecione ou crie um setlist</h3>
                            <p className="max-w-xs mx-auto">Visualize e gerencie a ordem das músicas para seus próximos shows.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
