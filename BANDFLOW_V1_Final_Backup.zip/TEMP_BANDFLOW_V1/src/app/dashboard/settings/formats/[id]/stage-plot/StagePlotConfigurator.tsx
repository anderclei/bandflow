"use client";

import { useState } from "react";
import {
    DndContext,
    useSensor,
    useSensors,
    MouseSensor,
    TouchSensor,
    DragEndEvent,
    useDraggable,
    useDroppable,
    Modifier
} from "@dnd-kit/core";
import {
    restrictToParentElement,
} from "@dnd-kit/modifiers";
import { Mic2, MonitorSpeaker, Box, Drum, Music, Guitar, Zap, Save, Trash2, Edit2, Loader2, Volume2, Monitor } from "lucide-react";
import { updateStagePlot } from "@/app/actions/stagePlot";

interface StageItem {
    id: string;
    type: "mic" | "amp" | "monitor" | "drums" | "keys" | "guitar" | "power" | "di";
    x: number;
    y: number;
    label: string;
}

const ICONS = {
    mic: { icon: Mic2, label: "Microfone" },
    amp: { icon: MonitorSpeaker, label: "Amplificador" },
    monitor: { icon: Volume2, label: "Retorno" },
    drums: { icon: Drum, label: "Bateria" },
    keys: { icon: Music, label: "Teclado" },
    guitar: { icon: Guitar, label: "Instrumento" },
    power: { icon: Zap, label: "Energia (AC)" },
    di: { icon: Box, label: "Direct Box (DI)" }
};

// -- STYLED DRAGGABLE ITEM --
function DraggableStageElement({ item, onRemove, onEdit }: { item: StageItem, onRemove: (id: string) => void, onEdit: (item: StageItem) => void }) {
    const { attributes, listeners, setNodeRef, transform } = useDraggable({
        id: item.id,
        data: item
    });

    const IconComp = ICONS[item.type].icon;

    const style = transform ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
        left: item.x,
        top: item.y,
    } : {
        left: item.x,
        top: item.y,
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...listeners}
            {...attributes}
            className="absolute z-10 group touch-none cursor-grab active:cursor-grabbing flex flex-col items-center justify-center transform -translate-x-1/2 -translate-y-1/2"
        >
            <div className="w-12 h-12 bg-zinc-900 border-2 border-secondary rounded-xl shadow-lg flex items-center justify-center text-white relative">
                <IconComp className="h-6 w-6" />

                {/* Actions (Only visible on hover outside dragging context usually, but dnd-kit can make hover tricky. Just showing simple buttons) */}
                <div className="absolute -top-10 hidden group-hover:flex gap-1 bg-white dark:bg-zinc-800 rounded-lg shadow p-1 border border-zinc-200 dark:border-zinc-700">
                    <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); onEdit(item); }}
                        className="p-1 hover:bg-zinc-100 dark:hover:bg-zinc-700 rounded text-blue-500"
                    >
                        <Edit2 className="h-3 w-3" />
                    </button>
                    <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); onRemove(item.id); }}
                        className="p-1 hover:bg-zinc-100 dark:hover:bg-zinc-700 rounded text-red-500"
                    >
                        <Trash2 className="h-3 w-3" />
                    </button>
                </div>
            </div>

            <div className="mt-1 bg-black/70 text-white text-[10px] font-bold px-2 py-0.5 rounded whitespace-nowrap pointer-events-none">
                {item.label}
            </div>
        </div>
    );
}

// -- DROP ZONE CANVAS --
function StageCanvas({ items, onRemove, onEdit }: { items: StageItem[], onRemove: (id: string) => void, onEdit: (item: StageItem) => void }) {
    const { setNodeRef } = useDroppable({
        id: "stage-canvas"
    });

    return (
        <div
            ref={setNodeRef}
            className="w-full h-full min-h-[500px] relative bg-zinc-100 dark:bg-zinc-900/50 rounded-2xl overflow-hidden border-2 border-dashed border-zinc-300 dark:border-zinc-700"
            style={{
                backgroundImage: 'radial-gradient(circle at 10px 10px, rgba(0,0,0,0.05) 2px, transparent 0)',
                backgroundSize: '40px 40px'
            }}
        >
            {/* Stage Grid Reference (Front) */}
            <div className="absolute bottom-0 left-0 right-0 h-10 border-t-2 border-secondary/30 bg-secondary/5 flex items-center justify-center pointer-events-none">
                <span className="text-zinc-400 font-bold uppercase tracking-[0.5em] text-sm">Público / Frente do Palco</span>
            </div>

            {/* Render Items */}
            {items.map(item => (
                <DraggableStageElement
                    key={item.id}
                    item={item}
                    onRemove={onRemove}
                    onEdit={onEdit}
                />
            ))}
        </div>
    );
}

export function StagePlotConfigurator({ formatId, initialPlot }: { formatId: string, initialPlot: StageItem[] }) {
    const [items, setItems] = useState<StageItem[]>(initialPlot);
    const [isSaving, setIsSaving] = useState(false);

    // Edit Modal State
    const [editingItem, setEditingItem] = useState<StageItem | null>(null);

    const sensors = useSensors(
        useSensor(MouseSensor, {
            // Require mouse to move 5px before dragging starts so clicks for edit/remove work
            activationConstraint: {
                distance: 5,
            },
        }),
        useSensor(TouchSensor, {
            activationConstraint: {
                delay: 250,
                tolerance: 5,
            },
        })
    );

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, delta } = event;

        if (active.id) {
            setItems((items) => {
                const itemIndex = items.findIndex((i) => i.id === active.id);
                if (itemIndex === -1) return items;

                const newItems = [...items];
                const item = newItems[itemIndex];

                // Update position
                item.x += delta.x;
                item.y += delta.y;

                return newItems;
            });
        }
    };

    const addItem = (type: keyof typeof ICONS) => {
        const newItem: StageItem = {
            id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            type,
            x: 100 + (Math.random() * 50), // Spawn near top left with slight offset
            y: 100 + (Math.random() * 50),
            label: ICONS[type].label
        };
        setItems([...items, newItem]);
    };

    const removeItem = (id: string) => {
        setItems(items.filter(i => i.id !== id));
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            await updateStagePlot(formatId, JSON.stringify(items));
            alert("Mapa de Palco salvo com sucesso!");
        } catch (error) {
            console.error(error);
            alert("Erro ao salvar.");
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="flex flex-col lg:flex-row h-full">
            {/* Sidebar Palette */}
            <div className="w-full lg:w-72 bg-zinc-50 dark:bg-zinc-900/80 border-r border-zinc-100 dark:border-zinc-800 p-6 flex flex-col h-[500px] lg:h-auto overflow-y-auto shrink-0">
                <h3 className="font-bold text-foreground mb-4">Adicionar Equipamento</h3>

                <div className="grid grid-cols-2 gap-3 mb-8">
                    {(Object.keys(ICONS) as Array<keyof typeof ICONS>).map((key) => {
                        const Icon = ICONS[key].icon;
                        const label = ICONS[key].label;

                        return (
                            <button
                                key={key}
                                onClick={() => addItem(key)}
                                className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 hover:border-secondary hover:text-secondary transition-colors shadow-sm text-zinc-600 dark:text-zinc-400 group"
                            >
                                <Icon className="h-6 w-6 group-hover:scale-110 transition-transform" />
                                <span className="text-[10px] font-bold uppercase text-center">{label}</span>
                            </button>
                        );
                    })}
                </div>

                <div className="mt-auto">
                    <button
                        onClick={handleSave}
                        disabled={isSaving}
                        className="w-full flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-sm font-semibold text-white hover:opacity-90 transition-colors disabled:opacity-50 shadow-md shadow-secondary/20"
                    >
                        {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                        Salvar Mapa (JSON)
                    </button>
                    <p className="text-xs text-center text-zinc-500 mt-3">
                        As alterações não são salvas automaticamente.
                    </p>
                </div>
            </div>

            {/* Canvas Area */}
            <div className="flex-1 p-6 bg-zinc-50/50 dark:bg-zinc-950/20 min-h-[600px] relative">
                <DndContext
                    sensors={sensors}
                    onDragEnd={handleDragEnd}
                    modifiers={[restrictToParentElement]}
                >
                    <StageCanvas items={items} onRemove={removeItem} onEdit={setEditingItem} />
                </DndContext>

                {/* Edit Modal (Overlay) */}
                {editingItem && (
                    <div className="absolute inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm">
                        <div className="bg-white dark:bg-zinc-900 rounded-2xl p-6 w-full max-w-sm shadow-xl border border-zinc-200 dark:border-zinc-800">
                            <h3 className="font-bold text-lg mb-4">Editar Rótulo (Label)</h3>
                            <input
                                type="text"
                                value={editingItem.label}
                                onChange={(e) => setEditingItem({ ...editingItem, label: e.target.value })}
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20 mb-4"
                                autoFocus
                            />
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setEditingItem(null)}
                                    className="flex-1 rounded-xl bg-zinc-100 dark:bg-zinc-800 px-4 py-2 text-sm font-semibold text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200"
                                >
                                    Cancelar
                                </button>
                                <button
                                    onClick={() => {
                                        setItems(items.map(i => i.id === editingItem.id ? editingItem : i));
                                        setEditingItem(null);
                                    }}
                                    className="flex-1 rounded-xl bg-secondary px-4 py-2 text-sm font-semibold text-white hover:opacity-90"
                                >
                                    Confirmar
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
