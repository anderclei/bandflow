import { getActiveBand } from "@/lib/getActiveBand";
import { prisma } from "@/lib/prisma";
import { redirect, notFound } from "next/navigation";
import { StagePlotConfigurator } from "./StagePlotConfigurator";
import { ArrowLeft, Map } from "lucide-react";
import Link from "next/link";

export default async function StagePlotPage({
    params,
}: {
    params: Promise<{ id: string }>;
}) {
    const id = (await params).id;
    const { band } = await getActiveBand();

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const format = await prisma.showFormat.findUnique({
        where: { id, bandId: band.id },
    });

    if (!format) {
        notFound();
    }

    // Default stage plot configuration
    const initialPlot = format.stagePlot ? JSON.parse(format.stagePlot) : [];

    return (
        <div className="space-y-6 h-full flex flex-col">
            <div className="flex items-center gap-4">
                <Link
                    href="/dashboard/settings/formats"
                    className="p-2 rounded-xl bg-white border border-zinc-200 text-zinc-600 hover:text-secondary hover:border-secondary/30 transition-all dark:bg-zinc-900 dark:border-zinc-800"
                >
                    <ArrowLeft className="h-5 w-5" />
                </Link>
                <div>
                    <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
                        <Map className="h-6 w-6 text-secondary" />
                        Mapa de Palco: {format.name}
                    </h1>
                    <p className="text-zinc-500 text-sm mt-1">
                        Arraste e solte equipamentos para configurar a disposição no palco para este formato de show.
                    </p>
                </div>
            </div>

            <div className="flex-1 bg-white rounded-3xl overflow-hidden shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 flex flex-col">
                <StagePlotConfigurator formatId={format.id} initialPlot={initialPlot} />
            </div>
        </div>
    );
}
