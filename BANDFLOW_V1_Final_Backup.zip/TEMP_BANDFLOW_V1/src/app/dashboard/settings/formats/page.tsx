import { getActiveBand } from "@/lib/getActiveBand";
import { prisma } from "@/lib/prisma";
import { AudioLines, Plus, Trash2, ArrowLeft, DollarSign } from "lucide-react";
import { redirect } from "next/navigation";
import Link from "next/link";
import { createShowFormat, deleteShowFormat } from "@/app/actions/formats";

export default async function ShowFormatsPage() {
    const { band } = await getActiveBand({
        formats: {
            orderBy: { createdAt: 'asc' }
        }
    });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const formats = band.formats || [];

    return (
        <div className="space-y-8">
            <div className="flex items-center gap-4">
                <Link
                    href="/dashboard/settings"
                    className="p-2 -ml-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors text-zinc-500"
                >
                    <ArrowLeft className="h-5 w-5" />
                </Link>
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <AudioLines className="h-8 w-8 text-secondary" />
                        Formatos de Show
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Cada formato representa uma formação diferente da banda (ex: Acústico, Completo).
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
                {/* Form to add new format */}
                <div className="lg:col-span-1">
                    <div className="sticky top-8 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                            <Plus className="h-5 w-5 text-secondary" />
                            Novo Formato
                        </h2>
                        <form action={createShowFormat.bind(null, band.id)} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Nome</label>
                                <input
                                    name="name"
                                    required
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="Ex: Formação Acústica"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Valor Base (Opcional)</label>
                                <div className="relative">
                                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <DollarSign className="h-4 w-4 text-zinc-400" />
                                    </div>
                                    <input
                                        name="basePrice"
                                        type="number"
                                        step="0.01"
                                        className="w-full pl-9 rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="0.00"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Descrição</label>
                                <textarea
                                    name="description"
                                    rows={3}
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="Detalhes deste formato..."
                                />
                            </div>
                            <button
                                type="submit"
                                className="w-full rounded-xl bg-secondary py-3 text-sm font-semibold text-white hover:opacity-90 transition-colors shadow-sm shadow-secondary/20"
                            >
                                Adicionar Formato
                            </button>
                        </form>
                    </div>
                </div>

                {/* List of formats */}
                <div className="lg:col-span-2 space-y-4">
                    {formats.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {formats.map((format: any) => (
                                <div key={format.id} className="group relative flex flex-col h-full rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 hover:ring-secondary/50 dark:bg-zinc-900 dark:ring-zinc-800 transition-all">
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="flex items-center gap-3">
                                            <div className="p-3 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 group-hover:bg-secondary/10 group-hover:text-secondary dark:group-hover:bg-secondary/20 transition-colors">
                                                <AudioLines className="h-5 w-5" />
                                            </div>
                                            <div>
                                                <h3 className="font-bold text-foreground group-hover:text-secondary transition-colors">{format.name}</h3>
                                            </div>
                                        </div>

                                        <form action={async () => {
                                            "use server";
                                            await deleteShowFormat(format.id);
                                        }}>
                                            <button
                                                type="submit"
                                                className="p-2 text-zinc-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 bg-white dark:bg-zinc-900 rounded-lg shadow-sm"
                                                title="Excluir"
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </button>
                                        </form>
                                    </div>

                                    {format.description && (
                                        <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4 flex-1">
                                            {format.description}
                                        </p>
                                    )}

                                    <div className="mt-auto pt-4 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                                        <div className="flex items-center gap-2 text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                                            Base: {format.basePrice
                                                ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(format.basePrice)
                                                : "A combinar"}
                                        </div>
                                        <Link
                                            href={`/dashboard/settings/formats/${format.id}/stage-plot`}
                                            className="text-xs font-bold bg-secondary/10 text-secondary px-3 py-1.5 rounded-lg hover:bg-secondary/20 transition-colors"
                                        >
                                            Editar Mapa de Palco
                                        </Link>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <div className="inline-flex p-4 rounded-full bg-zinc-100 dark:bg-zinc-800/50 text-zinc-400 mb-4">
                                <AudioLines className="h-8 w-8" />
                            </div>
                            <h3 className="text-lg font-bold text-foreground">Nenhum formato cadastrado</h3>
                            <p className="mt-2 text-zinc-500 max-w-sm mx-auto">Adicione formatações diferentes (ex: Acústico, Completo) com preços pré-estabelecidos para facilitar suas propostas.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
