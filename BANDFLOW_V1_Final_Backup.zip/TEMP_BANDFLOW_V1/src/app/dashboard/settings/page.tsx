import { getActiveBand } from "@/lib/getActiveBand";
import { User, Shield, Music, Settings as SettingsIcon, Save, Camera } from "lucide-react";
import { redirect } from "next/navigation";
import { updateBand } from "@/app/actions/bands";
import { BandImageUpload } from "@/components/dashboard/BandImageUpload";
import { ColorPickerInput } from "@/components/dashboard/ColorPickerInput";
import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function SettingsPage() {
    const { band: activeBand, membership, session } = await getActiveBand();

    if (!activeBand) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    // SQL raw para evitar conflito com cliente Prisma desatualizado
    // O cliente Prisma conhece campos diferentes dos que existem no banco real
    const rows = await prisma.$queryRawUnsafe<any[]>(
        `SELECT id, name, slug, imageUrl, primaryColor, secondaryColor, type, description,
                respName, respDocument, createdAt,
                addressStreet, addressNumber, addressNeighborhood,
                addressZipCode, addressCity, addressState
         FROM Band WHERE id = ? LIMIT 1`,
        activeBand.id
    );
    const band = rows[0] ?? activeBand;



    const user = session?.user;

    return (
        <div className="space-y-12">
            <div>
                <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                    <SettingsIcon className="h-8 w-8 text-secondary" />
                    Configurações
                </h1>
                <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                    Gerencie os detalhes da sua conta e da banda.
                </p>
            </div>

            <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
                {/* Band Settings */}
                <div className="space-y-6">
                    <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                            <Music className="h-5 w-5" />
                        </div>
                        <h2 className="text-xl font-bold text-foreground">Perfil da Banda</h2>
                    </div>

                    <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 space-y-8">
                        <div className="flex items-center gap-6">
                            <BandImageUpload defaultImage={band.imageUrl} />
                            <div>
                                <h3 className="text-lg font-bold text-foreground">{band.name}</h3>
                                <div className="flex flex-col gap-1">
                                    <p className="text-sm text-zinc-500">Administrador desde {new Date(band.createdAt).toLocaleDateString('pt-BR')}</p>
                                    <a
                                        href={`/band/${band.slug}`}
                                        target="_blank"
                                        className="text-xs text-secondary hover:underline font-medium"
                                    >
                                        Ver perfil público →
                                    </a>
                                </div>
                            </div>
                        </div>

                        <form action={updateBand} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="md:col-span-2">
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Nome da Banda / Escritório</label>
                                    <input
                                        name="name"
                                        defaultValue={(band as any).name}
                                        required
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Cor</label>
                                    <ColorPickerInput
                                        name="secondaryColor"
                                        defaultValue={(band as any).secondaryColor || "#10b981"}
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Responsável</label>
                                    <input
                                        name="respName"
                                        defaultValue={(band as any).respName || ""}
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    />
                                </div>

                                <div className="md:col-span-2">
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">CNPJ / CPF</label>
                                    <input
                                        name="respDocument"
                                        defaultValue={(band as any).respDocument || ""}
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    />
                                </div>
                            </div>

                            <div className="pt-6 border-t border-zinc-100 dark:border-zinc-800 space-y-4">
                                <h4 className="text-sm font-bold text-foreground">Endereço Completo</h4>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div className="md:col-span-3">
                                        <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Logradouro (Rua/Av)</label>
                                        <input
                                            name="addressStreet"
                                            defaultValue={(band as any).addressStreet || ""}
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Nº</label>
                                        <input
                                            name="addressNumber"
                                            defaultValue={(band as any).addressNumber || ""}
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        />
                                    </div>
                                    <div className="md:col-span-2">
                                        <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Bairro</label>
                                        <input
                                            name="addressNeighborhood"
                                            defaultValue={(band as any).addressNeighborhood || ""}
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        />
                                    </div>
                                    <div className="md:col-span-2">
                                        <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">CEP</label>
                                        <input
                                            name="addressZipCode"
                                            defaultValue={(band as any).addressZipCode || ""}
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                            placeholder="00000-000"
                                        />
                                    </div>
                                    <div className="md:col-span-3">
                                        <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">Cidade</label>
                                        <input
                                            name="addressCity"
                                            defaultValue={(band as any).addressCity || ""}
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-bold text-zinc-500 uppercase mb-1">UF</label>
                                        <input
                                            name="addressState"
                                            defaultValue={(band as any).addressState || ""}
                                            maxLength={2}
                                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-3 text-sm outline-none focus:ring-2 focus:ring-secondary/20 uppercase text-center"
                                            placeholder="SP"
                                        />
                                    </div>
                                </div>
                            </div>


                            {membership.role === "ADMIN" ? (
                                <button type="submit" className="flex items-center justify-center gap-2 w-full rounded-xl bg-zinc-900 py-3 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors dark:bg-white dark:text-black dark:hover:bg-zinc-200 mt-6">
                                    <Save className="h-4 w-4" />
                                    Salvar Alterações
                                </button>
                            ) : (
                                <div className="p-4 rounded-xl bg-orange-50 dark:bg-orange-950/30 text-orange-600 dark:text-orange-400 text-sm text-center font-medium mt-6">
                                    Apenas administradores podem editar o perfil da banda.
                                </div>
                            )}
                        </form>

                    </div>
                </div>

                {/* User Settings */}
                <div className="space-y-6">
                    <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-950/30 text-blue-600">
                            <User className="h-5 w-5" />
                        </div>
                        <h2 className="text-xl font-bold text-foreground">Sua Conta</h2>
                    </div>

                    <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 space-y-8">
                        <div className="flex items-center gap-6">
                            {(user as any)?.image ? (
                                <img src={(user as any).image} alt="" className="h-24 w-24 rounded-3xl object-cover" />
                            ) : (
                                <div className="h-24 w-24 rounded-3xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-400">
                                    <User className="h-10 w-10" />
                                </div>
                            )}
                            <div>
                                <h3 className="text-lg font-bold text-foreground">{(user as any)?.name}</h3>
                                <p className="text-sm text-zinc-500">{(user as any)?.email}</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <Shield className="h-5 w-5 text-secondary" />
                                        <div>
                                            <p className="text-sm font-bold text-foreground">Permissão</p>
                                            <p className="text-xs text-zinc-500">{membership.role}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <Link
                                href="/dashboard/settings/formats"
                                className="block w-full text-center rounded-xl bg-zinc-900 py-3 text-sm font-semibold text-white hover:bg-zinc-800 transition-colors dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-zinc-300"
                            >
                                Gerenciar Formatos de Show
                            </Link>

                            <button className="w-full rounded-xl bg-zinc-100 py-3 text-sm font-semibold text-zinc-600 hover:bg-zinc-200 transition-colors dark:bg-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-700">
                                Solicitar Mudança de E-mail
                            </button>

                            <button className="w-full rounded-xl bg-red-50 py-3 text-sm font-semibold text-red-600 hover:bg-red-100 transition-colors dark:bg-red-950/20 dark:text-red-400 dark:hover:bg-red-950/40">
                                Excluir Minha Conta
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
