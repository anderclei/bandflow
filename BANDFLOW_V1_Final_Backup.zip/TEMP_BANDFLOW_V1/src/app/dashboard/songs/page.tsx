import { getActiveBand } from "@/lib/getActiveBand";
import { createSong, deleteSong } from "@/app/actions/songs";
import { Music, Plus, Trash2, Clock, Paperclip, ChevronRight } from "lucide-react";
import { redirect } from "next/navigation";
import { cn } from "@/lib/utils";
import { SongFileUpload } from "@/components/dashboard/SongFileUpload";

export default async function SongsPage() {
    const { band } = await getActiveBand({ songs: { orderBy: { createdAt: 'desc' } } });

    if (!band) {
        return <div className="p-8 text-center"><h2 className="text-xl">Você ainda não possui um escritório/banda atribuído. Solicite acesso ao suporte.</h2></div>;
    }

    const songs = (band as any).songs || [];

    const formatDuration = (seconds: number | null) => {
        if (!seconds) return "--:--";
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, "0")} `;
    };

    return (
        <div className="space-y-8">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <Music className="h-8 w-8 text-secondary" />
                        Repositório de Músicas
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie o repertório completo da sua banda.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
                {/* Form to add song */}
                <div className="lg:col-span-1">
                    <div className="sticky top-8 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                            <Plus className="h-5 w-5 text-secondary" />
                            Nova Música
                        </h2>
                        <form action={createSong} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Título</label>
                                <input
                                    name="title"
                                    required
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="Ex: Paranoid"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Artista (Opcional)</label>
                                <input
                                    name="artist"
                                    className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    placeholder="Ex: Black Sabbath"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Duração (segundos)</label>
                                    <input
                                        name="duration"
                                        type="number"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="Ex: 170"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">BPM</label>
                                    <input
                                        name="bpm"
                                        type="number"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="Ex: 120"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Tom</label>
                                    <input
                                        name="key"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="Ex: Am"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Status</label>
                                    <select
                                        name="status"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                    >
                                        <option value="READY">Pronta</option>
                                        <option value="IN_PROGRESS">Em Ensaio</option>
                                        <option value="ARCHIVED">Arquivo</option>
                                    </select>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">ISWC</label>
                                    <input
                                        name="iswc"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="Ex: T-034.522.680-1"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">Cód. Obra (ECAD)</label>
                                    <input
                                        name="workId"
                                        className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                                        placeholder="Ex: 12345678"
                                    />
                                </div>
                            </div>

                            <SongFileUpload />

                            <button
                                type="submit"
                                className="w-full rounded-xl bg-secondary py-3 text-sm font-semibold text-white hover:opacity-90 transition-colors shadow-sm"
                            >
                                Adicionar ao Repertório
                            </button>
                        </form>
                    </div>
                </div>

                {/* List of songs */}
                <div className="lg:col-span-2 space-y-4">
                    {songs.length > 0 ? (
                        <div className="rounded-3xl bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 overflow-hidden">
                            <table className="w-full text-left">
                                <thead className="bg-zinc-50 dark:bg-zinc-800/50 text-zinc-500 dark:text-zinc-400 text-xs uppercase font-bold">
                                    <tr>
                                        <th className="px-6 py-4">Música</th>
                                        <th className="px-6 py-4">Artista</th>
                                        <th className="px-6 py-4 text-center">Tom</th>
                                        <th className="px-6 py-4 text-center">BPM</th>
                                        <th className="px-6 py-4 text-center">ECAD</th>
                                        <th className="px-6 py-4 text-center">Status</th>
                                        <th className="px-6 py-4 text-right"><Clock className="inline h-3.5 w-3.5 mr-1" /> Duração</th>
                                        <th className="px-6 py-4"></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
                                    {songs.map((song: any) => (
                                        <tr key={song.id} className="group hover:bg-zinc-50 dark:hover:bg-zinc-800/30 transition-colors">
                                            <td className="px-6 py-4">
                                                <div className="flex flex-col">
                                                    <div className="flex items-center gap-3">
                                                        <div className="p-2 rounded-lg bg-secondary/10 text-secondary">
                                                            <Music className="h-4 w-4" />
                                                        </div>
                                                        <span className="font-semibold text-foreground">{song.title}</span>
                                                    </div>
                                                    {song.fileUrl && (
                                                        <a
                                                            href={song.fileUrl}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            className="ml-11 mt-1 flex items-center gap-1 text-[10px] uppercase font-bold text-secondary hover:text-secondary/80"
                                                            title="Ver Anexo"
                                                        >
                                                            <Paperclip className="h-3 w-3" />
                                                            Anexo
                                                        </a>
                                                    )}
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 text-zinc-500 dark:text-zinc-400 text-sm">
                                                {song.artist || "---"}
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                {song.key ? (
                                                    <span className="inline-flex items-center rounded-lg bg-zinc-100 px-2 py-1 text-xs font-bold text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300">
                                                        {song.key}
                                                    </span>
                                                ) : "---"}
                                            </td>
                                            <td className="px-6 py-4 text-center text-zinc-500 dark:text-zinc-400 text-sm font-mono">
                                                {song.bpm || "---"}
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                {(song.iswc || song.workId) ? (
                                                    <div className="flex flex-col gap-0.5">
                                                        {song.iswc && <span className="text-[9px] font-bold text-secondary">{song.iswc}</span>}
                                                        {song.workId && <span className="text-[9px] font-medium text-zinc-400">ID: {song.workId}</span>}
                                                    </div>
                                                ) : "---"}
                                            </td>
                                            <td className="px-6 py-4 text-center">
                                                <span className={cn(
                                                    "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold uppercase",
                                                    song.status === "READY" && "bg-secondary/10 text-secondary dark:bg-secondary/20 dark:text-secondary",
                                                    song.status === "IN_PROGRESS" && "bg-amber-100 text-amber-700 dark:bg-amber-950/30 dark:text-amber-400",
                                                    song.status === "ARCHIVED" && "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400"
                                                )}>
                                                    {song.status === "READY" ? "Pronta" : song.status === "IN_PROGRESS" ? "Ensaio" : "Arquivo"}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-zinc-500 dark:text-zinc-400 text-sm text-right font-mono">
                                                {formatDuration(song.duration)}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <form action={async () => {
                                                    "use server";
                                                    await deleteSong(song.id);
                                                }}>
                                                    <button className="p-2 text-zinc-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
                                                        <Trash2 className="h-4 w-4" />
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div className="rounded-3xl bg-white p-12 text-center ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                            <div className="inline-flex p-4 rounded-full bg-secondary/10 text-secondary mb-4">
                                <Music className="h-8 w-8" />
                            </div>
                            <h3 className="text-lg font-bold text-foreground">Sua lista está vazia</h3>
                            <p className="mt-2 text-zinc-500">Comece adicionando as músicas que sua banda toca.</p>
                        </div>
                    )}
                </div>
            </div>
        </div >
    );
}
