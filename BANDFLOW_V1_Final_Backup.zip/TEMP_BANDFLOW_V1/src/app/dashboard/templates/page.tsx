import { ContractTemplateManager } from "@/components/dashboard/contracts/ContractTemplateManager"
import { LayoutTemplate } from "lucide-react"

export default function TemplatesPage() {
    return (
        <div className="flex-1 space-y-4 p-8 pt-6">
            <div className="flex items-center justify-between pb-6 border-b border-zinc-100 dark:border-zinc-800">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <LayoutTemplate className="h-8 w-8 text-secondary" />
                        Templates de Documentos
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Crie e gerencie os modelos padrão para seus contratos e orçamentos.
                    </p>
                </div>
            </div>

            <ContractTemplateManager />
        </div>
    )
}
