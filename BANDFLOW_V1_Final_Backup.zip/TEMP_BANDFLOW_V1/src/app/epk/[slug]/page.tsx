import { prisma } from "@/lib/prisma"
import { notFound } from "next/navigation"
import { Instagram, Youtube, Download, MapPin, AudioLines, Music, Users, Camera } from "lucide-react"
import Link from "next/link"

export default async function EPKPage({ params }: { params: { slug: string } }) {
    const band = await prisma.band.findUnique({
        where: { slug: params.slug },
        include: {
            formats: true,
            members: true,
        }
    })

    if (!band) {
        notFound()
    }

    const { primaryColor, secondaryColor, name, imageUrl, shortBio, videoUrl, socialLinks, addressCity, addressState } = band as any
    const parsedLinks = socialLinks ? JSON.parse(socialLinks) : {}

    return (
        <div className="min-h-screen bg-zinc-950 text-white selection:bg-white/20">
            {/* Hero Section */}
            <div className="relative h-[60vh] md:h-[80vh] w-full flex items-end justify-center pb-20">
                <div className="absolute inset-0 z-0">
                    {imageUrl ? (
                        <img src={imageUrl} alt={name} className="w-full h-full object-cover opacity-60 mix-blend-overlay" />
                    ) : (
                        <div className="w-full h-full bg-zinc-900" />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-transparent" />
                </div>

                <div className="relative z-10 container mx-auto px-6 text-center space-y-6 max-w-4xl">
                    <h1 className="text-6xl md:text-8xl font-black tracking-tighter" style={{ color: secondaryColor || 'white' }}>
                        {name}
                    </h1>
                    {addressCity && (
                        <p className="flex items-center justify-center gap-2 text-zinc-400 font-medium tracking-widest uppercase text-sm">
                            <MapPin className="h-4 w-4" />
                            {addressCity} {addressState && `- ${addressState}`}
                        </p>
                    )}
                    <div className="flex items-center justify-center gap-4 pt-4">
                        {parsedLinks.instagram && (
                            <a href={parsedLinks.instagram} target="_blank" rel="noopener noreferrer" className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                                <Instagram className="h-5 w-5" />
                            </a>
                        )}
                        {parsedLinks.youtube && (
                            <a href={parsedLinks.youtube} target="_blank" rel="noopener noreferrer" className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                                <Youtube className="h-5 w-5" />
                            </a>
                        )}
                        {parsedLinks.spotify && (
                            <a href={parsedLinks.spotify} target="_blank" rel="noopener noreferrer" className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                                <Music className="h-5 w-5" />
                            </a>
                        )}
                    </div>
                </div>
            </div>

            {/* Content Section */}
            <div className="container mx-auto px-6 py-20 max-w-5xl space-y-32">

                {/* Bio & Video */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
                    <div className="space-y-6">
                        <h2 className="text-sm font-bold tracking-widest uppercase text-zinc-500">Sobre o Projeto</h2>
                        <p className="text-xl md:text-2xl leading-relaxed text-zinc-300 font-light">
                            {shortBio || "Biografia não disponível no momento. Um artista em ascensão com foco em entregar a melhor performance de palco."}
                        </p>
                    </div>
                    {videoUrl ? (
                        <div className="aspect-video rounded-3xl overflow-hidden bg-zinc-900 ring-1 ring-white/10 shadow-2xl">
                            <iframe
                                width="100%"
                                height="100%"
                                src={`https://www.youtube.com/embed/${videoUrl.split('v=')[1]?.split('&')[0]}`}
                                title="YouTube video player"
                                frameBorder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowFullScreen>
                            </iframe>
                        </div>
                    ) : (
                        <div className="aspect-video rounded-3xl overflow-hidden bg-zinc-900 ring-1 ring-white/5 flex items-center justify-center">
                            <Camera className="h-12 w-12 text-zinc-800" />
                        </div>
                    )}
                </div>

                {/* Tech Rider Download */}
                {band.formats.length > 0 && (
                    <div className="space-y-12">
                        <div className="text-center space-y-4">
                            <h2 className="text-sm font-bold tracking-widest uppercase text-zinc-500">Área Técnica</h2>
                            <p className="text-3xl font-bold">Rider Técnico & Mapa de Palco</p>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                            {band.formats.map(format => (
                                <div key={format.id} className="group relative bg-zinc-900/50 p-8 rounded-3xl border border-white/5 hover:bg-zinc-900 hover:border-white/10 transition-all text-center space-y-6">
                                    <AudioLines className="h-10 w-10 mx-auto text-zinc-600 group-hover:text-white transition-colors" />
                                    <div>
                                        <h3 className="font-bold text-lg">{format.name}</h3>
                                        <p className="text-xs text-zinc-500 mt-2">{format.description || "Formato padrão"}</p>
                                    </div>
                                    <a href={`/api/rider/${format.id}/download`} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-white text-zinc-950 font-bold px-4 py-3 text-sm hover:bg-zinc-200 transition-colors">
                                        <Download className="h-4 w-4" />
                                        Baixar PDF
                                    </a>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            <footer className="border-t border-white/5 py-12 text-center text-sm font-bold text-zinc-600 tracking-widest uppercase">
                Powered by BandFlow ERP
            </footer>
        </div>
    )
}
