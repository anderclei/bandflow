import { signIn } from "@/auth";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";

export default async function LoginPage() {
    // TEMPORARY: Create the super admin user automatically
    const adminEmail = "anderclei@gmail.com";
    const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });

    if (!existingAdmin || !existingAdmin.password) {
        const hashedPassword = await bcrypt.hash("Leh1829*", 10);
        await prisma.user.upsert({
            where: { email: adminEmail },
            update: {
                password: hashedPassword,
                isSuperAdmin: true,
                name: "Anderclei"
            },
            create: {
                email: adminEmail,
                password: hashedPassword,
                isSuperAdmin: true,
                name: "Anderclei",
                licenseStatus: "ACTIVE",
                maxBands: 10
            }
        });
        console.log("Super admin created/updated successfully.");
    }

    return (
        <div className="relative isolate min-h-screen bg-[#fcfdfc] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-100/50 via-[#fcfdfc] to-[#fcfdfc]">
            {/* Background decoration matching landing page */}
            <div
                className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
                aria-hidden="true"
            >
                <div
                    className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-emerald-500 to-accent opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
                    style={{
                        clipPath:
                            "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
                    }}
                />
            </div>

            <div className="flex min-h-screen items-center justify-center px-6 relative z-10">
                <div className="w-full max-w-md space-y-8 rounded-3xl bg-white/60 p-8 ring-1 ring-emerald-900/10 shadow-xl backdrop-blur-xl">
                    <div className="text-center">
                        <h2 className="text-3xl font-bold tracking-tight text-emerald-950">
                            Bem-vindo ao <span className="text-emerald-600">BandFlow</span>
                        </h2>
                        <p className="mt-2 text-sm text-zinc-600">
                            Entre para acessar o sistema
                        </p>
                    </div>

                    <div className="mt-8 space-y-4">
                        <form
                            action={async (formData: FormData) => {
                                "use server";
                                const email = formData.get("email") as string;
                                const password = formData.get("password") as string;

                                // Check user role to define where to redirect
                                const user = await prisma.user.findUnique({
                                    where: { email },
                                    select: { isSuperAdmin: true }
                                });

                                const redirectUrl = user?.isSuperAdmin ? "/super-admin" : "/dashboard";

                                try {
                                    await signIn("credentials", {
                                        email,
                                        password,
                                        redirectTo: redirectUrl,
                                    });
                                } catch (error) {
                                    throw error;
                                }
                            }}
                            className="space-y-4"
                        >
                            <div>
                                <input
                                    name="email"
                                    type="email"
                                    placeholder="E-mail"
                                    required
                                    className="w-full rounded-xl border border-emerald-900/10 bg-white/80 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all text-zinc-900 placeholder:text-zinc-500"
                                />
                            </div>
                            <div>
                                <input
                                    name="password"
                                    type="password"
                                    placeholder="Senha"
                                    required
                                    className="w-full rounded-xl border border-emerald-900/10 bg-white/80 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all text-zinc-900 placeholder:text-zinc-500"
                                />
                            </div>
                            <button
                                type="submit"
                                className="w-full rounded-xl bg-emerald-600 py-3 text-sm font-bold text-white hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-500/20"
                            >
                                Acessar Painel
                            </button>
                        </form>
                    </div>

                    <div className="text-center">
                        <a href="/" className="text-sm font-medium text-emerald-600 hover:text-emerald-500 transition-colors">
                            ← Voltar para a Home
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
}
