import Image from "next/image";

export default function Home() {
  return (
    <div className="relative isolate min-h-screen bg-[#fcfdfc] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-100/50 via-[#fcfdfc] to-[#fcfdfc]">
      {/* Background decoration */}
      <div
        className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
        aria-hidden="true"
      >
        <div
          className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-emerald-500 to-accent opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
          style={{
            clipPath:
              "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
          }}
        />
      </div>

      {/* Navbar */}
      <nav className="flex items-center justify-between p-6 lg:px-8" aria-label="Global">
        <div className="flex lg:flex-1">
          <a href="/" className="-m-1.5 p-1.5">
            <span className="text-xl font-bold tracking-tight text-foreground">
              Band<span className="text-primary">Flow</span>
            </span>
          </a>
        </div>
        <div className="flex gap-x-12">
          {/* Add links here if needed */}
        </div>
        <div className="flex lg:flex-1 lg:justify-end gap-x-6 items-center">
          <a href="/login" className="text-sm font-semibold leading-6 text-foreground">
            Log in
          </a>
          <a
            href="/login"
            className="rounded-full bg-emerald-600 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-emerald-500 transition-all duration-200"
          >
            Criar minha conta
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <main>
        <div className="px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <div className="mb-8 flex justify-center">
              <div className="relative rounded-full px-3 py-1 text-sm leading-6 text-foreground ring-1 ring-emerald-900/10 hover:ring-emerald-900/20 dark:ring-white/10 dark:hover:ring-white/20">
                Lançamos a versão beta do Setlist Manager.{" "}
                <a href="#" className="font-semibold text-primary">
                  <span className="absolute inset-0" aria-hidden="true" />
                  Saiba mais <span aria-hidden="true">&rarr;</span>
                </a>
              </div>
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-emerald-950 sm:text-6xl">
              Domine o Palco, Gerencie o <span className="text-emerald-600">Negócio</span>
            </h1>
            <p className="mt-6 text-lg leading-8 text-zinc-600 dark:text-zinc-400">
              A plataforma definitiva para bandas profissionais. Agende shows, gerencie setlists e controle suas finanças em um só lugar.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <a
                href="/login"
                className="rounded-full bg-emerald-500 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-emerald-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-400 transition-all duration-200"
              >
                Criar minha conta
              </a>
              <a href="/login" className="text-base font-semibold leading-6 text-foreground group">
                Ver demonstração <span aria-hidden="true" className="inline-block transition-transform group-hover:translate-x-1">&rarr;</span>
              </a>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="mx-auto mt-8 max-w-7xl px-6 lg:px-8 pb-24">
          <div className="mx-auto max-w-2xl lg:text-center">
            <h2 className="text-base font-semibold leading-7 text-primary">Tudo em um só lugar</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Tudo que sua banda precisa para profissionalizar a gestão
            </p>
          </div>
          <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
            <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
              {[
                {
                  name: "Controle Total da Banda",
                  description: "Acompanhe lucros, gastos e o valor do seu equipamento sem complicações ou planilhas difíceis.",
                  icon: "�",
                },
                {
                  name: "Encontre Tudo na Hora",
                  description: "Use a busca rápida para achar contratos, letras de música ou contatos de contratantes em um clique.",
                  icon: "🚀",
                },
                {
                  name: "Avisos e Lembretes",
                  description: "Receba alertas automáticos de shows próximos, documentos vencendo e o que precisa ser comprado.",
                  icon: "🔔",
                },
                {
                  name: "Relatórios Facilitados",
                  description: "Crie documentos profissionais em PDF para mostrar o desempenho da banda para todos os parceiros.",
                  icon: "�",
                },
                {
                  name: "Objetivos Claros",
                  description: "Defina metas de quantos shows quer fazer ou quanto quer ganhar e veja o progresso da banda crescer.",
                  icon: "�",
                },
                {
                  name: "Histórico de Mudanças",
                  description: "Saiba exatamente quem da banda adicionou ou alterou qualquer informação importante no sistema.",
                  icon: "🕰️",
                },
              ].map((feature) => (
                <div key={feature.name} className="flex flex-col bg-white/5 p-6 rounded-2xl ring-1 ring-emerald-900/10 dark:ring-white/10 hover:ring-primary/30 transition-all group">
                  <dt className="flex items-center gap-x-3 text-lg font-semibold leading-7 text-foreground">
                    <span className="text-2xl group-hover:scale-110 transition-transform">{feature.icon}</span>
                    {feature.name}
                  </dt>
                  <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-zinc-600 dark:text-zinc-400">
                    <p className="flex-auto">{feature.description}</p>
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white/5 border-t border-emerald-900/10 dark:border-white/10 py-12">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
            <div className="text-xl font-bold tracking-tight text-foreground">
              Band<span className="text-primary">Flow</span>
            </div>
            <p className="text-sm text-zinc-500">
              © 2026 BandFlow SaaS. Todos os direitos reservados.
            </p>
            <div className="flex gap-x-6">
              <a href="#" className="text-sm font-semibold text-zinc-600 hover:text-primary">Docs</a>
              <a href="#" className="text-sm font-semibold text-zinc-600 hover:text-primary">Privacidade</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
