import { getUsers } from "@/app/actions/super-admin";
import { ClientManager } from "@/components/super-admin/ClientManager";

export default async function SuperAdminClientsPage() {
    const response = await getUsers();

    if (!response.success || !response.users) {
        return <div className="p-8 text-red-500">Erro ao carregar os clientes.</div>;
    }

    return (
        <div className="max-w-6xl mx-auto">
            <ClientManager initialUsers={response.users} />
        </div>
    );
}
