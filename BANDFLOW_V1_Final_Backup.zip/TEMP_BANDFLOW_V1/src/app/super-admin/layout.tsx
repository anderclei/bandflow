import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";
import Link from "next/link";
import { Settings, Users, LayoutDashboard, LogOut } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";

export default async function SuperAdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const session = await auth();

    if (!session?.user?.id) {
        redirect("/login");
    }

    const user = await prisma.user.findUnique({
        where: { id: session.user.id }
    });

    if (!user?.isSuperAdmin) {
        redirect("/dashboard");
    }

    const navItems = [
        { name: "Overview", href: "/super-admin", icon: LayoutDashboard },
        { name: "Clientes & Instâncias", href: "/super-admin/tenants", icon: Users },
        { name: "Configurações", href: "/super-admin/settings", icon: Settings },
    ];

    return (
        <div className="flex h-screen overflow-hidden bg-zinc-50 dark:bg-zinc-950 font-sans text-zinc-900 dark:text-zinc-50">
            {/* Sidebar */}
            <aside className="w-64 border-r border-zinc-200 dark:border-white/5 bg-white dark:bg-zinc-950/50 hidden md:flex flex-col">
                <div className="flex h-16 items-center px-6 border-b border-zinc-200 dark:border-white/5">
                    <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-lg bg-red-600 shadow-lg shadow-red-600/20 flex items-center justify-center">
                            <span className="text-white font-black text-xl">B</span>
                        </div>
                        <span className="text-lg font-bold tracking-tight text-zinc-900 dark:text-white">
                            BandFlow <span className="text-red-600">Admin</span>
                        </span>
                    </div>
                </div>

                <nav className="flex-1 space-y-2 p-4">
                    {navItems.map((item) => {
                        const Icon = item.icon;
                        return (
                            <Link
                                key={item.name}
                                href={item.href}
                                className="group flex items-center rounded-xl px-3 py-2 text-sm font-medium text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-white/5 hover:text-zinc-900 dark:hover:text-white transition-all"
                            >
                                <Icon className="mr-3 h-5 w-5" />
                                <span>{item.name}</span>
                            </Link>
                        );
                    })}
                </nav>

                <div className="p-4 border-t border-zinc-200 dark:border-white/5 space-y-2">
                    <Link
                        href="/dashboard"
                        className="group flex w-full items-center rounded-xl px-3 py-2 text-sm font-medium text-zinc-500 hover:bg-zinc-100 dark:hover:bg-white/5 transition-all"
                    >
                        <LogOut className="mr-3 h-5 w-5" />
                        <span>Voltar ao Dashboard</span>
                    </Link>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
                <header className="h-16 flex items-center justify-between px-6 border-b border-zinc-200 dark:border-white/5 bg-white/50 dark:bg-zinc-950/50 backdrop-blur-sm">
                    <h1 className="text-sm font-medium text-zinc-500 dark:text-zinc-400">Painel de Controle Central</h1>
                    <div className="flex items-center gap-4">
                        <ThemeToggle />
                        <div className="h-8 w-8 rounded-full bg-zinc-200 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 overflow-hidden">
                            {user.image ? (
                                <img src={user.image} alt={user.name || "Admin"} className="h-full w-full object-cover" />
                            ) : (
                                <div className="h-full w-full flex items-center justify-center text-xs font-bold text-zinc-500">
                                    {user.name?.charAt(0) || "A"}
                                </div>
                            )}
                        </div>
                    </div>
                </header>
                <div className="flex-1 overflow-auto bg-zinc-50/50 dark:bg-black/20 p-6 md:p-8">
                    {children}
                </div>
            </main>
        </div>
    );
}
