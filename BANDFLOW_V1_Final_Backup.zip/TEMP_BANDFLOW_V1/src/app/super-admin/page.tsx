import { prisma } from "@/lib/prisma";
import { Users, CheckCircle2, AlertTriangle, ShieldCheck } from "lucide-react";

export default async function SuperAdminDashboard() {
    const totalUsers = await prisma.user.count({
        where: { isSuperAdmin: false }
    });

    const activeLicenses = await prisma.user.count({
        where: { licenseStatus: "ACTIVE", isSuperAdmin: false }
    });

    const blockedLicenses = await prisma.user.count({
        where: { licenseStatus: "BLOCKED", isSuperAdmin: false }
    });

    const superAdmins = await prisma.user.count({
        where: { isSuperAdmin: true }
    });

    return (
        <div className="max-w-6xl mx-auto space-y-6">
            <div className="flex flex-col gap-2">
                <h1 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">Dashboard Geral</h1>
                <p className="text-zinc-500 dark:text-zinc-400">Visão geral do sistema e licenças de clientes.</p>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-xl border border-zinc-200 dark:border-white/5 bg-white dark:bg-zinc-900/50 p-6 shadow-sm">
                    <div className="flex items-center gap-4">
                        <div className="rounded-lg bg-blue-500/10 p-3">
                            <Users className="h-6 w-6 text-blue-600 dark:text-blue-500" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-zinc-500">Total de Clientes</p>
                            <h2 className="text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">{totalUsers}</h2>
                        </div>
                    </div>
                </div>

                <div className="rounded-xl border border-zinc-200 dark:border-white/5 bg-white dark:bg-zinc-900/50 p-6 shadow-sm">
                    <div className="flex items-center gap-4">
                        <div className="rounded-lg bg-red-500/10 p-3">
                            <CheckCircle2 className="h-6 w-6 text-red-600 dark:text-red-500" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-zinc-500">Licenças Ativas</p>
                            <h2 className="text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">{activeLicenses}</h2>
                        </div>
                    </div>
                </div>

                <div className="rounded-xl border border-zinc-200 dark:border-white/5 bg-white dark:bg-zinc-900/50 p-6 shadow-sm">
                    <div className="flex items-center gap-4">
                        <div className="rounded-lg bg-red-500/10 p-3">
                            <AlertTriangle className="h-6 w-6 text-red-600 dark:text-red-500" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-zinc-500">Licenças Bloqueadas</p>
                            <h2 className="text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">{blockedLicenses}</h2>
                        </div>
                    </div>
                </div>

                <div className="rounded-xl border border-zinc-200 dark:border-white/5 bg-white dark:bg-zinc-900/50 p-6 shadow-sm">
                    <div className="flex items-center gap-4">
                        <div className="rounded-lg bg-purple-500/10 p-3">
                            <ShieldCheck className="h-6 w-6 text-purple-600 dark:text-purple-500" />
                        </div>
                        <div>
                            <p className="text-sm font-medium text-zinc-500">Super Admins</p>
                            <h2 className="text-3xl font-bold tracking-tight text-zinc-900 dark:text-white">{superAdmins}</h2>
                        </div>
                    </div>
                </div>
            </div>

            <div className="rounded-xl border border-zinc-200 dark:border-white/5 bg-white dark:bg-zinc-900/50 p-6 shadow-sm">
                <h3 className="text-lg font-bold mb-4 text-zinc-900 dark:text-white">Seja Bem-vindo ao Controle Central!</h3>
                <p className="text-zinc-600 dark:text-zinc-400">
                    Use o menu lateral para visualizar todos os clientes cadastrados. Na tela de "Clientes & Licenças", você pode alterar quantas bandas cada usuário tem permissão para criar, bem como bloquear ou ativar suas contas do BandFlow Saas.
                </p>
            </div>
        </div>
    );
}
