"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Lock, Eye, EyeOff, RotateCcw, Search, ShieldAlert } from "lucide-react";
import { updateSuperAdminPassword, getTenants, resetBandData } from "@/app/actions/super-admin";
import { useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export default function SuperAdminSettingsPage() {
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [saving, setSaving] = useState(false);
    const [showCurrent, setShowCurrent] = useState(false);
    const [showNew, setShowNew] = useState(false);

    const [bands, setBands] = useState<any[]>([]);
    const [searchReset, setSearchReset] = useState("");
    const [loadingBands, setLoadingBands] = useState(false);

    useEffect(() => {
        const fetchBands = async () => {
            setLoadingBands(true);
            const result = await getTenants();
            if (result.success) setBands(result.bands || []);
            setLoadingBands(false);
        };
        fetchBands();
    }, []);

    const handleResetAction = async (id: string, name: string) => {
        if (confirm(`ATENÇÃO: Deseja realmente RESETAR todos os dados da banda ${name}? \n\nIsso apagará permanentemente todos os shows, músicas, documentos e financeiro.`)) {
            setSaving(true);
            try {
                const result = await resetBandData(id);
                if (result.success) {
                    toast.success("Dados resetados com sucesso!");
                } else {
                    toast.error(result.error);
                }
            } catch {
                toast.error("Erro ao resetar dados.");
            } finally {
                setSaving(false);
            }
        }
    };

    const filteredForReset = bands.filter(b =>
        searchReset.length > 2 && (
            b.name.toLowerCase().includes(searchReset.toLowerCase()) ||
            b.slug.toLowerCase().includes(searchReset.toLowerCase())
        )
    );

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (newPassword !== confirmPassword) {
            toast.error("A nova senha e a confirmação não coincidem.");
            return;
        }
        if (newPassword.length < 6) {
            toast.error("A nova senha deve ter ao menos 6 caracteres.");
            return;
        }
        setSaving(true);
        try {
            const result = await updateSuperAdminPassword(currentPassword, newPassword);
            if (result.success) {
                toast.success("Senha atualizada com sucesso!");
                setCurrentPassword("");
                setNewPassword("");
                setConfirmPassword("");
            } else {
                toast.error(result.error);
            }
        } catch {
            toast.error("Erro inesperado ao alterar a senha.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="max-w-lg mx-auto py-8 px-4">
            <div className="mb-8">
                <h1 className="text-2xl font-bold text-zinc-900 dark:text-white">Configurações</h1>
                <p className="text-zinc-500 text-sm mt-1">Gerenciamento da conta do Super Admin.</p>
            </div>

            <div className="bg-white dark:bg-zinc-900/50 rounded-xl border border-zinc-200 dark:border-white/5 p-6 space-y-6">
                <div className="flex items-center gap-3 pb-4 border-b border-zinc-200 dark:border-white/5">
                    <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                        <Lock className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                        <h2 className="font-semibold text-zinc-900 dark:text-white">Alterar Senha</h2>
                        <p className="text-xs text-zinc-500">Atualize a senha de acesso ao painel Super Admin.</p>
                    </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-1">
                        <Label htmlFor="currentPassword">Senha Atual</Label>
                        <div className="relative">
                            <Input
                                id="currentPassword"
                                type={showCurrent ? "text" : "password"}
                                value={currentPassword}
                                onChange={(e) => setCurrentPassword(e.target.value)}
                                placeholder="••••••••"
                                required
                            />
                            <button
                                type="button"
                                onClick={() => setShowCurrent(!showCurrent)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
                            >
                                {showCurrent ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                        </div>
                    </div>

                    <div className="space-y-1">
                        <Label htmlFor="newPassword">Nova Senha</Label>
                        <div className="relative">
                            <Input
                                id="newPassword"
                                type={showNew ? "text" : "password"}
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                                placeholder="••••••••"
                                required
                                minLength={6}
                            />
                            <button
                                type="button"
                                onClick={() => setShowNew(!showNew)}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
                            >
                                {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                        </div>
                    </div>

                    <div className="space-y-1">
                        <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                        <Input
                            id="confirmPassword"
                            type="password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            placeholder="••••••••"
                            required
                            minLength={6}
                        />
                    </div>

                    <Button
                        type="submit"
                        disabled={saving || !currentPassword || !newPassword || !confirmPassword}
                        className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                        {saving ? "Salvando..." : "Atualizar Senha"}
                    </Button>
                </form>
            </div>

            <div className="bg-white dark:bg-zinc-900/50 rounded-xl border border-zinc-200 dark:border-white/5 p-6 space-y-6 mt-8">
                <div className="flex items-center gap-3 pb-4 border-b border-zinc-200 dark:border-white/5">
                    <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center">
                        <ShieldAlert className="w-5 h-5 text-red-500" />
                    </div>
                    <div>
                        <h2 className="font-semibold text-zinc-900 dark:text-white">Manutenção do Sistema</h2>
                        <p className="text-xs text-zinc-500">Reset de dados e limpeza de instâncias.</p>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="space-y-1">
                        <Label>Buscar Banda para Resetar Dados</Label>
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
                            <Input
                                placeholder="Digite o nome da banda (min. 3 caracteres)..."
                                value={searchReset}
                                onChange={(e) => setSearchReset(e.target.value)}
                                className="pl-9"
                            />
                        </div>
                    </div>

                    {searchReset.length > 2 && (
                        <div className="bg-zinc-50 dark:bg-black/20 rounded-lg border border-zinc-200 dark:border-white/5 overflow-hidden divide-y divide-zinc-200 dark:divide-white/5">
                            {loadingBands ? (
                                <div className="p-4 text-center text-sm text-zinc-500">Carregando bandas...</div>
                            ) : filteredForReset.length === 0 ? (
                                <div className="p-4 text-center text-sm text-zinc-500">Nenhuma banda encontrada.</div>
                            ) : (
                                filteredForReset.map(band => (
                                    <div key={band.id} className="p-4 flex items-center justify-between gap-4">
                                        <div>
                                            <div className="font-bold text-sm text-zinc-900 dark:text-white">{band.name}</div>
                                            <div className="text-[10px] text-zinc-500 uppercase tracking-widest italic">/{band.slug}</div>
                                        </div>
                                        <Button
                                            size="sm"
                                            variant="destructive"
                                            className="h-8 gap-2 font-bold px-4"
                                            onClick={() => handleResetAction(band.id, band.name)}
                                            disabled={saving}
                                        >
                                            <RotateCcw className="w-3 h-3" />
                                            Resetar Dados
                                        </Button>
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                    <p className="text-[10px] text-zinc-500 text-center italic">
                        Dica: Você também pode resetar dados na lista de <a href="/super-admin/tenants" className="text-red-500 hover:underline">Contas & Escritórios</a>.
                    </p>
                </div>
            </div>
        </div>
    );
}
