import { getTenants } from "@/app/actions/super-admin";
import { TenantManager } from "@/components/super-admin/TenantManager";

export default async function SuperAdminTenantsPage() {
    const response = await getTenants();

    if (!response.success || !response.bands) {
        return <div className="p-8 text-red-500">Erro ao carregar as Contas/Bandas.</div>;
    }

    return (
        <div className="max-w-6xl mx-auto space-y-6">
            <div>
                <h1 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">Contas & Escritórios</h1>
                <p className="text-zinc-500 dark:text-zinc-400">Ponto de partida. Crie um novo ambiente de Banda/Escritório e entregue a chave para o cliente administrador.</p>
            </div>

            <TenantManager initialBands={response.bands} />
        </div>
    );
}
