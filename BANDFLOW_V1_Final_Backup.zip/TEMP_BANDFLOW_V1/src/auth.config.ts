import type { NextAuthConfig } from "next-auth";
import github from "next-auth/providers/github";
import google from "next-auth/providers/google";
import credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export default {
    providers: [
        github({
            clientId: process.env.AUTH_GITHUB_ID as string,
            clientSecret: process.env.AUTH_GITHUB_SECRET as string,
        }),
        google({
            clientId: process.env.AUTH_GOOGLE_ID as string,
            clientSecret: process.env.AUTH_GOOGLE_SECRET as string,
        }),
        credentials({
            name: "Credentials",
            credentials: {
                email: { label: "Email", type: "email" },
                password: { label: "Password", type: "password" }
            },
            async authorize(credentials) {
                if (!credentials?.email || !credentials?.password) {
                    return null;
                }

                const user = await prisma.user.findUnique({
                    where: { email: credentials.email as string }
                });

                if (!user || (!user.password && user.email !== "admin@bandmanager.com")) {
                    return null;
                }

                // Temporary bypass for the demo admin without DB password
                if (user.email === "admin@bandmanager.com" && credentials.password === "admin123" && !user.password) {
                    return { id: user.id, name: user.name, email: user.email, isSuperAdmin: user.isSuperAdmin };
                }

                if (user.password) {
                    const passwordsMatch = await bcrypt.compare(
                        credentials.password as string,
                        user.password
                    );

                    if (passwordsMatch) {
                        return { id: user.id, name: user.name, email: user.email, isSuperAdmin: user.isSuperAdmin };
                    }
                }

                return null;
            }
        })
    ],
    pages: {
        signIn: "/login",
    },
    callbacks: {
        session({ session, user, token }) {
            if (session.user) {
                // If using JWT strategy, user is undefined and token is used
                // If using database strategy, user is available
                session.user.id = user?.id || token?.sub as string;
            }
            return session;
        },
    },
} satisfies NextAuthConfig;
