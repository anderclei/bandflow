import NextAuth from "next-auth";
import { PrismaAdapter } from "@auth/prisma-adapter";
import { prisma } from "@/lib/prisma";
import authConfig from "./auth.config";

export const { handlers, auth, signIn, signOut } = NextAuth({
    adapter: PrismaAdapter(prisma),
    session: { strategy: "jwt" }, // Because PrismaLibSql doesn't work well on edge, switching to JWT avoids DB calls on every request edge middleware
    ...authConfig,
    callbacks: {
        ...authConfig.callbacks,
        async jwt({ token, user, account, profile, isNewUser }) {
            if (user) {
                token.id = user.id;
                // @ts-ignore - The user from database has isSuperAdmin
                token.isSuperAdmin = user.isSuperAdmin;
            }
            return token;
        },
        async session({ session, token }) {
            if (session.user && token.id) {
                session.user.id = token.id as string;
                // @ts-ignore - Extending session type
                session.user.isSuperAdmin = token.isSuperAdmin as boolean;
            }
            return session;
        }
    }
});
