"use client";

import React, { useState } from "react";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, MapPin } from "lucide-react";

interface Gig {
    id: string;
    title: string;
    date: Date;
    location?: string | null;
}

interface CalendarProps {
    gigs?: Gig[];
    bandId?: string;
}

export default function Calendar({ gigs = [], bandId }: CalendarProps) {
    const [currentDate, setCurrentDate] = useState(new Date());

    const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
    const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const days = Array.from({ length: daysInMonth(year, month) }, (_, i) => i + 1);
    const startDay = firstDayOfMonth(year, month);

    const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
    const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

    const monthNames = [
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ];

    const isToday = (day: number) => {
        const today = new Date();
        return today.getDate() === day && today.getMonth() === month && today.getFullYear() === year;
    };

    const getGigsForDay = (day: number) => {
        return gigs.filter(gig => {
            const gigDate = new Date(gig.date);
            return gigDate.getDate() === day && gigDate.getMonth() === month && gigDate.getFullYear() === year;
        });
    };

    return (
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                    <CalendarIcon className="h-5 w-5 text-secondary" />
                    <h2 className="text-xl font-bold text-foreground">
                        {monthNames[month]} <span className="text-zinc-400 font-medium">{year}</span>
                    </h2>
                    {bandId && (
                        <a
                            href={`/api/bands/${bandId}/calendar`}
                            title="Sincronizar com Apple Calendar / Google Calendar"
                            className="ml-2 px-3 py-1 bg-zinc-100 dark:bg-zinc-800 text-xs font-semibold rounded-full hover:bg-zinc-200 dark:hover:bg-zinc-700 transition"
                        >
                            Assinar .ics
                        </a>
                    )}
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={prevMonth}
                        className="p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                    >
                        <ChevronLeft className="h-5 w-5" />
                    </button>
                    <button
                        onClick={nextMonth}
                        className="p-2 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                    >
                        <ChevronRight className="h-5 w-5" />
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-7 gap-px mb-2">
                {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map(day => (
                    <div key={day} className="text-center text-xs font-semibold text-zinc-500 py-2">
                        {day}
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-7 gap-2">
                {Array.from({ length: startDay }).map((_, i) => (
                    <div key={`empty-${i}`} className="h-24" />
                ))}
                {days.map(day => {
                    const dayGigs = getGigsForDay(day);
                    return (
                        <div
                            key={day}
                            className={`h-24 p-2 rounded-2xl border transition-all ${isToday(day)
                                ? "bg-secondary/10 border-secondary/30 dark:bg-secondary/10 dark:border-secondary/30"
                                : "bg-zinc-50/30 border-zinc-100 dark:bg-zinc-800/20 dark:border-zinc-800"
                                } hover:border-secondary/40 dark:hover:border-secondary/50 transition-colors group cursor-pointer`}
                        >
                            <span className={`text-sm font-medium ${isToday(day) ? "text-secondary" : "text-zinc-600 dark:text-zinc-400"}`}>
                                {day}
                            </span>
                            <div className="mt-1 space-y-1 overflow-y-auto max-h-[60px] scrollbar-hide">
                                {dayGigs.map(gig => (
                                    <div
                                        key={gig.id}
                                        className="text-[10px] p-1 rounded bg-white dark:bg-zinc-800 shadow-sm border border-zinc-100 dark:border-zinc-700 truncate"
                                        title={gig.title}
                                    >
                                        <div className="font-semibold text-secondary truncate">
                                            {gig.title}
                                        </div>
                                        {gig.location && (
                                            <div className="flex items-center gap-0.5 text-zinc-400">
                                                <MapPin className="h-2 w-2" />
                                                <span className="truncate">{gig.location}</span>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
