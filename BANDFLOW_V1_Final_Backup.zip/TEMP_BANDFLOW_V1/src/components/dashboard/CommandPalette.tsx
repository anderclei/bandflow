"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { Search, ArrowRight, Music, MapPin, Users, FileText, X } from "lucide-react";
import { useRouter } from "next/navigation";

interface SearchResult {
    id: string;
    title: string;
    type: string;
    href: string;
}

const typeLabels: Record<string, { label: string; icon: any }> = {
    gig: { label: "Show", icon: MapPin },
    song: { label: "Música", icon: Music },
    contractor: { label: "Contratante", icon: Users },
    document: { label: "Documento", icon: FileText },
};

export function CommandPalette({ bandId }: { bandId: string }) {
    const [open, setOpen] = useState(false);
    const [query, setQuery] = useState("");
    const [results, setResults] = useState<SearchResult[]>([]);
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [loading, setLoading] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);
    const router = useRouter();

    // Ctrl+K to open
    useEffect(() => {
        function handleKeyDown(e: KeyboardEvent) {
            if ((e.ctrlKey || e.metaKey) && e.key === "k") {
                e.preventDefault();
                setOpen((prev) => !prev);
            }
            if (e.key === "Escape") setOpen(false);
        }
        window.addEventListener("keydown", handleKeyDown);
        return () => window.removeEventListener("keydown", handleKeyDown);
    }, []);

    useEffect(() => {
        if (open) {
            setTimeout(() => inputRef.current?.focus(), 100);
        } else {
            setQuery("");
            setResults([]);
            setSelectedIndex(0);
        }
    }, [open]);

    // Debounced search
    useEffect(() => {
        if (!query || query.length < 2) {
            setResults([]);
            return;
        }
        setLoading(true);
        const timer = setTimeout(async () => {
            try {
                const res = await fetch(`/api/search?q=${encodeURIComponent(query)}&bandId=${bandId}`);
                const data = await res.json();
                setResults(data.results || []);
            } catch {
                setResults([]);
            } finally {
                setLoading(false);
            }
        }, 250);
        return () => clearTimeout(timer);
    }, [query, bandId]);

    const handleSelect = useCallback(
        (result: SearchResult) => {
            setOpen(false);
            router.push(result.href);
        },
        [router]
    );

    const handleKeyNavigation = (e: React.KeyboardEvent) => {
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setSelectedIndex((prev) => Math.min(prev + 1, results.length - 1));
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setSelectedIndex((prev) => Math.max(prev - 1, 0));
        } else if (e.key === "Enter" && results[selectedIndex]) {
            handleSelect(results[selectedIndex]);
        }
    };

    if (!open) return null;

    return (
        <div className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm flex items-start justify-center pt-[20vh] animate-in fade-in duration-150">
            <div className="w-full max-w-lg rounded-2xl bg-white shadow-2xl ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-700 overflow-hidden">
                <div className="flex items-center gap-3 px-4 py-3 border-b border-zinc-100 dark:border-zinc-800">
                    <Search className="h-5 w-5 text-zinc-400" />
                    <input
                        ref={inputRef}
                        value={query}
                        onChange={(e) => { setQuery(e.target.value); setSelectedIndex(0); }}
                        onKeyDown={handleKeyNavigation}
                        placeholder="Buscar shows, músicas, contratantes..."
                        className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-zinc-400"
                    />
                    <kbd className="hidden sm:inline-block px-2 py-0.5 rounded-md bg-zinc-100 dark:bg-zinc-800 text-[10px] font-bold text-zinc-500">ESC</kbd>
                </div>

                <div className="max-h-[300px] overflow-y-auto">
                    {loading && (
                        <div className="p-6 text-center text-sm text-zinc-400">Buscando...</div>
                    )}
                    {!loading && results.length === 0 && query.length >= 2 && (
                        <div className="p-6 text-center text-sm text-zinc-400">Nenhum resultado encontrado.</div>
                    )}
                    {!loading && results.length === 0 && query.length < 2 && (
                        <div className="p-6 text-center text-sm text-zinc-400">
                            Digite pelo menos 2 caracteres para buscar...
                        </div>
                    )}
                    {results.map((result, i) => {
                        const meta = typeLabels[result.type] || { label: result.type, icon: Search };
                        const Icon = meta.icon;
                        return (
                            <button
                                key={result.id}
                                onClick={() => handleSelect(result)}
                                className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors ${i === selectedIndex ? "bg-secondary/10 text-secondary" : "hover:bg-zinc-50 dark:hover:bg-zinc-800/50"
                                    }`}
                            >
                                <div className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-500">
                                    <Icon className="h-4 w-4" />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-foreground truncate">{result.title}</p>
                                    <p className="text-[10px] text-zinc-400 uppercase font-bold">{meta.label}</p>
                                </div>
                                <ArrowRight className="h-3 w-3 text-zinc-300" />
                            </button>
                        );
                    })}
                </div>

                <div className="px-4 py-2 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                    <p className="text-[10px] text-zinc-400">
                        <kbd className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 font-bold mr-1">↑↓</kbd>
                        navegar
                        <kbd className="px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 font-bold mx-1">↵</kbd>
                        abrir
                    </p>
                </div>
            </div>
        </div>
    );
}
