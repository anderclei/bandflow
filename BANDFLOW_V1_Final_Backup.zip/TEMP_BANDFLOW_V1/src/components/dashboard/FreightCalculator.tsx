"use client";

import { useState } from "react";
import { Truck, Calculator, MapPin, AlertCircle, Loader2, CheckCircle2 } from "lucide-react";

interface Supplier {
    id: string;
    name: string;
    kmValue: number;
    contact: string | null;
}

interface FreightResult {
    originDisplay: string;
    destinationDisplay: string;
    straightKm: number;
    roadKm: number;
    estimatedCost: number | null;
}

interface FreightCalculatorProps {
    suppliers: Supplier[];
    bandCity?: string; // cidade base da banda (préfill)
}

export function FreightCalculator({ suppliers, bandCity = "" }: FreightCalculatorProps) {
    const [origin, setOrigin] = useState(bandCity);
    const [destination, setDestination] = useState("");
    const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(
        suppliers.length > 0 ? suppliers[0] : null
    );
    const [result, setResult] = useState<FreightResult | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const calculate = async () => {
        if (!origin.trim() || !destination.trim()) {
            setError("Informe a cidade de origem e destino.");
            return;
        }
        setLoading(true);
        setError(null);
        setResult(null);

        try {
            const params = new URLSearchParams({
                origin: origin.trim(),
                destination: destination.trim(),
                kmValue: selectedSupplier ? String(selectedSupplier.kmValue) : "0",
            });
            const res = await fetch(`/api/freight?${params}`);
            const data = await res.json();

            if (!res.ok) {
                setError(data.error || "Erro ao calcular distância.");
            } else {
                setResult(data);
            }
        } catch {
            setError("Erro de conexão. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    const fmt = (v: number) =>
        v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

    return (
        <div className="rounded-3xl bg-white dark:bg-zinc-900 ring-1 ring-zinc-200 dark:ring-zinc-800 p-6 space-y-5">
            {/* Header */}
            <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                    <Truck className="h-5 w-5" />
                </div>
                <div>
                    <h2 className="text-lg font-bold text-foreground">Calculadora de Frete</h2>
                    <p className="text-xs text-zinc-500">Estimativa por distância entre cidades</p>
                </div>
            </div>

            {/* Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> Cidade de Origem
                    </label>
                    <input
                        value={origin}
                        onChange={(e) => setOrigin(e.target.value)}
                        placeholder="Ex: São Paulo"
                        className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-secondary/30"
                    />
                </div>

                <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-1">
                        <MapPin className="h-3 w-3 text-secondary" /> Cidade do Show
                    </label>
                    <input
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                        placeholder="Ex: Campinas"
                        className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-secondary/30"
                    />
                </div>
            </div>

            {/* Supplier select */}
            {suppliers.length > 0 ? (
                <div className="space-y-1">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Fornecedor de Transporte</label>
                    <select
                        value={selectedSupplier?.id ?? ""}
                        onChange={(e) => {
                            const s = suppliers.find((s) => s.id === e.target.value) || null;
                            setSelectedSupplier(s);
                        }}
                        className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-secondary/30"
                    >
                        {suppliers.map((s) => (
                            <option key={s.id} value={s.id}>
                                {s.name} — {fmt(s.kmValue)}/km
                            </option>
                        ))}
                    </select>
                </div>
            ) : (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 text-xs font-medium border border-amber-200 dark:border-amber-800">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" />
                    Cadastre fornecedores em{" "}
                    <a href="/dashboard/logistics/suppliers" className="underline font-bold">
                        Logística → Fornecedores
                    </a>{" "}
                    para calcular o custo estimado.
                </div>
            )}

            {/* Calcular button */}
            <button
                onClick={calculate}
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-secondary text-white font-bold py-2.5 text-sm hover:bg-secondary/90 disabled:opacity-50 transition-all"
            >
                {loading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                    <Calculator className="h-4 w-4" />
                )}
                {loading ? "Calculando..." : "Calcular Distância e Frete"}
            </button>

            {/* Error */}
            {error && (
                <div className="flex items-center gap-2 p-3 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-xs font-medium border border-red-200 dark:border-red-800">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" />
                    {error}
                </div>
            )}

            {/* Result */}
            {result && (
                <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 space-y-4 border border-zinc-100 dark:border-zinc-700">
                    <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-sm">
                        <CheckCircle2 className="h-4 w-4" />
                        Estimativa calculada
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <div className="p-3 rounded-xl bg-white dark:bg-zinc-900 text-center">
                            <p className="text-[10px] font-bold text-zinc-500 uppercase mb-1">Distância (Estrada)</p>
                            <p className="text-2xl font-black text-foreground">{result.roadKm.toLocaleString("pt-BR")}</p>
                            <p className="text-[10px] text-zinc-500">km estimados</p>
                        </div>

                        <div className="p-3 rounded-xl bg-secondary/10 text-center">
                            <p className="text-[10px] font-bold text-secondary uppercase mb-1">Custo Estimado</p>
                            <p className="text-2xl font-black text-secondary">
                                {result.estimatedCost !== null
                                    ? fmt(result.estimatedCost)
                                    : "—"}
                            </p>
                            <p className="text-[10px] text-zinc-500">
                                {selectedSupplier ? `via ${selectedSupplier.name}` : "sem fornecedor"}
                            </p>
                        </div>
                    </div>

                    <div className="space-y-1 text-[10px] text-zinc-400">
                        <p>📍 <span className="font-medium text-zinc-600 dark:text-zinc-300">{result.originDisplay.split(",").slice(0, 2).join(",")}</span></p>
                        <p>🎯 <span className="font-medium text-zinc-600 dark:text-zinc-300">{result.destinationDisplay.split(",").slice(0, 2).join(",")}</span></p>
                        <p className="pt-1 italic">* Estimativa via linha reta × 1.35 (fator estrada médio). Use como referência inicial.</p>
                    </div>
                </div>
            )}
        </div>
    );
}
