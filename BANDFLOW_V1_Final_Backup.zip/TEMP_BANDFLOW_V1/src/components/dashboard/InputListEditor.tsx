"use client"

import React, { useState } from 'react';
import { Plus, Trash2, Save, CheckCircle2, ListMusic } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { updateShowFormatTechnical } from "@/app/actions/show-formats";
import { toast } from "sonner";

export type InputChannel = {
    id: string;
    channel: string;
    instrument: string;
    mic: string;
    insert: string;
}

interface InputListEditorProps {
    formatId: string;
    initialData?: string | null;
}

export function InputListEditor({ formatId, initialData }: InputListEditorProps) {
    const [isSaving, setIsSaving] = useState(false);
    const [channels, setChannels] = useState<InputChannel[]>(() => {
        if (initialData) {
            try {
                return JSON.parse(initialData);
            } catch (e) {
                console.error("Failed to parse input list data", e);
            }
        }
        return [
            { id: crypto.randomUUID(), channel: "01", instrument: "Bumbo", mic: "Shure Beta 52", insert: "Gate" },
            { id: crypto.randomUUID(), channel: "02", instrument: "Caixa", mic: "Shure SM57", insert: "Comp" },
            { id: crypto.randomUUID(), channel: "03", instrument: "Hi-Hat", mic: "Shure SM81", insert: "" },
        ];
    });

    const addChannel = () => {
        const nextNum = channels.length + 1;
        const channelStr = nextNum.toString().padStart(2, '0');
        setChannels([
            ...channels,
            { id: crypto.randomUUID(), channel: channelStr, instrument: "", mic: "", insert: "" }
        ]);
    };

    const updateChannel = (id: string, field: keyof InputChannel, value: string) => {
        setChannels(channels.map(ch =>
            ch.id === id ? { ...ch, [field]: value } : ch
        ));
    };

    const removeChannel = (id: string) => {
        setChannels(channels.filter(ch => ch.id !== id));
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            const result = await updateShowFormatTechnical(formatId, {
                inputList: JSON.stringify(channels)
            });
            if (result.success) {
                toast.success("Lista de inputs salva com sucesso!");
            } else {
                toast.error("Erro ao salvar lista de inputs");
            }
        } catch (error) {
            toast.error("Ocorreu um erro ao salvar");
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <Card className="border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-50 dark:bg-zinc-800 backdrop-blur-sm">
            <div className="flex flex-row items-center justify-between p-6 pb-7">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <ListMusic className="h-8 w-8 text-secondary" />
                        Input List
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Gerencie a lista de canais, microfonação e inserts técnicos.
                    </p>
                </div>
                <div className="flex gap-2">
                    <Button onClick={addChannel} variant="outline" size="sm" className="border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800 hover:bg-zinc-800 text-zinc-700 dark:text-zinc-300 gap-2">
                        <Plus className="h-4 w-4" />
                        Adicionar Canal
                    </Button>
                    <Button
                        onClick={handleSave}
                        disabled={isSaving}
                        className="bg-secondary hover:bg-secondary/90 text-white gap-2 transition-all active:scale-95"
                    >
                        {isSaving ? (
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        ) : (
                            <Save className="h-4 w-4" />
                        )}
                        Salvar Lista
                    </Button>
                </div>
            </div>
            <CardContent>
                <div className="rounded-md border border-zinc-200 dark:border-zinc-800">
                    <Table>
                        <TableHeader>
                            <TableRow className="border-zinc-200 dark:border-zinc-800 hover:bg-transparent">
                                <TableHead className="w-[80px] text-zinc-400 text-center font-bold">CH</TableHead>
                                <TableHead className="text-zinc-400 font-bold">Instrumento</TableHead>
                                <TableHead className="text-zinc-400 font-bold">Microfone / DI</TableHead>
                                <TableHead className="text-zinc-400 font-bold">Insert / FX</TableHead>
                                <TableHead className="w-[50px]"></TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {channels.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={5} className="h-24 text-center text-zinc-600 italic">
                                        Nenhum canal adicionado. Use o botão "Adicionar Canal" acima.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                channels.map((channel) => (
                                    <TableRow key={channel.id} className="border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:bg-zinc-800/30 transition-colors">
                                        <TableCell className="p-2">
                                            <Input
                                                value={channel.channel}
                                                onChange={(e) => updateChannel(channel.id, "channel", e.target.value)}
                                                className="h-9 w-16 bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-center font-mono text-secondary font-bold"
                                            />
                                        </TableCell>
                                        <TableCell className="p-2">
                                            <Input
                                                value={channel.instrument}
                                                onChange={(e) => updateChannel(channel.id, "instrument", e.target.value)}
                                                className="h-9 bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-200"
                                                placeholder="Ex: Voz Principal"
                                            />
                                        </TableCell>
                                        <TableCell className="p-2">
                                            <Input
                                                value={channel.mic}
                                                onChange={(e) => updateChannel(channel.id, "mic", e.target.value)}
                                                className="h-9 bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-400"
                                                placeholder="Ex: SM58"
                                            />
                                        </TableCell>
                                        <TableCell className="p-2">
                                            <Input
                                                value={channel.insert}
                                                onChange={(e) => updateChannel(channel.id, "insert", e.target.value)}
                                                className="h-9 bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-400"
                                                placeholder="Ex: Comp, Reverb"
                                            />
                                        </TableCell>
                                        <TableCell className="p-2 text-center">
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-8 w-8 text-zinc-600 hover:text-red-500 hover:bg-red-500/10 transition-colors"
                                                onClick={() => removeChannel(channel.id)}
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </div>

                <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="bg-zinc-50 dark:bg-zinc-800/30 border-zinc-200 dark:border-zinc-800 border-dashed">
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-2 mb-2 text-foreground font-bold text-sm">
                                <CheckCircle2 className="h-4 w-4 text-secondary" />
                                <span>Padrão Profissional</span>
                            </div>
                            <p className="text-xs text-zinc-500 leading-relaxed">
                                Organize seus canais seguindo o fluxo padrão (Ritmo, Harmonia, Metais, Vozes).
                            </p>
                        </CardContent>
                    </Card>
                    <Card className="bg-zinc-50 dark:bg-zinc-800/30 border-zinc-200 dark:border-zinc-800 border-dashed">
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-2 mb-2 text-foreground font-bold text-sm">
                                <CheckCircle2 className="h-4 w-4 text-secondary" />
                                <span>Clareza Técnica</span>
                            </div>
                            <p className="text-xs text-zinc-500 leading-relaxed">
                                Especifique modelos exatos de microfones para garantir a qualidade sonora.
                            </p>
                        </CardContent>
                    </Card>
                    <Card className="bg-zinc-50 dark:bg-zinc-800/30 border-zinc-200 dark:border-zinc-800 border-dashed">
                        <CardContent className="pt-6">
                            <div className="flex items-center gap-2 mb-2 text-foreground font-bold text-sm">
                                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                                <span>Sincronização PDF</span>
                            </div>
                            <p className="text-xs text-zinc-500 leading-relaxed">
                                Esta lista será incluída automaticamente no Rider Técnico gerado em PDF.
                            </p>
                        </CardContent>
                    </Card>
                </div>
            </CardContent>
        </Card>
    );
}
