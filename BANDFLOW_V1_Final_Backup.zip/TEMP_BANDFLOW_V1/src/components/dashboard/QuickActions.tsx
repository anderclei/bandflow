"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";
import {
    CalendarPlus,
    Map,
    FileText,
    PlusCircle,
    ArrowRight
} from "lucide-react";

interface QuickActionsProps {
    bandId: string;
}

export function QuickActions({ bandId }: QuickActionsProps) {
    const actions = [
        {
            title: "Marcar Show",
            description: "Adicionar nova data na agenda",
            href: "/dashboard/gigs",
            icon: CalendarPlus,
        },
        {
            title: "Ver Mapa de Palco",
            description: "Disposição visual para o som",
            href: "/dashboard/setlists/stage-plots",
            icon: Map,
        },
        {
            title: "Gerar Rider PDF",
            description: "Input list e rider técnico",
            href: "/dashboard/rider",
            icon: FileText,
        },
        {
            title: "Lançar Despesa",
            description: "Fluxo de caixa e divisões",
            href: "/dashboard/finance",
            icon: PlusCircle,
        },
    ];

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {actions.map((action) => (
                <Link
                    key={action.title}
                    href={action.href}
                    className="group relative overflow-hidden rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-100 transition-all hover:shadow-md hover:ring-primary/30 dark:bg-zinc-900 dark:ring-zinc-800"
                >
                    <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary/10 text-secondary">
                            <action.icon className="h-6 w-6" />
                        </div>
                        <div className="flex-1 min-w-0">
                            <h3 className="text-sm font-bold text-foreground truncate">{action.title}</h3>
                            <p className="text-[10px] text-zinc-500 dark:text-zinc-400 truncate">{action.description}</p>
                        </div>
                        <ArrowRight className="h-4 w-4 text-zinc-300 transition-transform group-hover:translate-x-1 dark:text-zinc-600" />
                    </div>
                </Link>
            ))}
        </div>
    );
}
