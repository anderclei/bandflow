"use client";

import { useRoleStore, UserRole } from "@/store/useRoleStore";
import { Shield, User, Hammer, ShoppingBag } from "lucide-react";
import { cn } from "@/lib/utils";

export function RoleToggle({ primaryColor }: { primaryColor?: string }) {
    const { currentRole, setRole } = useRoleStore();
    const brandColor = primaryColor || "var(--brand-primary)";

    const roles: { id: UserRole; label: string; icon: any; color: string }[] = [
        { id: 'ADMIN', label: 'Dono (Admin)', icon: Shield, color: brandColor },
        { id: 'PRODUCER', label: 'Produtor', icon: Hammer, color: '#a855f7' },
        { id: 'MUSICIAN', label: 'Músico', icon: User, color: '#3b82f6' },
        { id: 'MERCH_SELLER', label: 'Vendedor', icon: ShoppingBag, color: '#f59e0b' },
    ];

    return (
        <div
            className="flex items-center gap-1 p-1 rounded-xl bg-secondary/10 border border-secondary/20 backdrop-blur-sm"
        >
            {roles.map((role) => {
                const Icon = role.icon;
                const isActive = currentRole === role.id;

                return (
                    <button
                        key={role.id}
                        onClick={() => setRole(role.id)}
                        title={role.label}
                        className={cn(
                            "p-1.5 rounded-lg transition-all flex items-center gap-2",
                            isActive
                                ? "bg-white dark:bg-zinc-800 shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-700"
                                : "hover:bg-black/5 dark:hover:bg-white/5 grayscale opacity-50"
                        )}
                        style={isActive ? { color: role.color } : {}}
                    >
                        <Icon className="h-4 w-4" style={{ color: isActive ? role.color : undefined }} />
                        {isActive && <span className="text-[10px] font-bold pr-1 hidden lg:inline">{role.label}</span>}
                    </button>
                );
            })}
        </div>
    );
}
