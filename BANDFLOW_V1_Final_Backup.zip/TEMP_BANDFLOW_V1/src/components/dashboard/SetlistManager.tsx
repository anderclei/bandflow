"use client";

import React, { useState } from "react";
import {
    DndContext,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors,
    DragEndEvent,
} from "@dnd-kit/core";
import {
    arrayMove,
    SortableContext,
    sortableKeyboardCoordinates,
    verticalListSortingStrategy,
    useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Trash2, Plus, Music } from "lucide-react";
import { updateSetlistItems } from "@/app/actions/setlists";

interface Song {
    id: string;
    title: string;
    artist?: string | null;
    duration?: number | null;
}

interface SetlistItem {
    id: string;
    songId: string;
    song: Song;
}

interface Setlist {
    id: string;
    title: string;
    items: SetlistItem[];
}

interface Props {
    setlist: Setlist;
    availableSongs: Song[];
}

function SortableItem({ item, onRemove }: { item: SetlistItem, onRemove: (id: string) => void }) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
    } = useSortable({ id: item.id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            className="flex items-center gap-4 p-4 mb-2 bg-white dark:bg-zinc-800 rounded-2xl border border-zinc-100 dark:border-zinc-700 shadow-sm group"
        >
            <button {...attributes} {...listeners} className="cursor-grab text-zinc-400 hover:text-zinc-600">
                <GripVertical className="h-5 w-5" />
            </button>
            <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-foreground truncate">{item.song.title}</h4>
                <p className="text-xs text-zinc-500 truncate">{item.song.artist || "Artista desconhecido"}</p>
            </div>
            <button
                onClick={() => onRemove(item.id)}
                className="p-2 text-zinc-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
            >
                <Trash2 className="h-4 w-4" />
            </button>
        </div>
    );
}

export default function SetlistManager({ setlist, availableSongs }: Props) {
    const [items, setItems] = useState(setlist.items);
    const [isSaving, setIsSaving] = useState(false);

    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;

        if (over && active.id !== over.id) {
            setItems((items) => {
                const oldIndex = items.findIndex((i) => i.id === active.id);
                const newIndex = items.findIndex((i) => i.id === over.id);
                return arrayMove(items, oldIndex, newIndex);
            });
        }
    };

    const addSong = (song: Song) => {
        const newItem: SetlistItem = {
            id: `temp-${Date.now()}`,
            songId: song.id,
            song: song,
        };
        setItems([...items, newItem]);
    };

    const removeSong = (id: string) => {
        setItems(items.filter((item) => item.id !== id));
    };

    const saveChanges = async () => {
        setIsSaving(true);
        try {
            const itemsToSave = items.map((item, index) => ({
                songId: item.songId,
                position: index,
            }));
            await updateSetlistItems(setlist.id, itemsToSave);
            alert("Setlist salvo com sucesso!");
        } catch (error) {
            console.error(error);
            alert("Erro ao salvar setlist");
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
            <div>
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold text-foreground">Ordem do Show</h2>
                    <button
                        onClick={saveChanges}
                        disabled={isSaving}
                        className="rounded-full bg-secondary px-6 py-2 text-sm font-semibold text-white shadow-sm hover:bg-secondary/90 disabled:opacity-50"
                    >
                        {isSaving ? "Salvando..." : "Salvar Ordem"}
                    </button>
                </div>

                <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                >
                    <SortableContext
                        items={items.map(i => i.id)}
                        strategy={verticalListSortingStrategy}
                    >
                        {items.length > 0 ? (
                            <div className="min-h-[200px]">
                                {items.map((item) => (
                                    <SortableItem key={item.id} item={item} onRemove={removeSong} />
                                ))}
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center p-12 rounded-3xl border-2 border-dashed border-zinc-200 dark:border-zinc-800 text-zinc-500">
                                <Music className="h-8 w-8 mb-4 opacity-50" />
                                <p>Arraste ou adicione músicas do repositório</p>
                            </div>
                        )}
                    </SortableContext>
                </DndContext>
            </div>

            <div>
                <h2 className="text-xl font-bold text-foreground mb-6">Repositório de Músicas</h2>
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 max-h-[600px] overflow-y-auto">
                    <div className="space-y-2">
                        {availableSongs.map((song) => (
                            <div
                                key={song.id}
                                className="flex items-center justify-between p-3 rounded-xl hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors group"
                            >
                                <div className="min-w-0">
                                    <h4 className="font-medium text-foreground truncate">{song.title}</h4>
                                    <p className="text-xs text-zinc-500 truncate">{song.artist || "---"}</p>
                                </div>
                                <button
                                    onClick={() => addSong(song)}
                                    className="p-2 rounded-lg bg-secondary/10 text-secondary hover:bg-secondary/20 transition-colors"
                                >
                                    <Plus className="h-4 w-4" />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}
