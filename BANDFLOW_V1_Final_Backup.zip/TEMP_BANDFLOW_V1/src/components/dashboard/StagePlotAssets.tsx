"use client"

import React from 'react';

// ----------------------------------------------------------------------
// Types
// ----------------------------------------------------------------------

export type StageItemType =
    | 'drum' | 'keyboard' | 'piano' | 'bass' | 'guitar' | 'guitar-acoustic' | 'sax' | 'trumpet' | 'congas'
    | 'bass-amp' | 'guitar-amp' | 'side' | 'monitor' | 'drum-sub' | 'mic' | 'mic-handheld'
    | 'di' | 'power' | 'riser' | 'stand' | 'backdrop' | 'percussion';

export interface StageItem {
    id: string;
    type: StageItemType;
    x: number;
    y: number;
    label: string;
    rotation: number;
    scale: number;
}

// ----------------------------------------------------------------------
// Icons (Premium SVGRepo Line-Art)
// ----------------------------------------------------------------------

export const MicStandIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 512 512" className={className} fill="currentColor">
        <path d="M411.514,126.923c-12.351,0-23.712,4.292-32.694,11.448V74.224C378.82,33.295,345.525,0,304.598,0h-97.196
			c-40.926,0-74.222,33.295-74.222,74.222v64.148c-8.982-7.157-20.344-11.448-32.694-11.448c-28.988,0-52.57,23.583-52.57,52.572
			c0,23.782,15.879,43.915,37.589,50.383v5.715c0,70.424,55.103,128.212,124.461,132.546v129.841
			c0,7.743,6.279,14.021,14.021,14.021h64.03c7.743,0,14.021-6.279,14.021-14.021V368.138
			c69.357-4.334,124.461-62.122,124.461-132.546v-5.715c21.708-6.467,37.586-26.6,37.586-50.382
			C464.085,150.506,440.502,126.923,411.514,126.923z"/>
    </svg>
);

export const MicIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 16 16" className={className} fill="currentColor">
        <path d="M5 3C5 1.34315 6.34315 0 8 0C9.65685 0 11 1.34315 11 3V7C11 8.65685 9.65685 10 8 10C6.34315 10 5 8.65685 5 7V3Z" />
        <path d="M9 13.9291V16H7V13.9291C3.60771 13.4439 1 10.5265 1 7V6H3V7C3 9.76142 5.23858 12 8 12C10.7614 12 13 9.76142 13 7V6H15V7C15 10.5265 12.3923 13.4439 9 13.9291Z" />
    </svg>
);

export const MonitorWedgeIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 100 60" className={className} stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" fill="none">
        <path d="M10,55 L90,55 L82,15 L18,15 Z" className="fill-zinc-900 text-zinc-700" />
        <rect x="15" y="30" width="4" height="10" rx="0.5" className="fill-zinc-800" />
    </svg>
);

export const AmpStackIcon = ({ className }: { className?: string }) => (
    <svg viewBox="-3 0 64 64" className={className} fill="currentColor">
        <path d="M55.9995,57.0005 C55.9995,58.1025 55.1025,59.0005 53.9995,59.0005 L9.9995,59.0005 C8.8975,59.0005 7.9995,58.1025 7.9995,57.0005 L7.9995,27.0005 C7.9995,25.8975 8.8975,25.0005 9.9995,25.0005 L53.9995,25.0005 C55.1025,25.0005 55.9995,25.8975 55.9995,27.0005 L55.9995,57.0005 Z" />
        <path d="M60.9995,6.0005 C60.9995,2.7005 58.2995,0.0005 54.9995,0.0005 L8.9995,0.0005 C5.6995,0.0005 2.9995,2.7005 2.9995,6.0005 L2.9995,58.0005 C2.9995,61.3005 5.6995,64.0005 8.9995,64.0005 L54.9995,64.0005 C58.2995,64.0005 60.9995,61.3005 60.9995,58.0005 L60.9995,24.0005 Z" />
    </svg>
);

export const SpeakerIcon = ({ className }: { className?: string }) => (
    <svg viewBox="-11 0 64 64" className={className} fill="currentColor">
        <path d="M32,54 C24.832,54 19,48.168 19,41 C19,33.832 24.832,28 32,28 C39.168,28 45,33.832 45,41 C45,48.168 39.168,54 32,54 L32,54 Z M32,26 C23.716,26 17,32.716 17,41 C17,49.284 23.716,56 32,56 C40.284,56 47,49.284 47,41 C47,32.716 40.284,26 32,26 Z" />
        <path d="M53,59 L53,5 C53,2.25 50.75,0 48,0 L16,0 C13.25,0 11,2.25 11,5 L11,59 C11,61.75 13.25,64 16,64 L48,64 C50.75,64 53,61.75 53,59 Z" />
    </svg>
);

export const GuitarIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 512 512" className={className} fill="currentColor">
        <path d="M396.727,262.864c-25.77,0-46.737,20.966-46.737,46.737v85.061l-23.796-66.129l19.138-66.2
			c3.05-10.55,0.452-21.689-6.954-29.8c-7.404-8.109-18.265-11.707-29.048-9.628l-34.486,6.659V122.518l15.463-87.441
			c1.542-8.72-0.838-17.613-6.53-24.4S269.745,0,260.891,0h-41.479c-8.856,0-17.199,3.891-22.889,10.678
			c-5.69,6.787-8.071,15.678-6.53,24.4l15.463,87.441v88.79l-42.258-24.924c-12.624-7.447-28.067-6.206-39.342,3.161
			c-11.274,9.368-15.323,24.321-10.316,38.097l36.77,101.154L73.268,460.353c-7.1,12.122-6.146,27.143,2.429,38.27
			C82.316,507.211,92.336,512,102.787,512c3.087,0,6.211-0.418,9.298-1.279l130.647-36.476l87.751,33.656
			c12.681,4.863,26.581,1.98,36.282-7.521c6.957-6.814,10.534-15.862,10.315-25.147c0.072-0.567,0.122-1.143,0.122-1.729V309.599
			c0-10.766,8.76-19.525,19.525-19.525s19.525,8.758,19.525,19.525v64.615c0,7.515,6.093,13.606,13.606,13.606
			c7.513,0,13.606-6.091,13.606-13.606v-64.615C443.462,283.829,422.496,262.864,396.727,262.864z M217.37,28.165
			c0.365-0.434,1.012-0.952,2.04-0.952h41.479c1.027,0,1.675,0.517,2.04,0.952c0.366,0.434,0.762,1.163,0.582,2.174l-13.684,77.376
			H230.47l-13.684-77.376C216.61,29.328,217.006,28.599,217.37,28.165z M247.633,134.927v111.118v78.687h-14.967V235.13V134.927
			H247.633z M347.723,480.939c-0.976,0.956-3.661,3.027-7.496,1.554l-91.95-35.267c-2.728-1.045-5.719-1.185-8.532-0.401
			L104.766,484.51c-4.163,1.158-6.64-1.362-7.515-2.499c-0.878-1.137-2.682-4.185-0.502-7.906l29.159-49.793h110.819
			c7.513,0,13.606-6.091,13.606-13.606c0-7.515-6.093-13.606-13.606-13.606h-94.883l35.177-60.068
			c2.046-3.494,2.43-7.717,1.048-11.524l-38.956-107.161c-1.537-4.229,0.978-6.913,2.131-7.871c0.762-0.633,2.373-1.713,4.498-1.713
			c1.091,0,2.316,0.284,3.63,1.06l56.081,33.078v83.476h-1.361c-7.513,0-13.606,6.091-13.606,13.606
			c0,7.515,6.093,13.606,13.606,13.606h72.112c7.513,0,13.606-6.091,13.606-13.606c0-7.515-6.093-13.606-13.606-13.606h-1.361
			v-69.101l39.644-7.653c1.961-0.376,3.218,0.625,3.795,1.257s1.461,1.978,0.908,3.893l-20.364,70.439
			c-0.796,2.754-0.703,5.689,0.268,8.385l50.336,139.883C350.821,477.34,348.7,479.982,347.723,480.939z"/>
    </svg>
);

export const AcousticGuitarIcon = ({ className }: { className?: string }) => (
    <svg viewBox="-0.5 0 25 25" className={className} fill="currentColor">
        <path fillRule="evenodd" clipRule="evenodd" d="M20.7478 0.39531C21.1383 0.00478592 21.7715 0.00478592 22.162 0.39531L22.912 1.14523L23.6619 1.89514C24.0524 2.28567 24.0524 2.91883 23.6619 3.30935L21.3094 5.66182C20.9189 6.05234 20.2857 6.05234 19.8952 5.66182L19.8524 5.61901L18.4965 6.97485C19.2635 7.9448 19.8261 9.08552 20.125 10.336C20.7228 12.8373 19.2845 15.3979 16.8473 16.2355C15.6297 16.654 14.6773 17.5864 14.4747 18.8992L14.3925 19.4322C13.9642 22.2078 11.4479 24.2147 8.65153 23.9929C4.04517 23.6277 0.429342 20.0118 0.0640933 15.4055C-0.15764 12.6091 1.84925 10.0928 4.62478 9.66451L5.15777 9.58227C6.47057 9.37971 7.40303 8.42735 7.82152 7.20972C8.65916 4.77256 11.2197 3.33422 13.721 3.93203C14.9716 4.23092 16.1124 4.79361 17.0823 5.56062L18.4382 4.2048L18.3954 4.16199C18.0048 3.77146 18.0048 3.1383 18.3954 2.74777L20.7478 0.39531ZM13.9982 8.64474L15.6556 6.9874C14.9524 6.47076 14.141 6.08874 13.2561 5.87725C11.6176 5.48564 10.1649 6.54471 9.64603 8.05442C9.01026 9.90425 7.39357 11.261 5.46276 11.5589L4.92977 11.6411C3.18023 11.9111 1.9196 13.504 2.05784 15.2474C2.34539 18.8739 5.18308 21.7116 8.80962 21.9992C10.553 22.1374 12.1459 20.8768 12.4159 19.1272L12.4981 18.5943C12.7961 16.6634 14.1528 15.0468 16.0026 14.411C17.5123 13.8921 18.5714 12.4395 18.1798 10.8009C17.9683 9.91607 17.5863 9.10475 17.0697 8.40164L15.4124 10.059C15.0219 10.4495 14.3887 10.4495 13.9982 10.059C13.6077 9.66843 13.6077 9.03527 13.9982 8.64474ZM11.4999 15C12.8807 15 13.9999 13.8807 13.9999 12.5C13.9999 11.1193 12.8807 10 11.4999 10C10.1192 10 8.99994 11.1193 8.99994 12.5C8.99994 13.8807 10.1192 15 11.4999 15Z" />
    </svg>
);

export const BassIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 50 120" className={className} fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <path d="M10,45 C0,45 0,95 10,110 C20,120 40,110 40,90 C40,75 30,70 25,65 C30,60 40,50 40,40 C40,30 10,30 10,40 C10,50 15,55 25,60" className="fill-zinc-900 text-zinc-700" />
        <rect x="23" y="-5" width="4" height="70" className="fill-zinc-800" />
        <rect x="22" y="75" width="3" height="10" className="fill-zinc-600" />
        <rect x="25" y="80" width="3" height="10" className="fill-zinc-600" />
    </svg>
);

export const DrumKitIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 512.001 512.001" className={className} fill="currentColor">
        <path d="M256,237.13c-39.115,0-70.938,31.823-70.938,70.938s31.823,70.938,70.938,70.938s70.938-31.823,70.938-70.938
			S295.115,237.13,256,237.13z M256,353.939c-25.293,0-45.871-20.577-45.871-45.871c0-25.294,20.578-45.871,45.871-45.871
			s45.871,20.578,45.871,45.871S281.293,353.939,256,353.939z"/>
        <path d="M473.963,150.783c-15.997-3.492-36.305-5.656-58.159-6.259v-9.74c0-6.922-5.613-12.534-12.534-12.534
			s-12.534,5.611-12.534,12.534v9.74c-21.855,0.603-42.162,2.769-58.159,6.259c-12.282,2.68-27.602,7.128-34.445,16.333
			c-9.502-2.845-19.403-4.754-29.599-5.619v-20.385h78.335c6.921,0,12.534-5.611,12.534-12.534V54.312
			c0-6.922-5.613-12.534-12.534-12.534H165.131c-6.921,0-12.534,5.611-12.534,12.534v74.266c0,6.922,5.613,12.534,12.534,12.534
			h78.335v20.385c-10.196,0.865-20.098,2.774-29.599,5.619c-6.842-9.205-22.163-13.653-34.445-16.333
			c-15.997-3.492-36.305-5.656-58.159-6.259v-9.74c0-6.922-5.613-12.534-12.534-12.534s-12.534,5.611-12.534,12.534v9.74
			c-21.855,0.603-42.162,2.769-58.159,6.259C21.707,154.345,0,161.031,0,177.872c0,16.841,21.707,23.527,38.037,27.09
			c15.997,3.492,36.305,5.656,58.159,6.259v172.972l-45.262,66.437c-3.897,5.72-2.419,13.518,3.303,17.415
			c5.718,3.897,13.516,2.42,17.416-3.301l37.078-54.425l37.078,54.425c2.427,3.561,6.363,5.478,10.369,5.478
			c2.429,0,4.886-0.706,7.045-2.177c5.72-3.897,7.199-11.694,3.303-17.415l-45.263-66.437V367.09
			c22.786,51.813,74.6,88.088,134.737,88.088s111.951-36.275,134.737-88.088v17.103l-45.262,66.437
			c-3.897,5.72-2.419,13.518,3.303,17.415c5.719,3.897,13.516,2.42,17.415-3.301l37.078-54.425l37.078,54.425
			c2.427,3.561,6.363,5.478,10.369,5.478c2.429,0,4.886-0.706,7.045-2.177c5.72-3.897,7.199-11.694,3.303-17.415l-45.262-66.437
			V211.222c21.855-0.603,42.162-2.767,58.159-6.259c16.329-3.563,38.037-10.249,38.037-27.09
			C512.001,161.031,490.293,154.345,473.963,150.783z M96.196,186.156c-30.034-0.851-51.385-4.662-63.008-8.284
			c11.624-3.62,32.974-7.432,63.008-8.283V186.156z M177.665,116.045v-12.066h79.918c6.921,0,12.534-5.611,12.534-12.534
			s-5.613-12.534-12.534-12.534h-79.918V66.846h156.671v49.198H177.665z M121.263,169.589c30.034,0.851,51.385,4.664,63.008,8.284
			c-11.624,3.62-32.974,7.432-63.008,8.284V169.589z M121.263,211.222c8.774-0.242,17.301-0.732,25.396-1.463
			c-10.427,11.585-19.039,24.83-25.396,39.286V211.222z M256,430.112c-67.294,0-122.044-54.748-122.044-122.044
			S188.706,186.023,256,186.023s122.044,54.75,122.044,122.045S323.294,430.112,256,430.112z M390.737,249.044
			c-6.357-14.455-14.969-27.701-25.396-39.286c8.094,0.732,16.622,1.221,25.396,1.463V249.044z M390.737,186.156
			c-30.034-0.851-51.385-4.664-63.008-8.283c11.622-3.62,32.974-7.432,63.008-8.284V186.156z M415.804,186.156v-16.567
			c30.034,0.851,51.385,4.664,63.008,8.283C467.19,181.493,445.839,185.305,415.804,186.156z"/>
    </svg>
);

export const KeyboardIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 32 32" className={className} fill="currentColor">
        <path d="M28.002,7c0,-0.796 -0.316,-1.559 -0.878,-2.121c-0.563,-0.563 -1.326,-0.879 -2.122,-0.879c-4.184,0 -13.818,-0 -18.002,0c-0.796,-0 -1.559,0.316 -2.121,0.879c-0.563,0.562 -0.879,1.325 -0.879,2.121c-0,4.184 -0,13.816 -0,18c-0,0.796 0.316,1.559 0.879,2.121c0.562,0.563 1.325,0.879 2.121,0.879c4.184,0 13.818,0 18.002,0c0.796,0 1.559,-0.316 2.122,-0.879c0.562,-0.562 0.878,-1.325 0.878,-2.121l0,-18Zm-19.002,-1l-2,-0c-0.265,-0 -0.52,0.105 -0.707,0.293c-0.188,0.187 -0.293,0.442 -0.293,0.707l-0,18c-0,0.265 0.105,0.52 0.293,0.707c0.187,0.188 0.442,0.293 0.707,0.293l3.995,0l-0.039,-8l-0.956,0c-0.552,0 -1,-0.448 -1,-1l-0,-11Zm7.997,-0l-1.997,-0l0,11c-0,0.552 -0.448,1 -1,1l-1.044,0l0.039,8l6.005,0l-0.002,-8l-1.001,0c-0.552,0 -1,-0.448 -1,-1l0,-11Zm6,-0l0,11c0,0.552 -0.447,1 -1,1l-0.999,0l0.002,8l4.002,0c0.266,0 0.52,-0.105 0.708,-0.293c0.187,-0.187 0.292,-0.442 0.292,-0.707l0,-18c0,-0.265 -0.105,-0.52 -0.292,-0.707c-0.188,-0.188 -0.442,-0.293 -0.708,-0.293l-2.005,-0Zm-2,-0l-2,-0l0,10c0,0 2,0 2,-0l0,-10Zm-7.997,-0l-2,-0l-0,10c-0,0 2,0 2,-0l0,-10Z" />
    </svg>
);

export const SubIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 80 80" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="5" y="5" width="70" height="70" rx="1" className="fill-zinc-900 text-zinc-800" />
        <circle cx="40" cy="40" r="28" className="text-zinc-700" strokeDasharray="2,2" />
        <circle cx="40" cy="40" r="22" className="fill-zinc-800/50 text-zinc-600" strokeWidth="3" />
        <circle cx="40" cy="40" r="8" className="fill-zinc-900 text-zinc-700" />
        <rect x="2" y="30" width="4" height="20" rx="1" className="fill-zinc-700" />
        <rect x="74" y="30" width="4" height="20" rx="1" className="fill-zinc-700" />
    </svg>
);

export const SaxIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 512 512" className={className} fill="currentColor">
        <path d="M162.594,48.368c-21.87,0-37.143,17.107-37.143,41.6v39.447c0,10.324-4.017,20.026-11.311,27.318c-7.301,7.298-17.003,11.317-27.318,11.317H42.25v-20.8h35.657v-1.636c0-36.047,29.325-65.372,65.372-65.372c36.047,0,65.372,29.325,65.372,65.372v11.896v7.38h-41.6V89.968C199.737,65.473,184.462,48.368,162.594,48.368z M469.75,306.125h-20.8v-0.001c-27.854,0-50.515,22.66-50.515,50.515v26.296c0,54.783-44.569,99.352-99.352,99.352c-54.78,0-99.346-44.566-99.346-99.346v-91.469h41.6v8.803v89.898c0,24.577,19.995,44.572,44.572,44.572s44.572-19.995,44.572-44.572v-81.076c0-65.327,53.146-118.475,118.469-118.475h20.8V306.125z" />
    </svg>
);

export const TrumpetIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 512.003 512.003" className={className} fill="currentColor">
        <path d="M500.344,82.257L437.589,19.5c-2.448-2.447-5.767-3.823-9.229-3.823c-3.461,0-6.782,1.376-9.229,3.823l-34.208,34.208
			c-1.746-3.585-4.097-6.947-7.07-9.922l-3.908-3.908L342.63,22.28c5.097-5.097,5.097-13.361,0-18.459c-5.098-5.095-13.359-5.095-18.459,0L105.305,222.689c-5.097,5.097-5.097,13.361,0,18.459l105.305,105.305c5.097,5.097,13.361,5.097,18.459,0l300.859-300.859C505.441,95.618,505.441,87.354,500.344,82.257z"/>
    </svg>
);

export const DIIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 60 40" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="5" y="5" width="50" height="30" rx="1" className="fill-zinc-800 text-zinc-600" />
        <circle cx="15" cy="20" r="4" className="fill-zinc-950 text-zinc-500" />
        <circle cx="15" cy="18" r="1" className="fill-zinc-400" />
        <circle cx="13" cy="21" r="1" className="fill-zinc-400" />
        <circle cx="17" cy="21" r="1" className="fill-zinc-400" />
        <rect x="35" y="15" width="10" height="4" rx="0.5" className="fill-red-900/40 text-red-500" />
        <rect x="35" y="21" width="10" height="4" rx="0.5" className="fill-zinc-900" />
    </svg>
);

export const PowerIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 60 60" className={className} fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="10" y="10" width="40" height="40" rx="2" className="fill-amber-950/20 text-amber-600" />
        <circle cx="20" cy="20" r="5" className="fill-zinc-900 text-zinc-700" />
        <circle cx="40" cy="20" r="5" className="fill-zinc-900 text-zinc-700" />
        <circle cx="20" cy="40" r="5" className="fill-zinc-900 text-zinc-700" />
        <circle cx="40" cy="40" r="5" className="fill-zinc-900 text-zinc-700" />
        <path d="M28,25 L35,30 L25,35 L32,40" strokeWidth="2" strokeLinecap="round" className="text-amber-500" />
    </svg>
);

export const RizerIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 100 60" className={className} stroke="currentColor" strokeWidth="2" fill="none">
        <rect x="5" y="15" width="90" height="40" className="fill-zinc-400/20 text-zinc-500" />
        <path d="M5,15 L15,5 L95,5 L95,45 L85,55" className="fill-zinc-300/20 text-zinc-400" />
        <line x1="5" y1="15" x2="95" y2="15" className="text-zinc-500" />
    </svg>
);

export const CongasIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 80 100" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
        <ellipse cx="25" cy="15" rx="15" ry="8" className="fill-orange-100 dark:fill-orange-900/30 text-zinc-800 dark:text-orange-400" />
        <path d="M10,15 C10,40 15,90 25,95 C35,90 40,40 40,15" className="text-orange-700 dark:text-orange-500" />
        <ellipse cx="55" cy="25" rx="15" ry="8" className="fill-orange-100 dark:fill-orange-900/30 text-zinc-800 dark:text-orange-400" />
        <path d="M40,25 C40,50 45,90 55,95 C65,90 70,50 70,25" className="text-orange-700 dark:text-orange-500" />
    </svg>
);

export const StandIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 100 60" className={className} fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M10,50 L90,50" className="text-zinc-400" strokeWidth="4" strokeLinecap="round" />
        <path d="M20,50 L20,10" className="text-zinc-500" />
        <path d="M40,50 L40,10" className="text-zinc-500" />
        <path d="M60,50 L60,10" className="text-zinc-500" />
        <path d="M80,50 L80,10" className="text-zinc-500" />
        <path d="M10,10 L90,10" className="text-zinc-400" strokeWidth="3" />
    </svg>
);

export const BackdropIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 100 80" className={className} fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="5" y="10" width="90" height="60" className="fill-zinc-900/80 text-zinc-700" />
        <path d="M0,5 L100,5" strokeWidth="4" className="text-zinc-800 dark:text-zinc-100" />
        <path d="M10,5 L10,75 M90,5 L90,75" strokeWidth="1" strokeDasharray="4,2" className="text-zinc-500" />
    </svg>
);

export const PianoIcon = ({ className }: { className?: string }) => (
    <svg viewBox="0 0 100 80" className={className} fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M10,10 L90,10 L90,60 Q90,75 75,75 L10,75 Z" className="fill-zinc-200 dark:fill-zinc-800 text-zinc-900 dark:text-white" />
        <rect x="10" y="55" width="80" height="5" className="fill-white dark:fill-zinc-200" />
        <path d="M10,15 L90,15" className="text-zinc-400" />
    </svg>
);

// ----------------------------------------------------------------------
// Configuration
// ----------------------------------------------------------------------

export const ELEMENT_CONFIG: Record<StageItemType, { label: string, icon: React.ElementType, width: string, category: string }> = {
    'drum': { label: 'Bateria', icon: DrumKitIcon, width: 'w-24 h-24', category: 'Ritmo' },
    'percussion': { label: 'Percussão', icon: DrumKitIcon, width: 'w-20 h-20', category: 'Ritmo' },
    'congas': { label: 'Congas', icon: CongasIcon, width: 'w-16 h-20', category: 'Ritmo' },
    'keyboard': { label: 'Teclado', icon: KeyboardIcon, width: 'w-24 h-12', category: 'Harmonia' },
    'piano': { label: 'Pno Digital', icon: PianoIcon, width: 'w-24 h-20', category: 'Harmonia' },
    'bass': { label: 'Baixo', icon: BassIcon, width: 'w-10 h-24', category: 'Cordas' },
    'guitar': { label: 'Gtr Elétrica', icon: GuitarIcon, width: 'w-10 h-24', category: 'Cordas' },
    'guitar-acoustic': { label: 'Gtr Acústica', icon: AcousticGuitarIcon, width: 'w-12 h-24', category: 'Cordas' },
    'sax': { label: 'Sax', icon: SaxIcon, width: 'w-12 h-20', category: 'Sopro' },
    'trumpet': { label: 'Trompete', icon: TrumpetIcon, width: 'w-16 h-10', category: 'Sopro' },
    'bass-amp': { label: 'Amp Baixo', icon: AmpStackIcon, width: 'w-16 h-20', category: 'Amps' },
    'guitar-amp': { label: 'Amp Gtr', icon: AmpStackIcon, width: 'w-16 h-20', category: 'Amps' },
    'side': { label: 'Side Fill', icon: SpeakerIcon, width: 'w-16 h-16', category: 'PA' },
    'monitor': { label: 'Retorno', icon: MonitorWedgeIcon, width: 'w-14 h-10', category: 'PA' },
    'drum-sub': { label: 'Sub Batera', icon: SpeakerIcon, width: 'w-14 h-14', category: 'PA' },
    'mic': { label: 'Voz (Stand)', icon: MicStandIcon, width: 'w-8 h-16', category: 'Voz' },
    'mic-handheld': { label: 'Voz (Mão)', icon: MicIcon, width: 'w-8 h-10', category: 'Voz' },
    'di': { label: 'DI Box', icon: DIIcon, width: 'w-12 h-10', category: 'Infra' },
    'power': { label: 'Energia', icon: PowerIcon, width: 'w-12 h-12', category: 'Infra' },
    'riser': { label: 'Praticável', icon: RizerIcon, width: 'w-24 h-16', category: 'Estrutura' },
    'stand': { label: 'Stand Gtr', icon: StandIcon, width: 'w-20 h-14', category: 'Estrutura' },
    'backdrop': { label: 'Backdrop', icon: BackdropIcon, width: 'w-24 h-20', category: 'Estrutura' },
};

export const StageItemIcon = ({ type, className }: { type: StageItemType, className?: string }) => {
    const config = ELEMENT_CONFIG[type];
    if (!config) return null;
    const Icon = config.icon;
    return <Icon className={className || config.width} />;
};
