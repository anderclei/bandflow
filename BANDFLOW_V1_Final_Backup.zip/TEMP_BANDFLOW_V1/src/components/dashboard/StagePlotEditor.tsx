"use client"

import React, { useState, useEffect } from 'react';
import { DndContext, useDraggable, DragEndEvent, PointerSensor, KeyboardSensor, useSensor, useSensors, PointerActivationConstraint } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { updateShowFormatTechnical } from "@/app/actions/show-formats";
import { toast } from "sonner";

import {
    StageItem,
    StageItemType,
    ELEMENT_CONFIG,
    StageItemIcon
} from './StagePlotAssets';

const DraggableItem = ({ id, type, x, y, label, rotation, scale, selected, onSelect }: StageItem & { selected: boolean, onSelect: () => void }) => {
    const { attributes, listeners, setNodeRef, transform } = useDraggable({
        id: id,
    });

    const style = {
        transform: CSS.Translate.toString(transform),
        left: `${x}px`,
        top: `${y}px`,
        position: 'absolute' as 'absolute',
    };

    const config = ELEMENT_CONFIG[type];

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...listeners}
            {...attributes}
            onClick={() => onSelect()}
            className={`cursor-move transition-transform touch-none flex flex-col items-center group z-10 ${selected ? 'z-50' : ''}`}
        >
            <div
                className={`relative filter drop-shadow-[0_4px_6px_rgba(0,0,0,0.4)] transition-all duration-200 ${selected ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-zinc-100 dark:ring-offset-zinc-900 rounded-sm' : ''}`}
                style={{
                    transform: `rotate(${rotation}deg) scale(${scale})`,
                }}
            >
                <StageItemIcon type={type} />
            </div>

            <span
                className="text-[10px] uppercase tracking-wider font-bold bg-white/90 dark:bg-zinc-50 dark:bg-zinc-800/90 text-zinc-900 dark:text-zinc-100 px-1.5 py-0.5 rounded -mt-2 shadow-sm whitespace-nowrap z-20 pointer-events-none select-none border border-zinc-200 dark:border-zinc-700"
                style={{
                    transform: `translateY(${10 * scale}px)`,
                }}
            >
                {label}
            </span>
        </div>
    );
};

import { Map } from 'lucide-react';

export function StagePlotEditor({ bandId, initialData = [], formatId }: { bandId: string, initialData?: StageItem[], formatId?: string }) {
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [mounted, setMounted] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [items, setItems] = useState<StageItem[]>(initialData);


    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 8,
            },
        }),
        useSensor(KeyboardSensor)
    );

    useEffect(() => {
        setMounted(true);

        const handleKeyDown = (e: KeyboardEvent) => {
            if (selectedId && (e.key === 'Delete' || e.key === 'Backspace')) {
                // Prevenir comportamento padrão se não estiver em um input
                if (document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
                    removeItem(selectedId);
                }
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [selectedId, items]); // Include items if needed for context, but selectedId is key

    if (!mounted) return null;

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, delta } = event;
        setItems((items) =>
            items.map((item) => {
                if (item.id === active.id) {
                    return {
                        ...item,
                        x: item.x + delta.x,
                        y: item.y + delta.y,
                    };
                }
                return item;
            })
        );
    };

    const handleSave = async () => {
        if (!formatId) return;
        setIsSaving(true);
        try {
            const result = await updateShowFormatTechnical(formatId, { stagePlot: JSON.stringify(items) });
            if (result.success) {
                toast.success("Mapa de palco salvo com sucesso!");
            } else {
                toast.error("Erro ao salvar: " + result.error);
            }
        } catch (error) {
            console.error(error);
            toast.error("Ocorreu um erro inesperado.");
        } finally {
            setIsSaving(false);
        }
    }

    const addItem = (type: StageItemType) => {
        const config = ELEMENT_CONFIG[type];
        const newItem: StageItem = {
            id: `${type}-${Date.now()}`,
            type,
            x: 50,
            y: 50,
            label: config.label,
            rotation: 0,
            scale: 1,
        }
        setItems([...items, newItem])
        setSelectedId(newItem.id);
    }

    const updateItem = (id: string, updates: Partial<StageItem>) => {
        setItems(items.map(i => i.id === id ? { ...i, ...updates } : i));
    }

    const removeItem = (id: string) => {
        setItems(items.filter(i => i.id !== id));
        if (selectedId === id) setSelectedId(null);
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">

            <div className="lg:col-span-1 space-y-4">
                <Card className="bg-zinc-50 dark:bg-zinc-50 dark:bg-zinc-800/50">
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-bold flex items-center justify-between">
                            Biblioteca
                            <span className="text-[10px] font-normal text-muted-foreground">{items.length} itens</span>
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="h-[450px] overflow-y-auto pr-2 custom-scrollbar space-y-6">
                        {Array.from(new Set(Object.values(ELEMENT_CONFIG).map(c => c.category))).map(cat => (
                            <div key={cat} className="space-y-2">
                                <h3 className="text-[10px] font-bold uppercase text-muted-foreground tracking-widest px-1">{cat}</h3>
                                <div className="grid grid-cols-2 gap-2">
                                    {(Object.keys(ELEMENT_CONFIG) as StageItemType[])
                                        .filter(type => ELEMENT_CONFIG[type].category === cat)
                                        .map((type) => {
                                            const config = ELEMENT_CONFIG[type];
                                            const Icon = config.icon;
                                            return (
                                                <Button
                                                    key={type}
                                                    variant="outline"
                                                    className="flex flex-col h-20 gap-1 hover:bg-zinc-100 dark:hover:bg-zinc-800 p-1 items-center justify-center border-zinc-200 dark:border-zinc-200 dark:border-zinc-800 transition-all active:scale-95"
                                                    onClick={() => addItem(type)}
                                                >
                                                    <div className="pointer-events-none scale-75">
                                                        <Icon className="w-10 h-10" />
                                                    </div>
                                                    <span className="text-[9px] text-center uppercase tracking-tight font-bold mt-auto">{config.label}</span>
                                                </Button>
                                            )
                                        })}
                                </div>
                            </div>
                        ))}
                    </CardContent>
                </Card>

                <div className="grid grid-cols-1 gap-2">
                    <Button
                        className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold h-10 rounded-xl shadow-lg ring-1 ring-secondary/50"
                        variant="default"
                        disabled={isSaving || !formatId}
                        onClick={handleSave}
                    >
                        {isSaving ? "Salvando..." : "💾 Salvar Alterações"}
                    </Button>
                    <Button
                        className="w-full bg-zinc-200 dark:bg-zinc-800 hover:bg-secondary/10 hover:text-secondary text-zinc-600 dark:text-zinc-400 font-bold h-10 rounded-xl"
                        variant="ghost"
                        onClick={() => {
                            if (window.confirm("🗑️ Deseja realmente limpar todo o palco? Esta ação não pode ser desfeita.")) {
                                setItems([]);
                            }
                        }}
                    >
                        Limpar Palco
                    </Button>
                </div>
            </div>

            <div className="lg:col-span-3">
                <Card className="h-[600px] relative overflow-hidden bg-white dark:bg-[#18181b] border-zinc-200 dark:border-zinc-200 dark:border-zinc-800 shadow-xl transition-colors group/stage">
                    <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]"></div>
                    <div className="absolute top-0 bottom-0 left-1/2 w-[2px] bg-red-500/30 z-0 pointer-events-none border-r border-dashed border-red-500/50"></div>
                    <div className="absolute top-0 left-0 right-0 bg-zinc-100/80 dark:bg-black/40 py-2 border-b border-zinc-200 dark:border-white/5 text-center text-xs font-bold text-zinc-500 dark:text-foreground/30 uppercase tracking-[0.2em] z-0 pointer-events-none">
                        Backstage
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 bg-zinc-100/80 dark:bg-black/40 py-2 border-t border-zinc-200 dark:border-white/5 text-center text-xs font-bold text-zinc-500 dark:text-foreground/30 uppercase tracking-[0.2em] z-0 pointer-events-none">
                        Audience / Plateia
                    </div>

                    <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
                        {items.map((item) => (
                            <DraggableItem
                                key={item.id}
                                {...item}
                                selected={selectedId === item.id}
                                onSelect={() => setSelectedId(item.id)}
                            />
                        ))}
                    </DndContext>

                    {selectedId && (
                        <div className="absolute top-4 right-4 bg-white dark:bg-zinc-800 p-2 rounded-lg shadow-lg border border-zinc-200 dark:border-zinc-700 flex flex-col gap-2 z-50 animate-in fade-in slide-in-from-top-2">
                            <span className="text-[10px] font-bold text-center text-muted-foreground uppercase">Ajustes</span>
                            <div className="flex gap-1 justify-center">
                                <Button
                                    size="icon"
                                    variant="outline"
                                    className="h-8 w-8"
                                    onClick={() => {
                                        const item = items.find(i => i.id === selectedId);
                                        if (item) updateItem(selectedId, { rotation: (item.rotation || 0) - 45 });
                                    }}
                                    title="Girar Esquerda"
                                >
                                    ↺
                                </Button>
                                <Button
                                    size="icon"
                                    variant="outline"
                                    className="h-8 w-8"
                                    onClick={() => {
                                        const item = items.find(i => i.id === selectedId);
                                        if (item) updateItem(selectedId, { rotation: (item.rotation || 0) + 45 });
                                    }}
                                    title="Girar Direita"
                                >
                                    ↻
                                </Button>
                            </div>
                            <div className="flex gap-1 justify-center">
                                <Button
                                    size="icon"
                                    variant="outline"
                                    className="h-8 w-8"
                                    onClick={() => {
                                        const item = items.find(i => i.id === selectedId);
                                        if (item) updateItem(selectedId, { scale: Math.max(0.5, (item.scale || 1) - 0.1) });
                                    }}
                                    title="Diminuir"
                                >
                                    -
                                </Button>
                                <Button
                                    size="icon"
                                    variant="outline"
                                    className="h-8 w-8"
                                    onClick={() => {
                                        const item = items.find(i => i.id === selectedId);
                                        if (item) updateItem(selectedId, { scale: Math.min(2, (item.scale || 1) + 0.1) });
                                    }}
                                    title="Aumentar"
                                >
                                    +
                                </Button>
                            </div>
                            <Button
                                size="sm"
                                variant="destructive"
                                className="w-full h-8 text-xs"
                                onClick={() => removeItem(selectedId)}
                            >
                                Remover
                            </Button>
                        </div>
                    )}
                </Card>
                <div className="flex justify-center mt-4">
                    <p className="text-xs text-muted-foreground bg-muted/50 px-3 py-1 rounded-full">
                        Selecionou? Ajuste o ângulo e tamanho no painel.
                    </p>
                </div>
            </div>
        </div>
    );
}
