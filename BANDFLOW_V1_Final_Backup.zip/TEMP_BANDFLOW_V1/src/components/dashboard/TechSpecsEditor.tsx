"use client"

import React, { useState } from 'react';
import { Save, Music, Speaker, Settings, Info, CheckCircle2, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { updateShowFormatTechnical } from "@/app/actions/show-formats";
import { toast } from "sonner";

export type TechSpecs = {
    paSystem: string;
    monitorSystem: string;
    console: string;
    backlineDrum: string;
    backlineAmps: string;
    backlineOther: string;
}

interface TechSpecsEditorProps {
    formatId: string;
    initialData?: string | null;
}

export function TechSpecsEditor({ formatId, initialData }: TechSpecsEditorProps) {
    const [isSaving, setIsSaving] = useState(false);
    const [specs, setSpecs] = useState<TechSpecs>(() => {
        if (initialData) {
            try {
                return JSON.parse(initialData);
            } catch (e) {
                console.error("Failed to parse tech specs data", e);
            }
        }
        return {
            paSystem: "",
            monitorSystem: "",
            console: "",
            backlineDrum: "",
            backlineAmps: "",
            backlineOther: ""
        };
    });

    const updateSpec = (field: keyof TechSpecs, value: string) => {
        setSpecs(prev => ({ ...prev, [field]: value }));
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            const result = await updateShowFormatTechnical(formatId, {
                techSpecs: JSON.stringify(specs)
            });
            if (result.success) {
                toast.success("Especificações técnicas salvas!");
            } else {
                toast.error("Erro ao salvar especificações");
            }
        } catch (error) {
            toast.error("Ocorreu um erro ao salvar");
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="grid gap-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-3">
                        <FileText className="h-8 w-8 text-secondary" />
                        Rider Técnico
                    </h1>
                    <p className="mt-2 text-zinc-600 dark:text-zinc-400">
                        Especificações detalhadas de som, monitoração e backline.
                    </p>
                </div>
                <Button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="bg-secondary hover:bg-secondary/90 text-white gap-2 transition-all active:scale-95 px-8"
                >
                    {isSaving ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    ) : (
                        <Save className="h-4 w-4" />
                    )}
                    Salvar Especificações
                </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 backdrop-blur-sm">
                    <CardHeader>
                        <div className="flex items-center gap-2 mb-1">
                            <Speaker className="h-5 w-5 text-emerald-500" />
                            <CardTitle>PA & Monitor</CardTitle>
                        </div>
                        <CardDescription>Especificações de sistema de som e monitoração.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid gap-3">
                            <Label className="text-zinc-700 dark:text-zinc-300 font-bold">Sistema de PA</Label>
                            <Textarea
                                value={specs.paSystem}
                                onChange={(e) => updateSpec("paSystem", e.target.value)}
                                placeholder="Ex: Line Array compatível com o local, subwoofers suficientes para cobertura uniforme..."
                                className="min-h-[100px] bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:border-emerald-500/50 transition-colors"
                            />
                        </div>
                        <div className="grid gap-3">
                            <Label className="text-zinc-700 dark:text-zinc-300 font-bold">Monitoração (Vias)</Label>
                            <Textarea
                                value={specs.monitorSystem}
                                onChange={(e) => updateSpec("monitorSystem", e.target.value)}
                                placeholder="Ex: 06 Vias de monitor independentes (In-ear e Wedges)..."
                                className="min-h-[100px] bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:border-emerald-500/50 transition-colors"
                            />
                        </div>
                        <div className="grid gap-3">
                            <Label className="text-zinc-700 dark:text-zinc-300 font-bold">Console (Mesa de Som)</Label>
                            <Textarea
                                value={specs.console}
                                onChange={(e) => updateSpec("console", e.target.value)}
                                placeholder="Ex: Console digital mínimo 32 canais (Yamaha CL5, Midas M32)..."
                                className="min-h-[80px] bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:border-emerald-500/50 transition-colors"
                            />
                        </div>
                    </CardContent>
                </Card>

                <Card className="border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 backdrop-blur-sm">
                    <CardHeader>
                        <div className="flex items-center gap-2 mb-1">
                            <Music className="h-5 w-5 text-emerald-500" />
                            <CardTitle>Backline</CardTitle>
                        </div>
                        <CardDescription>Equipamentos que devem ser fornecidos pelo contratante/local.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid gap-3">
                            <Label className="text-zinc-700 dark:text-zinc-300 font-bold">Bateria</Label>
                            <Textarea
                                value={specs.backlineDrum}
                                onChange={(e) => updateSpec("backlineDrum", e.target.value)}
                                placeholder="Ex: Pearl Export ou superior (Bumbo 22, Tons 10/12, Surdo 16). Ferragens completas..."
                                className="min-h-[100px] bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:border-emerald-500/50 transition-colors"
                            />
                        </div>
                        <div className="grid gap-3">
                            <Label className="text-zinc-700 dark:text-zinc-300 font-bold">Amplificadores de Guitarra/Baixo</Label>
                            <Textarea
                                value={specs.backlineAmps}
                                onChange={(e) => updateSpec("backlineAmps", e.target.value)}
                                placeholder="Ex: 01 Marshall DSL40 para guitarra, 01 Ampeg SVT para baixo..."
                                className="min-h-[100px] bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:border-emerald-500/50 transition-colors"
                            />
                        </div>
                        <div className="grid gap-3">
                            <Label className="text-zinc-700 dark:text-zinc-300 font-bold">Outros / Acessórios</Label>
                            <Textarea
                                value={specs.backlineOther}
                                onChange={(e) => updateSpec("backlineOther", e.target.value)}
                                placeholder="Ex: 04 pontos de energia 110v, estantes de partitura, banco de piano..."
                                className="min-h-[80px] bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 focus:border-emerald-500/50 transition-colors"
                            />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card className="bg-red-500/5 border-red-500/20">
                <CardContent className="py-4 flex items-start gap-3">
                    <Info className="h-5 w-5 text-emerald-500 mt-0.5 shrink-0" />
                    <div className="text-sm text-zinc-400 leading-relaxed">
                        <strong className="text-foreground block mb-1 font-bold italic underline">Dica para o Usuário:</strong>
                        Seja o mais específico possível nos modelos e marcas aceitáveis. Isso evita problemas técnicos no dia do show
                        e garante que a sonoridade da banda seja preservada. Requisitos de energia e espaço também são vitais.
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
