"use client"

import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Map, ListMusic, FileText, Layout, AudioLines, Plus } from "lucide-react";
import { StagePlotEditor } from "./StagePlotEditor";
import { InputListEditor } from "./InputListEditor";
import { TechSpecsEditor } from "./TechSpecsEditor";
import { RiderGenerator } from "./inventory/RiderGenerator";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { createDefaultShowFormat } from "@/app/actions/show-formats";
import { toast } from "sonner";

interface ShowFormat {
    id: string;
    name: string;
    stagePlot: string | null;
    inputList: string | null;
    techSpecs: string | null;
}

interface TechnicalRiderManagerProps {
    formats: ShowFormat[];
    bandId: string;
    bandName: string;
}

export function TechnicalRiderManager({ formats, bandId, bandName }: TechnicalRiderManagerProps) {
    const [selectedFormatId, setSelectedFormatId] = useState<string>(formats[0]?.id || "");
    const selectedFormat = formats.find(f => f.id === selectedFormatId);

    const [isCreatingDefault, setIsCreatingDefault] = useState(false);

    const handleCreateDefaultFormat = async () => {
        setIsCreatingDefault(true);
        try {
            const res = await createDefaultShowFormat(bandId, "Formato Padrão");
            if (res.success) {
                toast.success("Formato criado com sucesso!");
                window.location.reload();
            } else {
                toast.error(res.error || "Erro ao criar formato.");
            }
        } catch (e) {
            toast.error("Erro inesperado.");
        } finally {
            setIsCreatingDefault(false);
        }
    };

    if (formats.length === 0) {
        return (
            <Card className="border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50">
                <CardContent className="h-64 flex flex-col items-center justify-center text-zinc-500 space-y-4">
                    <AudioLines className="h-12 w-12 opacity-20" />
                    <div className="text-center">
                        <p className="font-bold text-foreground mb-1">Mapa de Palco e Rider Técnico</p>
                        <p className="text-sm max-w-sm">Para começar a montar seu mapa de palco e input list, crie seu primeiro formato de show.</p>
                    </div>
                    <Button
                        onClick={handleCreateDefaultFormat}
                        disabled={isCreatingDefault}
                        className="bg-secondary text-white hover:bg-secondary/90 gap-2 font-bold"
                    >
                        {isCreatingDefault ? (
                            <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        ) : (
                            <Plus className="h-4 w-4" />
                        )}
                        Criar Formato Padrão
                    </Button>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-zinc-950/60 p-5 rounded-2xl border border-zinc-200 dark:border-white/5 shadow-sm dark:backdrop-blur-md relative overflow-hidden group">
                {/* Glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-secondary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div className="flex items-center gap-4 relative z-10">
                    <div className="h-10 w-10 rounded-full bg-secondary/10 flex items-center justify-center border border-secondary/20">
                        <Layout className="h-5 w-5 text-secondary" />
                    </div>
                    <div>
                        <h2 className="text-sm font-bold text-zinc-900 dark:text-white uppercase tracking-wider">Selecione o Formato</h2>
                        <p className="text-xs text-zinc-500 dark:text-zinc-400">Cada formato possui seu próprio rider técnico.</p>
                    </div>
                </div>
                <Select value={selectedFormatId} onValueChange={setSelectedFormatId}>
                    <SelectTrigger className="w-full md:w-[300px] bg-zinc-50 dark:bg-black/40 border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white font-medium hover:bg-zinc-100 dark:hover:bg-black/60 focus:ring-1 focus:ring-secondary/50 transition-all relative z-10">
                        <SelectValue placeholder="Selecione um formato" />
                    </SelectTrigger>
                    <SelectContent className="bg-white dark:bg-zinc-950 border-zinc-200 dark:border-white/10 text-zinc-900 dark:text-white">
                        {formats.map((f) => (
                            <SelectItem key={f.id} value={f.id} className="focus:bg-secondary/10 dark:focus:bg-secondary/20 focus:text-secondary cursor-pointer">
                                {f.name}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            {selectedFormat && (
                <Tabs defaultValue="input-list" className="w-full">
                    <TabsList className="grid grid-cols-2 lg:grid-cols-4 w-full bg-zinc-100/80 dark:bg-zinc-950/50 border border-zinc-200 dark:border-white/5 p-1 min-h-[48px] rounded-xl dark:backdrop-blur-md">
                        <TabsTrigger
                            value="input-list"
                            className="py-2.5 px-2 data-[state=active]:bg-white dark:data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary data-[state=active]:shadow-sm gap-2 font-bold transition-all text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 rounded-lg border border-transparent dark:data-[state=active]:border-secondary/20 data-[state=active]:border-zinc-200"
                        >
                            <ListMusic className="h-4 w-4" />
                            Input List
                        </TabsTrigger>
                        <TabsTrigger
                            value="tech-specs"
                            className="py-2.5 px-2 data-[state=active]:bg-white dark:data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary data-[state=active]:shadow-sm gap-2 font-bold transition-all text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 rounded-lg border border-transparent dark:data-[state=active]:border-secondary/20 data-[state=active]:border-zinc-200"
                        >
                            <FileText className="h-4 w-4" />
                            Rider Técnico
                        </TabsTrigger>
                        <TabsTrigger
                            value="stage-plot"
                            className="py-2.5 px-2 data-[state=active]:bg-white dark:data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary data-[state=active]:shadow-sm gap-2 font-bold transition-all text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 rounded-lg border border-transparent dark:data-[state=active]:border-secondary/20 data-[state=active]:border-zinc-200"
                        >
                            <Map className="h-4 w-4" />
                            Mapa de Palco
                        </TabsTrigger>
                        <TabsTrigger
                            value="preview"
                            className="py-2.5 px-2 data-[state=active]:bg-white dark:data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary data-[state=active]:shadow-sm gap-2 font-bold transition-all text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300 rounded-lg border border-transparent dark:data-[state=active]:border-secondary/20 data-[state=active]:border-zinc-200"
                        >
                            <AudioLines className="h-4 w-4" />
                            Rider PDF
                        </TabsTrigger>
                    </TabsList>

                    <div className="mt-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                        <TabsContent value="input-list" className="mt-0">
                            <InputListEditor
                                formatId={selectedFormat.id}
                                initialData={selectedFormat.inputList}
                            />
                        </TabsContent>
                        <TabsContent value="tech-specs" className="mt-0">
                            <TechSpecsEditor
                                formatId={selectedFormat.id}
                                initialData={selectedFormat.techSpecs}
                            />
                        </TabsContent>
                        <TabsContent value="stage-plot" className="mt-0">
                            <StagePlotEditor
                                bandId={bandId}
                                formatId={selectedFormat.id}
                                initialData={selectedFormat.stagePlot ? JSON.parse(selectedFormat.stagePlot) : []}
                            />
                        </TabsContent>
                        <TabsContent value="preview" className="mt-0">
                            <Card className="border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm">
                                <CardContent className="pt-6">
                                    <RiderGenerator
                                        equipment={[]} // We won't use physical equipment anymore
                                        formats={[selectedFormat]}
                                        bandName={bandName}
                                    />
                                </CardContent>
                            </Card>
                        </TabsContent>
                    </div>
                </Tabs>
            )}
        </div>
    );
}
