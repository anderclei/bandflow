"use client"

import { useState, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { createContractor, updateContractor } from "@/app/actions/contractors"

interface ContractorDialogProps {
    open: boolean
    onOpenChange: (open: boolean) => void
    contractor?: any
    onSuccess?: () => void
}

export function ContractorDialog({ open, onOpenChange, contractor, onSuccess }: ContractorDialogProps) {
    const isEdit = !!contractor
    const [isPending, setIsPending] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [type, setType] = useState<"PF" | "PJ">(contractor?.type || "PF")
    const formRef = useRef<HTMLFormElement>(null)

    useEffect(() => {
        if (open) {
            setError(null)
            setIsPending(false)
            if (contractor) {
                setType(contractor.type || "PF")
            } else {
                setType("PF")
            }
        }
    }, [open, contractor])

    async function handleSubmit(formData: FormData) {
        setIsPending(true)
        setError(null)

        formData.append("type", type)

        const result = isEdit
            ? await updateContractor(contractor.id, formData)
            : await createContractor(formData)

        if (result.success) {
            onSuccess?.()
            onOpenChange(false)
        } else {
            setError(result.error as string)
        }
        setIsPending(false)
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-[1000px] w-[95vw] max-h-[90vh] overflow-y-auto outline-none">
                <DialogHeader>
                    <DialogTitle className="text-secondary">{isEdit ? "Editar Contratante" : "Novo Contratante"}</DialogTitle>
                    <DialogDescription className="text-zinc-500">
                        Preencha as informações legais necessárias para a geração de contratos.
                    </DialogDescription>
                </DialogHeader>

                <Tabs value={type} onValueChange={(v) => setType(v as "PF" | "PJ")} className="w-full mt-2">
                    <div className="flex justify-center w-full mb-6">
                        <TabsList className="grid w-full max-w-sm grid-cols-2 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl shadow-inner">
                            <TabsTrigger value="PF" className="rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-700 data-[state=active]:text-foreground data-[state=active]:shadow-sm text-zinc-600 dark:text-zinc-400">Pessoa Física (PF)</TabsTrigger>
                            <TabsTrigger value="PJ" className="rounded-lg data-[state=active]:bg-white dark:data-[state=active]:bg-zinc-700 data-[state=active]:text-foreground data-[state=active]:shadow-sm text-zinc-600 dark:text-zinc-400">Pessoa Jurídica (PJ)</TabsTrigger>
                        </TabsList>
                    </div>

                    <form ref={formRef} action={handleSubmit} className="space-y-6">
                        {error && (
                            <div className="p-3 text-sm text-red-500 bg-red-100 dark:bg-red-500/10 rounded-xl">
                                {error}
                            </div>
                        )}

                        <div className="space-y-4">
                            <div className="text-sm font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-zinc-800 pb-2">
                                Dados Principais
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                <div className="md:col-span-2 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">{type === "PJ" ? "Razão Social *" : "Nome Completo *"}</Label>
                                    <Input name="name" required defaultValue={contractor?.name} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">{type === "PJ" ? "CNPJ *" : "CPF *"}</Label>
                                    <Input name="document" required defaultValue={contractor?.document} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>

                                {type === "PF" && (
                                    <>
                                        <div className="space-y-2">
                                            <Label className="text-zinc-700 dark:text-zinc-300">RG</Label>
                                            <Input name="rg" defaultValue={contractor?.rg} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                        </div>
                                        <div className="space-y-2">
                                            <Label className="text-zinc-700 dark:text-zinc-300">Órgão Emissor / UF</Label>
                                            <Input name="issuingBody" defaultValue={contractor?.issuingBody} placeholder="SSP/SP" className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                        </div>
                                        <div className="space-y-2">
                                            <Label className="text-zinc-700 dark:text-zinc-300">Nacionalidade</Label>
                                            <Input name="nationality" defaultValue={contractor?.nationality} placeholder="Brasileiro(a)" className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                        </div>
                                        <div className="space-y-2">
                                            <Label className="text-zinc-700 dark:text-zinc-300">Estado Civil</Label>
                                            <Input name="maritalStatus" defaultValue={contractor?.maritalStatus} placeholder="Solteiro(a)" className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                        </div>
                                        <div className="space-y-2">
                                            <Label className="text-zinc-700 dark:text-zinc-300">Profissão</Label>
                                            <Input name="profession" defaultValue={contractor?.profession} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>

                        {type === "PJ" && (
                            <div className="space-y-4">
                                <div className="text-sm font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-zinc-800 pb-2">
                                    Dados do Representante Legal
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div className="md:col-span-2 space-y-2">
                                        <Label className="text-zinc-700 dark:text-zinc-300">Nome do Representante *</Label>
                                        <Input name="repName" required={type === "PJ"} defaultValue={contractor?.repName} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-zinc-700 dark:text-zinc-300">CPF</Label>
                                        <Input name="repCpf" defaultValue={contractor?.repCpf} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-zinc-700 dark:text-zinc-300">RG</Label>
                                        <Input name="repRg" defaultValue={contractor?.repRg} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-zinc-700 dark:text-zinc-300">Nacionalidade</Label>
                                        <Input name="repNationality" defaultValue={contractor?.repNationality} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-zinc-700 dark:text-zinc-300">Estado Civil</Label>
                                        <Input name="repMaritalStatus" defaultValue={contractor?.repMaritalStatus} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                    </div>
                                    <div className="md:col-span-2 space-y-2">
                                        <Label className="text-zinc-700 dark:text-zinc-300">Profissão</Label>
                                        <Input name="repProfession" defaultValue={contractor?.repProfession} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                    </div>
                                </div>
                            </div>
                        )}

                        <div className="space-y-4">
                            <div className="text-sm font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-zinc-800 pb-2">
                                Endereço e Contato
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                                <div className="col-span-1 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">CEP</Label>
                                    <Input name="zipCode" defaultValue={contractor?.zipCode} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="col-span-3 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">Rua / Av</Label>
                                    <Input name="address" defaultValue={contractor?.address} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="col-span-1 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">Número</Label>
                                    <Input name="addressNumber" defaultValue={contractor?.addressNumber} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="col-span-1 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">UF</Label>
                                    <Input name="state" defaultValue={contractor?.state} maxLength={2} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>

                                <div className="col-span-2 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">Complemento</Label>
                                    <Input name="addressComplement" defaultValue={contractor?.addressComplement} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="col-span-2 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">Bairro</Label>
                                    <Input name="neighborhood" defaultValue={contractor?.neighborhood} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="col-span-2 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">Cidade</Label>
                                    <Input name="city" defaultValue={contractor?.city} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>

                                <div className="col-span-2 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">E-mail</Label>
                                    <Input name="email" type="email" defaultValue={contractor?.email} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="col-span-2 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">Telefone / WhatsApp</Label>
                                    <Input name="phone" defaultValue={contractor?.phone} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                                <div className="col-span-2 space-y-2">
                                    <Label className="text-zinc-700 dark:text-zinc-300">Observações Internas</Label>
                                    <Input name="notes" defaultValue={contractor?.notes} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                                </div>
                            </div>
                        </div>

                        <div className="flex justify-end gap-2 pt-4 border-t border-zinc-200 dark:border-zinc-800">
                            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancelar</Button>
                            <Button type="submit" disabled={isPending} className="bg-secondary text-white hover:opacity-90 transition-opacity">
                                {isPending ? "Salvando..." : (isEdit ? "Atualizar" : "Cadastrar")}
                            </Button>
                        </div>
                    </form>
                </Tabs>
            </DialogContent>
        </Dialog>
    )
}
