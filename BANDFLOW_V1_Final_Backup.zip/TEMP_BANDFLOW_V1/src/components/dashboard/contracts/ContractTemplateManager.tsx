"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { VisualContractEditor } from "./VisualContractEditor"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FileText, Wand2, Info, FileSignature, Calculator } from "lucide-react"

export function ContractTemplateManager() {
    const [contractContent, setContractContent] = useState(`
        <h1 style="text-align: center">CONTRATO DE PRESTAÇÃO DE SERVIÇOS MUSICAIS</h1>
        <p></p>
        <p>CONTRATADA: {{nome_da_banda}}</p>
        <p>CONTRATANTE: {{nome_contratante}}</p>
        <p></p>
        <p>Pelo presente instrumento particular, as partes acima identificadas têm entre si justo e acertado o presente contrato conforme as cláusulas abaixo:</p>
        <p></p>
        <h3>CLÁUSULA 1 - DO OBJETO</h3>
        <p>A CONTRATADA se compromete a realizar apresentação musical no evento {{nome_evento}}, na cidade de {{cidade}}, no dia {{data_show}}.</p>
        <p></p>
        <h3>CLÁUSULA 2 - DO VALOR</h3>
        <p>O valor total acordado para a prestação dos serviços é de {{valor_cache}}.</p>
    `)

    const [budgetContent, setBudgetContent] = useState(`
        <h1 style="text-align: center">PROPOSTA DE ORÇAMENTO MUSICAL</h1>
        <p></p>
        <p>BANDA: {{nome_da_banda}}</p>
        <p>CLIENTE: {{nome_contratante}}</p>
        <p></p>
        <p>Agradecemos o interesse em nosso trabalho para o evento <strong>{{nome_evento}}</strong> em {{cidade}}.</p>
        <p></p>
        <h3>PROPOSTA COMERCIAL</h3>
        <p>Data sugerida: {{data_show}}</p>
        <p>Valor do Cachê Artístico: <strong>{{valor_cache}}</strong></p>
        <p></p>
        <p>Aguardamos seu retorno para darmos prosseguimento à contratação.</p>
    `)

    const [exclusivityContent, setExclusivityContent] = useState(`
        <h1 style="text-align: center">CARTA DE EXCLUSIVIDADE</h1>
        <p></p>
        <p>Declaramos para os devidos fins de direito prestação de contas, de acordo com o inciso III c/c art. 25 da Lei nº 8.666/93 e Lei 14.133/21, que o artista/banda <strong>{{nome_da_banda}}</strong> é representado de forma EXCLUSIVA pela empresa <strong>{{nome_contratante}}</strong> para fins de comercialização de seus espetáculos musicais.</p>
        <p></p>
        <p>Por ser verdade, firmamos a presente.</p>
        <p></p>
        <p>Data de emissão: {{data_show}}</p>
    `)

    const placeholders = [
        { key: "{{nome_da_banda}}", label: "Nome da Banda" },
        { key: "{{nome_contratante}}", label: "Nome do Contratante" },
        { key: "{{valor_cache}}", label: "Valor do Cachê" },
        { key: "{{data_show}}", label: "Data do Show" },
        { key: "{{nome_evento}}", label: "Nome do Evento" },
        { key: "{{cidade}}", label: "Cidade" },
    ]

    return (
        <div className="grid gap-6 lg:grid-cols-4">
            <div className="lg:col-span-3">
                <Tabs defaultValue="contract" className="w-full">
                    <TabsList className="mb-4 bg-zinc-100/80 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-1 rounded-xl">
                        <TabsTrigger
                            value="contract"
                            className="data-[state=active]:bg-white dark:data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary flex gap-2 font-bold"
                        >
                            <FileSignature className="h-4 w-4" />
                            Contrato
                        </TabsTrigger>
                        <TabsTrigger
                            value="budget"
                            className="data-[state=active]:bg-white dark:data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary flex gap-2 font-bold"
                        >
                            <Calculator className="h-4 w-4" />
                            Orçamento
                        </TabsTrigger>
                        <TabsTrigger
                            value="exclusivity"
                            className="data-[state=active]:bg-white dark:data-[state=active]:bg-secondary/10 data-[state=active]:text-secondary flex gap-2 font-bold"
                        >
                            <FileText className="h-4 w-4" />
                            Exclusividade
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="contract" className="mt-0">
                        <VisualContractEditor
                            initialContent={contractContent}
                            onSave={(html) => {
                                console.log("Saving Contract HTML:", html)
                                alert("Template de Contrato salvo com sucesso!")
                            }}
                        />
                    </TabsContent>

                    <TabsContent value="budget" className="mt-0">
                        <VisualContractEditor
                            initialContent={budgetContent}
                            onSave={(html) => {
                                console.log("Saving Budget HTML:", html)
                                alert("Template de Orçamento salvo com sucesso!")
                            }}
                        />
                    </TabsContent>

                    <TabsContent value="exclusivity" className="mt-0">
                        <VisualContractEditor
                            initialContent={exclusivityContent}
                            onSave={(html) => {
                                console.log("Saving Exclusivity HTML:", html)
                                alert("Carta de Exclusividade salva com sucesso!")
                            }}
                        />
                    </TabsContent>
                </Tabs>
            </div>

            <div className="space-y-6">
                <Card className="bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800">
                    <CardHeader>
                        <CardTitle className="text-sm font-bold flex items-center gap-2">
                            <Wand2 className="h-4 w-4 text-secondary" />
                            Placeholders Inteligentes
                        </CardTitle>
                        <CardDescription className="text-xs">
                            Estes campos serão preenchidos automaticamente.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                        {placeholders.map((p) => (
                            <button
                                key={p.key}
                                onClick={() => {
                                    // In a real impl, we'd use the ref to insert
                                }}
                                className="w-full flex items-center justify-between p-2 rounded border border-zinc-100 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 text-left transition-colors group"
                            >
                                <span className="text-[11px] font-mono text-secondary">{p.key}</span>
                                <span className="text-[10px] text-muted-foreground group-hover:text-foreground">{p.label}</span>
                            </button>
                        ))}

                        <div className="mt-4 p-3 rounded-lg bg-secondary/10 border border-secondary/20 flex gap-3 text-secondary">
                            <Info className="h-4 w-4 shrink-0" />
                            <p className="text-[10px] leading-relaxed opacity-90">
                                Clique no placeholder para copiar ou arraste para o editor. Eles serão substituídos pelos dados reais ao gerar o contrato.
                            </p>
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-white dark:bg-zinc-950 border-zinc-200 dark:border-zinc-800">
                    <CardHeader>
                        <CardTitle className="text-sm font-bold flex items-center gap-2">
                            <FileText className="h-4 w-4 text-secondary" />
                            Exportação & Assinatura
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                        <Button variant="outline" className="w-full text-xs h-9 justify-start gap-2">
                            <FileText className="h-3.5 w-3.5" />
                            Exportar para PDF
                        </Button>
                        <Button variant="outline" className="w-full text-xs h-9 justify-start gap-2">
                            <FileText className="h-3.5 w-3.5 text-secondary" />
                            Exportar para Word (.docx)
                        </Button>
                        <Button variant="default" className="w-full text-xs h-9 justify-start gap-2 bg-secondary text-white hover:bg-secondary/90 border-0">
                            <Wand2 className="h-3.5 w-3.5" />
                            Solicitar Assinatura
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}
