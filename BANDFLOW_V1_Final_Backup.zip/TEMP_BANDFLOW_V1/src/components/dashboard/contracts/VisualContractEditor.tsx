"use client"

import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Underline from '@tiptap/extension-underline'
import TextAlign from '@tiptap/extension-text-align'
import { Button } from "@/components/ui/button"
import { Toggle } from "@/components/ui/toggle"
import {
    Bold,
    Italic,
    Underline as UnderlineIcon,
    AlignLeft,
    AlignCenter,
    AlignRight,
    List,
    ListOrdered,
    Save,
    Type
} from "lucide-react"
import { useEffect, forwardRef, useImperativeHandle } from "react"

interface VisualEditorProps {
    initialContent?: string
    onSave: (html: string) => void
    isSaving?: boolean
    onUpdate?: (html: string) => void
}

export interface VisualEditorRef {
    insertContent: (text: string) => void
}

export const VisualContractEditor = forwardRef<VisualEditorRef, VisualEditorProps>(({
    initialContent = "",
    onSave,
    isSaving,
    onUpdate
}, ref) => {
    const editor = useEditor({
        immediatelyRender: false,
        extensions: [
            StarterKit,
            Underline,
            TextAlign.configure({
                types: ['heading', 'paragraph'],
            }),
        ],
        content: initialContent,
        editorProps: {
            attributes: {
                class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none min-h-[500px] border border-zinc-200 dark:border-zinc-800 rounded-md p-8 bg-white dark:bg-zinc-950 shadow-inner',
            },
        },
        editable: true,
        onUpdate: ({ editor }) => {
            if (onUpdate) {
                onUpdate(editor.getHTML())
            }
        }
    })

    useImperativeHandle(ref, () => ({
        insertContent: (text: string) => {
            if (editor) {
                editor.chain().focus().insertContent(text).run()
            }
        }
    }))

    useEffect(() => {
        if (editor && initialContent && editor.getHTML() !== initialContent) {
            if (editor.isEmpty) editor.commands.setContent(initialContent)
        }
    }, [initialContent, editor])

    if (!editor) {
        return null
    }

    return (
        <div className="space-y-4">
            <div className="sticky top-0 z-10 flex flex-wrap items-center gap-1 border border-zinc-200 dark:border-zinc-800 p-1.5 rounded-lg bg-white/80 dark:bg-zinc-950/80 backdrop-blur shadow-sm">
                <Toggle
                    size="sm"
                    pressed={editor.isActive('bold')}
                    onPressedChange={() => editor.chain().focus().toggleBold().run()}
                    className="h-8 w-8 p-0"
                >
                    <Bold className="h-4 w-4" />
                </Toggle>
                <Toggle
                    size="sm"
                    pressed={editor.isActive('italic')}
                    onPressedChange={() => editor.chain().focus().toggleItalic().run()}
                    className="h-8 w-8 p-0"
                >
                    <Italic className="h-4 w-4" />
                </Toggle>
                <Toggle
                    size="sm"
                    pressed={editor.isActive('underline')}
                    onPressedChange={() => editor.chain().focus().toggleUnderline().run()}
                    className="h-8 w-8 p-0"
                >
                    <UnderlineIcon className="h-4 w-4" />
                </Toggle>

                <div className="w-px h-4 bg-zinc-200 dark:bg-zinc-800 mx-1" />

                <Toggle
                    size="sm"
                    pressed={editor.isActive({ textAlign: 'left' })}
                    onPressedChange={() => editor.chain().focus().setTextAlign('left').run()}
                    className="h-8 w-8 p-0"
                >
                    <AlignLeft className="h-4 w-4" />
                </Toggle>
                <Toggle
                    size="sm"
                    pressed={editor.isActive({ textAlign: 'center' })}
                    onPressedChange={() => editor.chain().focus().setTextAlign('center').run()}
                    className="h-8 w-8 p-0"
                >
                    <AlignCenter className="h-4 w-4" />
                </Toggle>
                <Toggle
                    size="sm"
                    pressed={editor.isActive({ textAlign: 'right' })}
                    onPressedChange={() => editor.chain().focus().setTextAlign('right').run()}
                    className="h-8 w-8 p-0"
                >
                    <AlignRight className="h-4 w-4" />
                </Toggle>

                <div className="w-px h-4 bg-zinc-200 dark:bg-zinc-800 mx-1" />

                <Toggle
                    size="sm"
                    pressed={editor.isActive('bulletList')}
                    onPressedChange={() => editor.chain().focus().toggleBulletList().run()}
                    className="h-8 w-8 p-0"
                >
                    <List className="h-4 w-4" />
                </Toggle>
                <Toggle
                    size="sm"
                    pressed={editor.isActive('orderedList')}
                    onPressedChange={() => editor.chain().focus().toggleOrderedList().run()}
                    className="h-8 w-8 p-0"
                >
                    <ListOrdered className="h-4 w-4" />
                </Toggle>

                <div className="ml-auto flex items-center gap-2 pr-1">
                    <Button size="sm" variant="outline" className="h-8 gap-2 border-secondary/20 hover:bg-secondary/10 text-secondary hover:text-secondary">
                        <Type className="h-3.5 w-3.5" />
                        Placeholder
                    </Button>
                    <Button size="sm" onClick={() => onSave(editor.getHTML())} disabled={isSaving} className="h-8 gap-2 bg-secondary text-white hover:bg-secondary/90 border-0">
                        <Save className="h-3.5 w-3.5" />
                        {isSaving ? "Salvando..." : "Salvar"}
                    </Button>
                </div>
            </div>

            <EditorContent editor={editor} />
        </div>
    )
})

VisualContractEditor.displayName = "VisualContractEditor"
