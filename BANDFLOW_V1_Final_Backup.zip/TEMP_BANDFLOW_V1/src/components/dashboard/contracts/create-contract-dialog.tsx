"use client"

import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { useState } from "react"
import { ContractPDFPreview } from "./contract-pdf-preview"

import { useEffect } from "react"
import { getContractors } from "@/app/actions/contractors"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"

interface CreateContractDialogProps {
    open: boolean
    onOpenChange: (open: boolean) => void
}

export function CreateContractDialog({ open, onOpenChange }: CreateContractDialogProps) {
    const [date, setDate] = useState<Date>()
    const [includeRider, setIncludeRider] = useState(false)
    const [showPreview, setShowPreview] = useState(false)
    const [contractors, setContractors] = useState<any[]>([])
    const [suppliers, setSuppliers] = useState<any[]>([])
    const [outsideHeadquarters, setOutsideHeadquarters] = useState(false)

    useEffect(() => {
        if (open) {
            getContractors().then(res => {
                if (res.success && res.data) {
                    setContractors(res.data)
                }
            })
            // Dynamically import to avoid circular dependencies if any
            import("@/app/actions/logistics-suppliers").then(mod => {
                mod.getLogisticsSuppliers().then(res => {
                    setSuppliers(res)
                })
            })
        }
    }, [open])

    // Estados do formulário
    const [contractType, setContractType] = useState<"BAR" | "WEDDING" | "CITY_HALL">("BAR")
    const [formData, setFormData] = useState({
        clientName: "",
        venue: "",
        amount: "",
        startTime: "",
        endTime: "",
        distanceKm: "",
        logisticsSupplierId: "none",
        // Campos dinâmicos
        couvertValue: "",
        foodIncluded: false,
        ceremonyTime: "",
        biddingProcess: "",
        paymentTerms: "",
    })

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
        setFormData(prev => ({ ...prev, [name]: value }))
    }

    const handleSelectChange = (value: string) => {
        setFormData(prev => ({ ...prev, clientName: value }))
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Novo Orçamento / Contrato</DialogTitle>
                    <DialogDescription>
                        Preencha os dados do evento para gerar uma proposta (orçamento) ou contrato.
                    </DialogDescription>
                </DialogHeader>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                    {/* Lado Esquerdo - Formulário */}
                    <div className="space-y-4">
                        <div className="grid gap-2">
                            <Label>Tipo de Contrato</Label>
                            <Select value={contractType} onValueChange={(val: any) => setContractType(val)}>
                                <SelectTrigger className="w-full bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 rounded-xl">
                                    <SelectValue placeholder="Selecione o tipo..." />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="BAR">Bar / Pub / Restaurante</SelectItem>
                                    <SelectItem value="WEDDING">Evento Social (Casamento/15 Anos)</SelectItem>
                                    <SelectItem value="CITY_HALL">Prefeitura / Edital / Evento Público</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="grid gap-2">
                            <Label htmlFor="clientName">Contratante</Label>
                            <Select value={formData.clientName} onValueChange={handleSelectChange}>
                                <SelectTrigger className="w-full bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 rounded-xl">
                                    <SelectValue placeholder="Selecione um contratante salvo" />
                                </SelectTrigger>
                                <SelectContent>
                                    {contractors.map(c => (
                                        <SelectItem key={c.id} value={c.name}>
                                            {c.name} {c.document ? `(${c.document})` : ''}
                                        </SelectItem>
                                    ))}
                                    {contractors.length === 0 && (
                                        <SelectItem value="none" disabled>Nenhum contratante cadastrado</SelectItem>
                                    )}
                                </SelectContent>
                            </Select>
                            <div className="text-right">
                                <a href="/dashboard/contractors" className="text-xs text-secondary hover:underline">
                                    + Cadastrar novo contratante
                                </a>
                            </div>
                        </div>

                        {/* Campos Dinâmicos por Tipo */}
                        {contractType === "BAR" && (
                            <div className="p-4 rounded-xl bg-orange-500/5 border border-orange-500/10 space-y-4">
                                <div className="grid gap-2">
                                    <Label htmlFor="couvertValue">Valor do Couvert (R$)</Label>
                                    <Input
                                        id="couvertValue"
                                        name="couvertValue"
                                        type="number"
                                        placeholder="Ex: 15,00"
                                        value={formData.couvertValue}
                                        onChange={handleInputChange}
                                    />
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Switch
                                        id="food-included"
                                        checked={formData.foodIncluded}
                                        onCheckedChange={(val) => setFormData(prev => ({ ...prev, foodIncluded: val }))}
                                    />
                                    <Label htmlFor="food-included">Alimentação/Bebida inclusa?</Label>
                                </div>
                            </div>
                        )}

                        {contractType === "WEDDING" && (
                            <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/10 space-y-4">
                                <div className="grid gap-2">
                                    <Label htmlFor="ceremonyTime">Horário da Cerimônia (se houver)</Label>
                                    <Input
                                        id="ceremonyTime"
                                        name="ceremonyTime"
                                        type="time"
                                        value={formData.ceremonyTime}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>
                        )}

                        {contractType === "CITY_HALL" && (
                            <div className="p-4 rounded-xl bg-blue-500/5 border border-blue-500/10 space-y-4">
                                <div className="grid gap-2">
                                    <Label htmlFor="biddingProcess">Processo / Licitação nº</Label>
                                    <Input
                                        id="biddingProcess"
                                        name="biddingProcess"
                                        placeholder="Ex: Pregão 001/2024"
                                        value={formData.biddingProcess}
                                        onChange={handleInputChange}
                                    />
                                </div>
                                <div className="grid gap-2">
                                    <Label htmlFor="paymentTerms">Prazo de Pagamento</Label>
                                    <Input
                                        id="paymentTerms"
                                        name="paymentTerms"
                                        placeholder="Ex: 30 dias após emissão da NF"
                                        value={formData.paymentTerms}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>
                        )}

                        <div className="grid gap-2">
                            <Label>Data do Show</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button
                                        variant={"outline"}
                                        className={cn(
                                            "w-full justify-start text-left font-normal",
                                            !date && "text-muted-foreground"
                                        )}
                                    >
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {date ? format(date, "PPP", { locale: ptBR }) : <span>Selecione uma data</span>}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0">
                                    <Calendar
                                        mode="single"
                                        selected={date}
                                        onSelect={setDate}
                                        initialFocus
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>

                        <div className="grid gap-2">
                            <Label htmlFor="venue">Local do Evento</Label>
                            <Input
                                id="venue"
                                name="venue"
                                placeholder="Endereço completo"
                                value={formData.venue}
                                onChange={handleInputChange}
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="grid gap-2">
                                <Label htmlFor="startTime">Início</Label>
                                <Input
                                    id="startTime"
                                    name="startTime"
                                    type="time"
                                    value={formData.startTime}
                                    onChange={handleInputChange}
                                />
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="endTime">Término</Label>
                                <Input
                                    id="endTime"
                                    name="endTime"
                                    type="time"
                                    value={formData.endTime}
                                    onChange={handleInputChange}
                                />
                            </div>
                        </div>

                        <div className="grid gap-2">
                            <Label htmlFor="amount">Cachê (R$)</Label>
                            <Input
                                id="amount"
                                name="amount"
                                type="number"
                                placeholder="0,00"
                                value={formData.amount}
                                onChange={handleInputChange}
                            />
                        </div>

                        <div className="flex items-center space-x-2 pt-2 pb-2">
                            <Switch
                                id="outside-headquarters"
                                checked={outsideHeadquarters}
                                onCheckedChange={setOutsideHeadquarters}
                            />
                            <Label htmlFor="outside-headquarters">Evento fora da sede? (Cobrar Deslocamento)</Label>
                        </div>

                        {outsideHeadquarters && (
                            <div className="grid grid-cols-2 gap-4 border-l-2 pl-4 border-secondary/50 ml-1">
                                <div className="grid gap-2">
                                    <Label>Fornecedor de Logística</Label>
                                    <Select
                                        value={formData.logisticsSupplierId}
                                        onValueChange={(val) => setFormData(prev => ({ ...prev, logisticsSupplierId: val }))}
                                    >
                                        <SelectTrigger className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 rounded-xl">
                                            <SelectValue placeholder="Selecione..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="none">Nenhum (Valor Manual)</SelectItem>
                                            {suppliers.map(sup => (
                                                <SelectItem key={sup.id} value={sup.id}>
                                                    {sup.name} (R$ {sup.kmValue}/km)
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="grid gap-2">
                                    <Label htmlFor="distanceKm">Distância Total (KM)</Label>
                                    <Input
                                        id="distanceKm"
                                        name="distanceKm"
                                        type="number"
                                        placeholder="Ex: 150"
                                        value={formData.distanceKm}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>
                        )}

                        <div className="flex items-center space-x-2 pt-2">
                            <Switch
                                id="rider-mode"
                                checked={includeRider}
                                onCheckedChange={setIncludeRider}
                            />
                            <Label htmlFor="rider-mode">Incluir Rider Técnico automaticamente?</Label>
                        </div>

                        <Button className="w-full mt-4" onClick={() => setShowPreview(true)}>
                            Gerar Prévia
                        </Button>
                    </div>

                    {/* Lado Direito - Preview */}
                    <div className="border rounded-lg p-4 bg-muted/50 min-h-[400px] flex flex-col">
                        <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider text-muted-foreground">Prévia do Contrato</h3>
                        {showPreview ? (
                            <ContractPDFPreview
                                data={{
                                    ...formData,
                                    contractType,
                                    date,
                                    includeRider,
                                    outsideHeadquarters,
                                    displacementValue: (() => {
                                        if (!outsideHeadquarters || !formData.distanceKm) return 0;
                                        const supplier = suppliers.find(s => s.id === formData.logisticsSupplierId);
                                        return supplier ? (supplier.kmValue * Number(formData.distanceKm)) : 0;
                                    })()
                                }}
                            />
                        ) : (
                            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm text-center p-8 border-2 border-dashed rounded-md">
                                Preencha o formulário e clique em "Gerar Prévia" para visualizar o contrato.
                            </div>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    )
}
