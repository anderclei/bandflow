"use client";

import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Deal } from "./KanbanBoard";
import { Building, DollarSign } from "lucide-react";

export function DealCard({ deal }: { deal: Deal }) {
    const {
        setNodeRef,
        attributes,
        listeners,
        transform,
        transition,
        isDragging,
    } = useSortable({
        id: deal.id,
        data: {
            type: "Deal",
            deal,
        },
    });

    const style = {
        transition,
        transform: CSS.Transform.toString(transform),
    };

    if (isDragging) {
        return (
            <div
                ref={setNodeRef}
                style={style}
                className="bg-emerald-500/20 border-2 border-emerald-500 rounded-2xl h-28 opacity-50"
            />
        );
    }

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...attributes}
            {...listeners}
            className="bg-white dark:bg-zinc-950 p-4 rounded-2xl shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-800 cursor-grab active:cursor-grabbing hover:ring-emerald-500/50 transition-all group"
        >
            <h4 className="font-bold text-sm text-foreground mb-2 group-hover:text-emerald-500 transition-colors">
                {deal.title}
            </h4>

            <div className="space-y-2 mt-3">
                {deal.contractor && (
                    <div className="flex items-center gap-1.5 text-xs text-zinc-500">
                        <Building className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">{deal.contractor.name}</span>
                    </div>
                )}

                {deal.value ? (
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                        <DollarSign className="h-3.5 w-3.5 text-emerald-500 shrink-0 -ml-0.5" />
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(deal.value)}
                    </div>
                ) : (
                    <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                        <DollarSign className="h-3.5 w-3.5 shrink-0 -ml-0.5" />
                        A definir
                    </div>
                )}
            </div>

            {deal.status === "WON" && (
                <div className="max-w-max mt-4">
                    <a
                        href={`/dashboard/gigs/new?dealId=${deal.id}&title=${encodeURIComponent(deal.title)}${deal.contractorId ? `&contractorId=${deal.contractorId}` : ''}${deal.value ? `&fee=${deal.value}` : ''}`}
                        className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-500/10 px-3 py-2 text-xs font-semibold text-emerald-600 hover:bg-emerald-500/20 transition-colors"
                    >
                        Converter em Show
                    </a>
                </div>
            )}
        </div>
    );
}
