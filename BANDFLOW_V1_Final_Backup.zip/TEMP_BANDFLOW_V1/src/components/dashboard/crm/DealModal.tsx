"use client";

import { createDeal } from "@/app/actions/deals";
import { Plus, X } from "lucide-react";
import { useTransition } from "react";

interface DealModalProps {
    isOpen: boolean;
    onClose: () => void;
    contractors: any[];
    bandId: string;
}

export function DealModal({ isOpen, onClose, contractors, bandId }: DealModalProps) {
    const [isPending, startTransition] = useTransition();

    if (!isOpen) return null;

    const handleSubmit = (formData: FormData) => {
        startTransition(() => {
            createDeal(bandId, formData);
            onClose();
        });
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
            <div className="bg-white dark:bg-zinc-950 rounded-3xl p-6 w-full max-w-lg shadow-xl ring-1 ring-zinc-200 dark:ring-zinc-800 relative">
                <button
                    onClick={onClose}
                    className="absolute right-6 top-6 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 transition-colors"
                >
                    <X className="h-5 w-5" />
                </button>

                <h2 className="text-xl font-bold flex items-center gap-2 mb-6 text-foreground">
                    <Plus className="h-5 w-5 text-emerald-500" />
                    Novo Negócio (Deal)
                </h2>

                <form action={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                            Título do Negócio
                        </label>
                        <input
                            name="title"
                            required
                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 p-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500/20"
                            placeholder="Ex: Show Baile do Hawaii"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                            Contratante (Opcional)
                        </label>
                        <select
                            name="contractorId"
                            className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 p-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500/20"
                            defaultValue="none"
                        >
                            <option value="none">Nenhum / Novo (Sem cadastro)</option>
                            {contractors.map((c) => (
                                <option key={c.id} value={c.id}>
                                    {c.name} {c.city ? `(${c.city})` : ''}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                                Valor Estimado (R$)
                            </label>
                            <input
                                name="value"
                                type="number"
                                step="0.01"
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 p-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500/20"
                                placeholder="0.00"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1">
                                Status Inicial
                            </label>
                            <select
                                name="status"
                                className="w-full rounded-xl bg-zinc-50 border-zinc-200 dark:bg-zinc-900 dark:border-zinc-800 p-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500/20"
                                defaultValue="LEAD"
                            >
                                <option value="LEAD">Lead (Contato Inicial)</option>
                                <option value="NEGOTIATING">Em Negociação</option>
                                <option value="CONTRACT_SENT">Contrato Enviado</option>
                            </select>
                        </div>
                    </div>

                    <div className="pt-2">
                        <button
                            type="submit"
                            disabled={isPending}
                            className="w-full rounded-xl bg-emerald-500 py-3 text-sm font-semibold text-white hover:bg-emerald-600 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isPending ? "Salvando..." : "Salvar Negócio"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}
