"use client";

import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { DealCard } from "./DealCard";
import { Deal } from "./KanbanBoard";

interface ColumnProps {
    column: {
        id: string;
        title: string;
    };
    deals: Deal[];
}

export function KanbanColumn({ column, deals }: ColumnProps) {
    const {
        setNodeRef,
        attributes,
        listeners,
        transform,
        transition,
        isDragging,
    } = useSortable({
        id: column.id,
        data: {
            type: "Column",
            column,
        },
    });

    const style = {
        transition,
        transform: CSS.Transform.toString(transform),
    };

    if (isDragging) {
        return (
            <div
                ref={setNodeRef}
                style={style}
                className="w-80 shrink-0 bg-emerald-500/10 border-2 border-emerald-500/50 rounded-3xl h-full flex flex-col"
            ></div>
        );
    }

    return (
        <div
            ref={setNodeRef}
            style={style}
            className="w-80 shrink-0 bg-zinc-50 dark:bg-zinc-900/50 rounded-3xl h-full flex flex-col"
        >
            <div
                {...attributes}
                {...listeners}
                className="p-4 flex items-center justify-between font-bold text-sm text-zinc-700 dark:text-zinc-300 cursor-grab active:cursor-grabbing border-b border-zinc-200 dark:border-zinc-800"
            >
                <div className="flex items-center gap-2">
                    {column.title}
                    <span className="bg-zinc-200 dark:bg-zinc-800 px-2 py-0.5 rounded-full text-xs font-medium text-zinc-600 dark:text-zinc-400">
                        {deals.length}
                    </span>
                </div>
            </div>

            <div className="flex-1 p-3 overflow-y-auto space-y-3 flex flex-col gap-2">
                {deals.map((deal) => (
                    <DealCard key={deal.id} deal={deal} />
                ))}
            </div>
        </div>
    );
}
