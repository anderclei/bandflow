"use client"

import { useState } from "react"
import { Calendar as CalendarIcon, Upload, Check, AlertTriangle, ArrowRight, DollarSign, Receipt, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface Transaction {
    id: string
    description: string
    amount: number
    type: "INCOME" | "EXPENSE"
    status: "PENDING" | "PAID" | "CANCELLED"
    dueDate?: Date | null
    paymentDate?: Date | null
    receiptUrl?: string | null
    isRecurring?: boolean
}

export function AccountsDashboard({ transactions, bandId }: { transactions: Transaction[], bandId: string }) {
    const [activeTab, setActiveTab] = useState<"PAYABLES" | "RECEIVABLES">("PAYABLES")

    const payables = transactions.filter(t => t.type === "EXPENSE")
    const receivables = transactions.filter(t => t.type === "INCOME")

    const currentList = activeTab === "PAYABLES" ? payables : receivables

    const formatCurrency = (val: number) => {
        return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
    }

    const formatDate = (date: Date | null | undefined) => {
        if (!date) return "Sem data"
        return new Date(date).toLocaleDateString('pt-BR')
    }

    const isOverdue = (date: Date | null | undefined) => {
        if (!date) return false
        return new Date(date) < new Date()
    }

    return (
        <div className="space-y-6">
            <div className="flex bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl w-fit">
                <button
                    onClick={() => setActiveTab("PAYABLES")}
                    className={cn("px-6 py-2 rounded-lg text-sm font-bold transition-all", activeTab === "PAYABLES" ? "bg-white dark:bg-zinc-700 shadow-sm text-red-500" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300")}
                >
                    Contas a Pagar
                </button>
                <button
                    onClick={() => setActiveTab("RECEIVABLES")}
                    className={cn("px-6 py-2 rounded-lg text-sm font-bold transition-all", activeTab === "RECEIVABLES" ? "bg-white dark:bg-zinc-700 shadow-sm text-emerald-500" : "text-zinc-500 hover:text-zinc-700 dark:hover:text-zinc-300")}
                >
                    Contas a Receber
                </button>
            </div>

            <div className="rounded-3xl bg-white dark:bg-zinc-900 shadow-sm ring-1 ring-zinc-200 dark:ring-zinc-800 p-6 sm:p-8">
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h2 className="text-xl font-bold flex items-center gap-2">
                            {activeTab === "PAYABLES" ? <DollarSign className="h-5 w-5 text-red-500" /> : <DollarSign className="h-5 w-5 text-emerald-500" />}
                            {activeTab === "PAYABLES" ? "Despesas e Boletos" : "Faturamentos de Shows e Vendas"}
                        </h2>
                        <p className="text-sm text-zinc-500 mt-1">Gerencie vencimentos, anexos de notas fiscais e comprovantes.</p>
                    </div>
                    <Button className="bg-secondary text-white hover:brightness-90">
                        <Plus className="h-4 w-4 mr-2" />
                        Novo Lançamento
                    </Button>
                </div>

                <div className="space-y-4">
                    {currentList.length === 0 ? (
                        <div className="text-center py-12 border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-2xl">
                            <Receipt className="h-12 w-12 text-zinc-400 mx-auto opacity-50 mb-3" />
                            <p className="text-zinc-500 font-medium">Nenhuma conta cadastrada nesta visão.</p>
                        </div>
                    ) : (
                        currentList.map(t => (
                            <div key={t.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 border border-zinc-100 dark:border-zinc-800 rounded-2xl hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors">
                                <div className="flex items-start gap-4">
                                    <div className={cn(
                                        "h-12 w-12 shrink-0 rounded-xl flex items-center justify-center font-bold",
                                        t.status === "PAID"
                                            ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400"
                                            : isOverdue(t.dueDate)
                                                ? "bg-red-100 text-red-600 dark:bg-red-500/20 dark:text-red-400"
                                                : "bg-amber-100 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400"
                                    )}>
                                        {t.status === "PAID" ? <Check className="h-6 w-6" /> : isOverdue(t.dueDate) ? <AlertTriangle className="h-6 w-6" /> : <CalendarIcon className="h-6 w-6" />}
                                    </div>
                                    <div>
                                        <p className="font-bold text-foreground text-lg">{t.description}</p>
                                        <div className="flex items-center gap-3 text-xs text-zinc-500 mt-1">
                                            <span>Venc: {formatDate(t.dueDate)}</span>
                                            {t.isRecurring && <Badge variant="outline" className="text-[10px] h-5">Recorrente</Badge>}
                                            {t.receiptUrl && <Badge variant="secondary" className="bg-secondary/10 text-secondary border-none h-5"><Receipt className="h-3 w-3 mr-1" /> NF Anexada</Badge>}
                                        </div>
                                    </div>
                                </div>

                                <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between gap-2">
                                    <p className={cn("font-black text-xl", activeTab === "PAYABLES" ? "text-foreground" : "text-emerald-600 dark:text-emerald-400")}>
                                        {formatCurrency(t.amount)}
                                    </p>
                                    <div className="flex items-center gap-2">
                                        {!t.receiptUrl && (
                                            <Button variant="outline" size="sm" className="h-8 text-xs border-dashed gap-1">
                                                <Upload className="h-3 w-3" />
                                                Anexar NF
                                            </Button>
                                        )}
                                        {t.status !== "PAID" && (
                                            <Button size="sm" className="h-8 text-xs bg-zinc-900 text-white dark:bg-white dark:text-black">
                                                Dar Baixa
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    )
}
