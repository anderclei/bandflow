"use client";

import { BarChart3, TrendingUp, TrendingDown, MapPin, LayoutTemplate, DollarSign } from "lucide-react";
import { cn } from "@/lib/utils";

interface DREData {
    revenue: number;
    expenses: number;
    taxes: number;
    commissions: number;
    memberFees: number;
    netProfit: number;
    cityStats: Record<string, number>;
    formatStats: Record<string, number>;
    gigCount: number;
}

export function DREDashboard({ data }: { data: DREData }) {
    const formatCurrency = (val: number) =>
        val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    const sortedCities = Object.entries(data.cityStats).sort((a, b) => b[1] - a[1]);
    const sortedFormats = Object.entries(data.formatStats).sort((a, b) => b[1] - a[1]);

    return (
        <div className="space-y-8">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 shadow-sm">
                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Faturamento Bruto</p>
                    <p className="text-2xl font-black text-foreground">{formatCurrency(data.revenue)}</p>
                    <p className="text-[10px] text-zinc-500 mt-2">{data.gigCount} shows realizados</p>
                </div>
                <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 shadow-sm">
                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Impostos & Comissões</p>
                    <p className="text-2xl font-black text-amber-600">{formatCurrency(data.taxes + data.commissions)}</p>
                </div>
                <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 shadow-sm">
                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Custos & Cachês</p>
                    <p className="text-2xl font-black text-red-500">{formatCurrency(data.expenses + data.memberFees)}</p>
                </div>
                <div className="p-5 rounded-3xl bg-secondary shadow-lg shadow-secondary/20 text-white">
                    <p className="text-[10px] font-bold opacity-70 uppercase tracking-widest mb-1">Lucro Líquido (Real)</p>
                    <p className="text-2xl font-black">{formatCurrency(data.netProfit)}</p>
                    <div className="mt-2 text-[10px] font-bold flex items-center gap-1">
                        <TrendingUp className="h-3 w-3" />
                        {data.revenue > 0 ? ((data.netProfit / data.revenue) * 100).toFixed(1) : 0}% margem
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* City Ranking */}
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h3 className="text-lg font-bold text-foreground mb-6 flex items-center gap-2">
                        <MapPin className="h-5 w-5 text-secondary" />
                        Lucratividade por Cidade
                    </h3>
                    <div className="space-y-4">
                        {sortedCities.map(([city, profit], index) => (
                            <div key={city} className="flex items-center gap-4">
                                <span className="w-6 text-xs font-black text-zinc-300">#{index + 1}</span>
                                <div className="flex-1">
                                    <div className="flex justify-between text-sm mb-1">
                                        <span className="font-bold">{city}</span>
                                        <span className="font-black text-secondary">{formatCurrency(profit)}</span>
                                    </div>
                                    <div className="h-1.5 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                                        <div
                                            className="h-full bg-secondary rounded-full"
                                            style={{ width: `${Math.min(100, (profit / (sortedCities[0][1] || 1)) * 100)}%` }}
                                        />
                                    </div>
                                </div>
                            </div>
                        ))}
                        {sortedCities.length === 0 && <p className="text-sm text-zinc-500 py-4 text-center">Sem dados geográficos.</p>}
                    </div>
                </div>

                {/* Format Ranking */}
                <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h3 className="text-lg font-bold text-foreground mb-6 flex items-center gap-2">
                        <LayoutTemplate className="h-5 w-5 text-secondary" />
                        Performance por Formato
                    </h3>
                    <div className="space-y-4">
                        {sortedFormats.map(([format, profit], index) => (
                            <div key={format} className="flex items-center gap-4">
                                <span className="w-6 text-xs font-black text-zinc-300">#{index + 1}</span>
                                <div className="flex-1">
                                    <div className="flex justify-between text-sm mb-1">
                                        <span className="font-bold">{format}</span>
                                        <span className="font-black text-secondary">{formatCurrency(profit)}</span>
                                    </div>
                                    <div className="h-1.5 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                                        <div
                                            className="h-full bg-secondary rounded-full"
                                            style={{ width: `${Math.min(100, (profit / (sortedFormats[0][1] || 1)) * 100)}%` }}
                                        />
                                    </div>
                                </div>
                            </div>
                        ))}
                        {sortedFormats.length === 0 && <p className="text-sm text-zinc-500 py-4 text-center">Sem dados de formato.</p>}
                    </div>
                </div>
            </div>
        </div>
    );
}
