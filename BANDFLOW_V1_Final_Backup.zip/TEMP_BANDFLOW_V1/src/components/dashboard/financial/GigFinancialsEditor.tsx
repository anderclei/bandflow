"use client";

import { useState } from "react";
import { Plus, Trash2, Save, Loader2, DollarSign, TrendingDown, TrendingUp, AlertCircle, PieChart, Truck, MapPin } from "lucide-react";
import { updateGigExpenses, updateGigFinancials, calculateFreight } from "@/app/actions/financials";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Expense {
    id?: string;
    description: string;
    amount: number;
    category: string;
}

interface GigFinancialsEditorProps {
    gigId: string;
    initialFee: number | null;
    initialTaxRate: number | null;
    initialTaxAmount: number | null;
    initialExpenses: Expense[];
    initialCommissionRate: number | null;
    initialStatus: string;
    suppliers: any[];
}

const CATEGORIES = [
    { value: 'TRANSPORT', label: 'Transporte' },
    { value: 'FOOD', label: 'Alimentação' },
    { value: 'HOTEL', label: 'Hospedagem' },
    { value: 'TECHNICAL', label: 'Técnica/Roadie' },
    { value: 'MARKETING', label: 'Marketing' },
    { value: 'OTHER', label: 'Outros' }
];

const STATUS_OPTIONS = [
    { value: 'UPCOMING', label: 'Agendado' },
    { value: 'PERFORMED', label: 'Realizado' },
    { value: 'SETTLED', label: 'Liquidado (Pago)' },
    { value: 'CANCELLED', label: 'Cancelado' }
];

export function GigFinancialsEditor({
    gigId,
    initialFee,
    initialTaxRate,
    initialTaxAmount,
    initialExpenses,
    initialCommissionRate,
    initialStatus,
    suppliers
}: GigFinancialsEditorProps) {
    const [expenses, setExpenses] = useState<Expense[]>(initialExpenses);
    const [commissionRate, setCommissionRate] = useState(initialCommissionRate || 0);
    const [status, setStatus] = useState(initialStatus);
    const [isSaving, setIsSaving] = useState(false);
    const [isCalculatingFreight, setIsCalculatingFreight] = useState(false);
    const [selectedSupplierId, setSelectedSupplierId] = useState("");

    const fee = initialFee || 0;
    const taxes = (fee * (initialTaxRate || 0) / 100) + (initialTaxAmount || 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    const commission = (fee * commissionRate / 100);
    const netProfit = fee - taxes - totalExpenses - commission;

    const addExpense = () => {
        setExpenses([...expenses, { description: "", amount: 0, category: "OTHER" }]);
    };

    const removeExpense = (index: number) => {
        setExpenses(expenses.filter((_, i) => i !== index));
    };

    const updateExpense = (index: number, field: keyof Expense, value: any) => {
        const newExpenses = [...expenses];
        newExpenses[index] = { ...newExpenses[index], [field]: value };
        setExpenses(newExpenses);
    };

    const handleSave = async () => {
        setIsSaving(true);
        try {
            const expRes = await updateGigExpenses(gigId, expenses);
            const finRes = await updateGigFinancials(gigId, { commissionRate, status });

            if (expRes.success && finRes.success) {
                toast.success("Financeiro atualizado com sucesso!");
            } else {
                toast.error("Erro ao salvar dados financeiros.");
            }
        } catch (error) {
            toast.error("Erro inesperado ao salvar.");
        } finally {
            setIsSaving(false);
        }
    };

    const handleCalculateFreight = async () => {
        if (!selectedSupplierId) {
            toast.error("Selecione um fornecedor logístico primeiro.");
            return;
        }
        setIsCalculatingFreight(true);
        try {
            const res = await calculateFreight(gigId, selectedSupplierId);
            if (res.success && res.data) {
                setExpenses([...expenses, {
                    description: `Frete (Automático): ${res.data.distanceKm} km`,
                    amount: res.data.amount,
                    category: "TRANSPORT"
                }]);
                toast.success(`Custo de frete estimado para ${res.data.distanceKm} km adicionado.`);
            } else {
                toast.error(res.error || "Erro ao calcular frete automático.");
            }
        } catch (error) {
            toast.error("Erro ao chamar serviço de rotas.");
        } finally {
            setIsCalculatingFreight(false);
        }
    };

    return (
        <div className="space-y-6">
            {/* Automatic Freight Module */}
            <div className="bg-zinc-50 dark:bg-zinc-800/50 p-4 rounded-2xl ring-1 ring-zinc-200 dark:ring-zinc-700 flex flex-col md:flex-row md:items-end gap-4">
                <div className="flex-1 space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-1"><Truck className="h-3 w-3" /> Calcular Frete Automático</label>
                    <select
                        value={selectedSupplierId}
                        onChange={(e) => setSelectedSupplierId(e.target.value)}
                        className="w-full rounded-xl bg-white dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                    >
                        <option value="">Selecione um fornecedor de transporte base...</option>
                        {suppliers.map(s => (
                            <option key={s.id} value={s.id}>{s.name} (R$ {s.kmValue.toFixed(2)}/km)</option>
                        ))}
                    </select>
                </div>
                <button
                    onClick={handleCalculateFreight}
                    disabled={isCalculatingFreight || !selectedSupplierId}
                    className="h-10 px-4 rounded-xl bg-secondary text-white font-bold text-sm hover:opacity-90 transition-all shadow-lg flex items-center gap-2 disabled:opacity-50"
                >
                    {isCalculatingFreight ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4" />}
                    Criar Despesa
                </button>
            </div>

            {/* Status & Commission Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Status do Show</ label>
                    <select
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                        className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                    >
                        {STATUS_OPTIONS.map(opt => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                    </select>
                </div>
                <div className="space-y-2">
                    <label className="text-xs font-bold text-zinc-500 uppercase">Comissão Escritório (%)</label>
                    <input
                        type="number"
                        value={commissionRate || ""}
                        onChange={(e) => setCommissionRate(parseFloat(e.target.value) || 0)}
                        className="w-full rounded-xl bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 p-2.5 text-sm outline-none focus:ring-2 focus:ring-secondary/20"
                        placeholder="Ex: 15"
                    />
                </div>
            </div>

            {/* Profit Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
                    <div className="flex items-center gap-2 text-zinc-500 mb-1">
                        <TrendingDown className="h-4 w-4" />
                        <span className="text-[10px] font-bold uppercase tracking-wider">Custos + Comissões</span>
                    </div>
                    <p className="text-lg font-bold text-red-500">
                        R$ {(totalExpenses + commission + taxes).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                </div>
                <div className="p-4 rounded-2xl bg-secondary/5 border border-secondary/10">
                    <div className="flex items-center gap-2 text-secondary mb-1">
                        <TrendingUp className="h-4 w-4" />
                        <span className="text-[10px] font-bold uppercase tracking-wider">Margem Líquida Real</span>
                    </div>
                    <p className="text-lg font-bold text-secondary">
                        R$ {netProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                </div>
            </div>

            {/* Expenses List (Cost Center) */}
            <div className="space-y-4">
                <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-foreground flex items-center gap-2">
                        <PieChart className="h-4 w-4 text-secondary" />
                        Centro de Custos
                    </h3>
                    <button
                        onClick={addExpense}
                        className="p-1 px-3 rounded-lg bg-secondary/10 text-secondary text-xs font-bold hover:bg-secondary/20 transition-colors flex items-center gap-1"
                    >
                        <Plus className="h-3 w-3" />
                        Gasto
                    </button>
                </div>

                <div className="space-y-3">
                    {expenses.length === 0 ? (
                        <div className="p-8 text-center border-2 border-dashed border-zinc-100 dark:border-zinc-800 rounded-2xl">
                            <p className="text-xs text-zinc-400">Nenhum custo extra lançado.</p>
                        </div>
                    ) : (
                        expenses.map((exp, index) => (
                            <div key={index} className="flex gap-2 items-start bg-white dark:bg-zinc-900 p-3 rounded-2xl border border-zinc-100 dark:border-zinc-800 group relative">
                                <div className="flex-1 space-y-2">
                                    <input
                                        type="text"
                                        value={exp.description}
                                        onChange={(e) => updateExpense(index, 'description', e.target.value)}
                                        placeholder="Descrição (ex: Van, Almoço Equipe)"
                                        className="w-full bg-transparent border-none p-0 text-sm font-bold focus:ring-0 placeholder:text-zinc-300"
                                    />
                                    <div className="flex gap-2">
                                        <select
                                            value={exp.category}
                                            onChange={(e) => updateExpense(index, 'category', e.target.value)}
                                            className="bg-zinc-50 dark:bg-zinc-800 text-[10px] font-bold uppercase tracking-tighter px-2 py-1 rounded-md border-none focus:ring-0"
                                        >
                                            {CATEGORIES.map(cat => (
                                                <option key={cat.value} value={cat.value}>{cat.label}</option>
                                            ))}
                                        </select>
                                        <div className="flex items-center gap-1 text-zinc-500 pl-1 text-sm font-black">
                                            <span>R$</span>
                                            <input
                                                type="number"
                                                value={exp.amount || ""}
                                                onChange={(e) => updateExpense(index, 'amount', parseFloat(e.target.value) || 0)}
                                                className="w-20 bg-transparent border-none p-0 text-sm font-black focus:ring-0 tabular-nums"
                                                placeholder="0,00"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <button
                                    onClick={() => removeExpense(index)}
                                    className="p-2 text-zinc-300 hover:text-red-500 transition-colors"
                                >
                                    <Trash2 className="h-4 w-4" />
                                </button>
                            </div>
                        ))
                    )}
                </div>
            </div>

            <button
                onClick={handleSave}
                disabled={isSaving}
                className="w-full flex items-center justify-center gap-2 p-3 rounded-2xl bg-zinc-900 text-white font-bold hover:bg-zinc-800 transition-all dark:bg-white dark:text-black dark:hover:bg-zinc-200 disabled:opacity-50"
            >
                {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Salvar Painel Financeiro
            </button>
        </div>
    );
}
