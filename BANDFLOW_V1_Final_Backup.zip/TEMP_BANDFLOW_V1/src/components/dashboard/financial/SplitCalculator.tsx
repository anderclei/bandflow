"use client"

import { useState } from "react"
import { Calculator, Users, Plus, Trash2, Percent, DollarSign, ArrowRight, Briefcase } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

interface FixedFee {
    id: string
    name: string
    amount: number
}

interface Partner {
    id: string
    name: string
    percentage: number
}

export function SplitCalculator() {
    const [grossAmount, setGrossAmount] = useState<number>(0)
    const [commissionRate, setCommissionRate] = useState<number>(10)
    const [taxRate, setTaxRate] = useState<number>(6)

    // Equipe e Músicos ganham CACHÊ (Valor Fixo)
    const [fixedFees, setFixedFees] = useState<FixedFee[]>([
        { id: "1", name: "Baterista", amount: 400 },
        { id: "2", name: "Baixista", amount: 400 },
        { id: "3", name: "Roadie", amount: 250 },
        { id: "4", name: "Técnico P.A", amount: 350 },
    ])

    // Sócios ganham SPLIT (Porcentagem do Lucro Líquido)
    const [partners, setPartners] = useState<Partner[]>([
        { id: "p1", name: "Cantor (Sócio)", percentage: 70 },
        { id: "p2", name: "Empresário", percentage: 30 },
    ])

    const commissionAmount = grossAmount * (commissionRate / 100)
    const taxAmount = grossAmount * (taxRate / 100)
    const totalFixedFees = fixedFees.reduce((acc, fee) => acc + fee.amount, 0)

    // Lucro Líquido só existe APÓS pagar impostos, comissão e cachês da equipe
    const netProfit = grossAmount - commissionAmount - taxAmount - totalFixedFees

    const totalPercentage = partners.reduce((acc, p) => acc + p.percentage, 0)

    const addFixedFee = () => {
        setFixedFees([...fixedFees, { id: Date.now().toString(), name: `Novo Cachê ${fixedFees.length + 1}`, amount: 0 }])
    }

    const removeFixedFee = (id: string) => {
        setFixedFees(fixedFees.filter(f => f.id !== id))
    }

    const updateFixedFee = (id: string, field: "name" | "amount", value: string | number) => {
        setFixedFees(fixedFees.map(f => f.id === id ? { ...f, [field]: value } : f))
    }

    const addPartner = () => {
        setPartners([...partners, { id: Date.now().toString(), name: `Novo Sócio ${partners.length + 1}`, percentage: 0 }])
    }

    const removePartner = (id: string) => {
        setPartners(partners.filter(p => p.id !== id))
    }

    const updatePartner = (id: string, field: "name" | "percentage", value: string | number) => {
        setPartners(partners.map(p => p.id === id ? { ...p, [field]: value } : p))
    }

    const formatCurrency = (val: number) => {
        return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Lado Esquerdo - Configurações */}
            <div className="space-y-6">
                <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                        <Calculator className="h-5 w-5 text-secondary" />
                        Receita & Deduções Fiscais
                    </h2>
                    <div className="grid gap-4">
                        <div className="grid gap-2">
                            <Label htmlFor="grossAmount">Cachê Venda do Show (R$)</Label>
                            <div className="relative">
                                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 font-bold">R$</span>
                                <Input
                                    id="grossAmount"
                                    type="number"
                                    value={grossAmount || ""}
                                    onChange={(e) => setGrossAmount(Number(e.target.value))}
                                    className="pl-12 bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 h-12 text-lg font-bold focus-visible:ring-secondary/50"
                                    placeholder="0,00"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="grid gap-2">
                                <Label htmlFor="commission">Comissão (%)</Label>
                                <div className="relative">
                                    <Input
                                        id="commission"
                                        type="number"
                                        value={commissionRate}
                                        onChange={(e) => setCommissionRate(Number(e.target.value))}
                                        className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 pr-10 focus-visible:ring-secondary/50"
                                    />
                                    <Percent className="absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
                                </div>
                            </div>
                            <div className="grid gap-2">
                                <Label htmlFor="tax">Impostos NF (%)</Label>
                                <div className="relative">
                                    <Input
                                        id="tax"
                                        type="number"
                                        value={taxRate}
                                        onChange={(e) => setTaxRate(Number(e.target.value))}
                                        className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 pr-10 focus-visible:ring-secondary/50"
                                    />
                                    <Percent className="absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Bloco de Cachês Fixos */}
                <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2">
                            <Briefcase className="h-5 w-5 text-secondary" />
                            <div>
                                <h2 className="text-xl font-bold text-foreground">Cachês Fixos Opeacionais</h2>
                                <p className="text-xs text-zinc-500 font-medium">Músicos de apoio e Equipe Técnica</p>
                            </div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={addFixedFee} className="text-secondary hover:text-secondary/80">
                            <Plus className="h-4 w-4 mr-1" /> Novo Cachê
                        </Button>
                    </div>

                    <div className="space-y-3">
                        {fixedFees.map(fee => (
                            <div key={fee.id} className="flex items-center gap-3">
                                <Input
                                    value={fee.name}
                                    onChange={(e) => updateFixedFee(fee.id, "name", e.target.value)}
                                    className="flex-1 bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-sm focus-visible:ring-secondary/50"
                                    placeholder="Ex: Roadie 1"
                                />
                                <div className="relative w-32">
                                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-bold text-xs">R$</span>
                                    <Input
                                        type="number"
                                        value={fee.amount}
                                        onChange={(e) => updateFixedFee(fee.id, "amount", Number(e.target.value))}
                                        className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 pl-8 pr-2 w-full text-right font-mono focus-visible:ring-secondary/50"
                                    />
                                </div>
                                <Button variant="ghost" size="icon" onClick={() => removeFixedFee(fee.id)} className="text-zinc-400 hover:text-red-500 transition-colors shrink-0">
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Bloco de Sócios (Split percentual) */}
                <div className="rounded-3xl bg-white p-8 shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800">
                    <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2">
                            <Users className="h-5 w-5 text-amber-500" />
                            <div>
                                <h2 className="text-xl font-bold text-foreground">Divisão de Lucros (Sócios)</h2>
                                <p className="text-xs text-zinc-500 font-medium">Opcional: Partilha do saldo restante</p>
                            </div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={addPartner} className="text-amber-500 hover:text-amber-600 hover:bg-amber-500/10 dark:hover:bg-amber-500/10">
                            <Plus className="h-4 w-4 mr-1" /> Novo Sócio
                        </Button>
                    </div>

                    <div className="space-y-3">
                        {partners.map(partner => (
                            <div key={partner.id} className="flex items-center gap-3">
                                <Input
                                    value={partner.name}
                                    onChange={(e) => updatePartner(partner.id, "name", e.target.value)}
                                    className="flex-1 bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 text-sm focus-visible:ring-amber-500/50"
                                    placeholder="Nome do integrante"
                                />
                                <div className="relative w-24">
                                    <Input
                                        type="number"
                                        value={partner.percentage}
                                        onChange={(e) => updatePartner(partner.id, "percentage", Number(e.target.value))}
                                        className="bg-zinc-50 dark:bg-zinc-800 border-zinc-200 dark:border-zinc-700 pr-8 font-mono text-center focus-visible:ring-amber-500/50"
                                    />
                                    <Percent className="absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-zinc-400" />
                                </div>
                                <Button variant="ghost" size="icon" onClick={() => removePartner(partner.id)} className="text-zinc-400 hover:text-red-500 transition-colors shrink-0">
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        ))}
                    </div>

                    {partners.length > 0 && (
                        <div className={cn(
                            "mt-6 p-4 rounded-2xl text-xs font-bold flex justify-between items-center transition-colors border",
                            totalPercentage === 100
                                ? "bg-amber-500/10 text-amber-600 border-amber-500/20 dark:bg-amber-900/20 dark:text-amber-400"
                                : "bg-red-500/10 text-red-500 border-red-500/20 dark:bg-red-900/20"
                        )}>
                            <span>Total de Divisão de Lucros:</span>
                            <span>{totalPercentage}% {totalPercentage !== 100 && "(Complete para 100%)"}</span>
                        </div>
                    )}
                </div>
            </div>

            {/* Lado Direito - Resumo */}
            <div className="space-y-6">
                <div className="rounded-3xl bg-secondary/5 p-8 text-foreground shadow-sm ring-1 ring-secondary/20 sticky top-4">
                    <h2 className="text-xl font-bold mb-8 uppercase tracking-widest text-secondary">Resumo da Operação</h2>

                    <div className="space-y-6">
                        <div className="flex justify-between items-end border-b border-zinc-200 dark:border-zinc-800 pb-4">
                            <span className="text-zinc-500 font-medium">Venda do Show Bruta</span>
                            <span className="text-2xl font-bold">{formatCurrency(grossAmount)}</span>
                        </div>

                        <div className="space-y-3">
                            <div className="flex justify-between text-sm">
                                <span className="text-zinc-500">Impostos de Nota Fiscal ({taxRate}%)</span>
                                <span className="text-red-500 dark:text-red-400 font-mono">-{formatCurrency(taxAmount)}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-zinc-500">Comissão de Venda ({commissionRate}%)</span>
                                <span className="text-red-500 dark:text-red-400 font-mono">-{formatCurrency(commissionAmount)}</span>
                            </div>
                            <div className="flex justify-between text-sm pt-2 border-t border-zinc-200 dark:border-zinc-800">
                                <span className="text-zinc-500 font-medium">Folha de Pagamentos (Equipe)</span>
                                <span className="text-red-500 dark:text-red-400 font-mono font-bold">-{formatCurrency(totalFixedFees)}</span>
                            </div>
                        </div>

                        <div className="bg-secondary p-6 rounded-2xl shadow-lg shadow-secondary/20 mt-8 relative overflow-hidden">
                            <div className="absolute -right-4 -top-4 opacity-20">
                                <DollarSign className="h-32 w-32 text-white" />
                            </div>
                            <div className="relative z-10 flex justify-between items-end">
                                <div>
                                    <p className="text-[10px] uppercase font-bold tracking-widest text-white/80 mb-1">Lucro Líquido Final da Banda</p>
                                    <p className={cn("text-4xl font-black text-white truncate max-w-[200px] xl:max-w-[280px]", netProfit < 0 && "text-red-900")}>
                                        {formatCurrency(netProfit)}
                                    </p>
                                </div>
                            </div>
                        </div>
                        {netProfit < 0 && (
                            <p className="text-xs text-red-500 font-bold bg-red-500/10 p-3 rounded-lg text-center">
                                Atenção: Os cachês superam a arrecadação. O show está dando prejuízo!
                            </p>
                        )}
                    </div>

                    {/* Fatias Percentuais dos Sócios */}
                    {partners.length > 0 && netProfit > 0 && (
                        <div className="mt-8 pt-8 border-t border-zinc-200 dark:border-zinc-800">
                            <h3 className="text-xs font-bold text-amber-600 dark:text-amber-500 uppercase tracking-widest mb-4">Repasse de Lucros (Sócios)</h3>
                            <div className="space-y-3">
                                {partners.map(partner => (
                                    <div key={partner.id} className="flex justify-between items-center bg-white dark:bg-zinc-800 p-3 rounded-xl border border-zinc-200 dark:border-zinc-700 shadow-sm">
                                        <div className="flex items-center gap-2">
                                            <span className="text-amber-600/70 dark:text-amber-500/50 text-[10px] font-bold">{partner.percentage}%</span>
                                            <span className="text-sm font-medium text-foreground">{partner.name}</span>
                                        </div>
                                        <span className="text-base font-bold text-amber-600 dark:text-amber-400">
                                            {formatCurrency(netProfit * (partner.percentage / 100))}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    <Button className="w-full mt-8 bg-secondary text-white hover:brightness-90 h-12 rounded-xl font-bold gap-2 shadow-lg shadow-secondary/20 border-0">
                        Salvar Rateio Financeiro
                        <ArrowRight className="h-4 w-4" />
                    </Button>
                </div>
            </div>
        </div>
    )
}
