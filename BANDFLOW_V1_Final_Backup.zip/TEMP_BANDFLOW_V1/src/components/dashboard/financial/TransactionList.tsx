"use client";

import { Check, Clock, DollarSign, ArrowUpCircle, ArrowDownCircle, Trash2 } from "lucide-react";
import { manageTransaction } from "@/app/actions/financials";
import { toast } from "sonner";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface Transaction {
    id: string;
    description: string;
    amount: number;
    type: 'INCOME' | 'EXPENSE';
    status: 'PENDING' | 'PAID' | 'CANCELLED';
    category?: string | null;
    dueDate?: Date | null;
    paymentDate?: Date | null;
}

export function TransactionList({ transactions, bandId }: { transactions: any[], bandId: string }) {
    const [localTransactions, setLocalTransactions] = useState(transactions);

    const handleMarkAsPaid = async (t: any) => {
        const res = await manageTransaction({
            ...t,
            status: 'PAID',
            paymentDate: new Date(),
            bandId
        });

        if (res.success) {
            toast.success("Pagamento registrado!");
            setLocalTransactions(prev => prev.map(item => item.id === t.id ? { ...item, status: 'PAID', paymentDate: new Date() } : item));
        } else {
            toast.error("Erro ao registrar pagamento.");
        }
    };

    const formatCurrency = (val: number) =>
        val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    return (
        <div className="rounded-3xl bg-white shadow-sm ring-1 ring-zinc-200 dark:bg-zinc-900 dark:ring-zinc-800 overflow-hidden">
            <table className="w-full text-left font-medium">
                <thead className="bg-zinc-50 dark:bg-zinc-800/50 text-zinc-500 dark:text-zinc-400 text-xs uppercase font-bold">
                    <tr>
                        <th className="px-6 py-4">Lançamento</th>
                        <th className="px-6 py-4">Vencimento</th>
                        <th className="px-6 py-4 text-right">Valor</th>
                        <th className="px-6 py-4 text-center">Status</th>
                        <th className="px-6 py-4"></th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
                    {localTransactions.map((t) => (
                        <tr key={t.id} className="group hover:bg-zinc-50 dark:hover:bg-zinc-800/30 transition-colors">
                            <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                    {t.type === 'INCOME' ? (
                                        <ArrowUpCircle className="h-5 w-5 text-emerald-500" />
                                    ) : (
                                        <ArrowDownCircle className="h-5 w-5 text-red-500" />
                                    )}
                                    <div className="flex flex-col">
                                        <span className="text-foreground font-bold">{t.description}</span>
                                        <span className="text-[10px] uppercase text-zinc-400">{t.category || "Geral"}</span>
                                    </div>
                                </div>
                            </td>
                            <td className="px-6 py-4 text-zinc-500 dark:text-zinc-400 text-sm">
                                {t.dueDate ? new Date(t.dueDate).toLocaleDateString('pt-BR') : "---"}
                            </td>
                            <td className={cn(
                                "px-6 py-4 text-sm text-right font-black tabular-nums",
                                t.type === 'INCOME' ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"
                            )}>
                                {t.type === 'INCOME' ? "+" : "-"}{formatCurrency(t.amount)}
                            </td>
                            <td className="px-6 py-4">
                                <div className="flex justify-center">
                                    <span className={cn(
                                        "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase",
                                        t.status === 'PAID' ? "bg-emerald-500/10 text-emerald-500" : "bg-amber-500/10 text-amber-500"
                                    )}>
                                        {t.status === 'PAID' ? "Pago" : "Pendente"}
                                    </span>
                                </div>
                            </td>
                            <td className="px-6 py-4 text-right">
                                {t.status === 'PENDING' && (
                                    <button
                                        onClick={() => handleMarkAsPaid(t)}
                                        className="p-2 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600 transition-colors shadow-sm"
                                        title="Baixar Pagamento"
                                    >
                                        <Check className="h-4 w-4" />
                                    </button>
                                )}
                            </td>
                        </tr>
                    ))}
                    {localTransactions.length === 0 && (
                        <tr>
                            <td colSpan={5} className="p-12 text-center text-zinc-500 text-sm italic">
                                Nenhum lançamento programado.
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}
