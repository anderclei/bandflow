"use client"

import { useState } from "react"
import { Coffee, Plus, Trash2, CheckCircle2, Circle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { addCateringItem, toggleCateringItem, deleteCateringItem } from "@/app/actions/catering"

interface CateringItem {
    id: string
    name: string
    quantity: string | null
    category: string
    isChecked: boolean
}

interface Gig {
    id: string
    title: string
    date: Date
    cateringItems: CateringItem[]
}

export function CateringList({ gigs }: { gigs: Gig[] }) {
    const [selectedGigId, setSelectedGigId] = useState<string>(gigs[0]?.id || "")
    const [newItemName, setNewItemName] = useState("")
    const [newItemQty, setNewItemQty] = useState("")
    const [newItemCategory, setNewItemCategory] = useState("Bebidas")
    const [isSaving, setIsSaving] = useState(false)

    const selectedGig = gigs.find(g => g.id === selectedGigId)

    const handleAddItem = async () => {
        if (!newItemName.trim() || !selectedGigId) return
        setIsSaving(true)
        await addCateringItem(selectedGigId, {
            name: newItemName,
            quantity: newItemQty,
            category: newItemCategory
        })
        setNewItemName("")
        setNewItemQty("")
        setIsSaving(false)
    }

    const categories = Array.from(new Set(selectedGig?.cateringItems.map(i => i.category) || []))
    if (!categories.includes("Bebidas")) categories.push("Bebidas")
    if (!categories.includes("Comidas")) categories.push("Comidas")
    if (!categories.includes("Camarim/Estrutura")) categories.push("Camarim/Estrutura")

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {gigs.length === 0 ? (
                <div className="text-center py-12 rounded-3xl border-2 border-dashed border-zinc-200 dark:border-zinc-800">
                    <p className="text-zinc-500 font-medium">Nenhum show cadastrado. Adicione um show antes de gerenciar itens de camarim.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Event Selector & Add Form */}
                    <div className="space-y-6 lg:col-span-1 border-r border-zinc-100 dark:border-zinc-800 lg:pr-8">
                        <div>
                            <label className="text-sm font-bold text-zinc-500 uppercase tracking-widest mb-3 block">Selecionar Show</label>
                            <select
                                value={selectedGigId}
                                onChange={(e) => setSelectedGigId(e.target.value)}
                                className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none focus:ring-2 focus:ring-secondary/20"
                            >
                                {gigs.map(g => (
                                    <option key={g.id} value={g.id}>
                                        {g.title} - {new Date(g.date).toLocaleDateString("pt-BR")}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className="bg-zinc-50 dark:bg-zinc-900/50 p-6 rounded-3xl space-y-4 ring-1 ring-zinc-200 dark:ring-zinc-800">
                            <h3 className="font-bold flex items-center gap-2 mb-2"><Plus className="h-4 w-4" /> Novo Item</h3>
                            <input
                                placeholder="Nome do item (ex: Água s/ gás)"
                                value={newItemName}
                                onChange={(e) => setNewItemName(e.target.value)}
                                className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm"
                            />
                            <div className="flex gap-2">
                                <input
                                    placeholder="Qtd"
                                    value={newItemQty}
                                    onChange={(e) => setNewItemQty(e.target.value)}
                                    className="w-1/3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm"
                                />
                                <select
                                    value={newItemCategory}
                                    onChange={(e) => setNewItemCategory(e.target.value)}
                                    className="w-2/3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm"
                                >
                                    <option>Bebidas</option>
                                    <option>Comidas</option>
                                    <option>Camarim/Estrutura</option>
                                </select>
                            </div>
                            <Button
                                onClick={handleAddItem}
                                disabled={isSaving || !newItemName.trim()}
                                className="w-full rounded-xl bg-zinc-900 text-white hover:bg-zinc-800 dark:bg-white dark:text-black dark:hover:bg-zinc-200 font-bold"
                            >
                                Adicionar
                            </Button>
                        </div>
                    </div>

                    {/* Checklist */}
                    <div className="lg:col-span-2 space-y-8">
                        {categories.map(cat => {
                            const items = selectedGig?.cateringItems.filter(i => i.category === cat) || []
                            return (
                                <div key={cat} className="space-y-4">
                                    <div className="flex items-center gap-2 border-b border-zinc-100 dark:border-zinc-800 pb-2">
                                        <h3 className="font-bold tracking-widest uppercase text-sm text-zinc-400">{cat}</h3>
                                        <span className="bg-zinc-100 dark:bg-zinc-800 text-zinc-500 text-xs px-2 py-0.5 rounded-full font-bold">
                                            {items.filter(i => i.isChecked).length} / {items.length}
                                        </span>
                                    </div>

                                    {items.length === 0 ? (
                                        <p className="text-zinc-500 text-sm">Nenhum item nesta categoria.</p>
                                    ) : (
                                        <div className="space-y-2">
                                            {items.map(item => (
                                                <div key={item.id} className="flex flex-row items-center justify-between p-3 rounded-2xl border border-zinc-100 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900 transition-colors group">
                                                    <div className="flex items-center gap-3">
                                                        <button
                                                            onClick={async () => await toggleCateringItem(item.id, !item.isChecked)}
                                                            className="text-zinc-400 hover:text-emerald-500 transition-colors"
                                                        >
                                                            {item.isChecked ? <CheckCircle2 className="h-6 w-6 text-emerald-500" /> : <Circle className="h-6 w-6" />}
                                                        </button>
                                                        <span className={`font-medium ${item.isChecked ? 'line-through text-zinc-400' : 'text-foreground'}`}>
                                                            {item.quantity && <span className="font-bold text-secondary mr-2">{item.quantity}</span>}
                                                            {item.name}
                                                        </span>
                                                    </div>
                                                    <button
                                                        onClick={async () => await deleteCateringItem(item.id)}
                                                        className="text-zinc-400 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                                                    >
                                                        <Trash2 className="h-4 w-4" />
                                                    </button>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            )
                        })}
                    </div>
                </div>
            )}
        </div>
    )
}
