"use client"

import { useState } from "react"
import { Plane, Plus, Trash2, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { addFlight, deleteFlight } from "@/app/actions/flights"

interface Flight {
    id: string
    airline: string
    flightNumber: string | null
    locator: string | null
    departureTime: Date | null
    arrivalTime: Date | null
    origin: string | null
    destination: string | null
    passengers: string | null
}

interface Trip {
    id: string
    eventName: string
    city: string
    date: string | null
    flights: Flight[]
}

export function FlightList({ trips }: { trips: Trip[] }) {
    const [selectedTripId, setSelectedTripId] = useState<string>(trips[0]?.id || "")
    const [isSaving, setIsSaving] = useState(false)

    const [formData, setFormData] = useState({
        airline: "",
        flightNumber: "",
        locator: "",
        origin: "",
        destination: "",
        passengers: "",
        departureTime: "",
        arrivalTime: ""
    })

    const selectedTrip = trips.find(t => t.id === selectedTripId)

    const handleAddFlight = async () => {
        if (!formData.airline.trim() || !selectedTripId) return
        setIsSaving(true)

        await addFlight(selectedTripId, {
            airline: formData.airline,
            flightNumber: formData.flightNumber,
            locator: formData.locator,
            origin: formData.origin,
            destination: formData.destination,
            passengers: formData.passengers,
            departureTime: formData.departureTime ? new Date(formData.departureTime) : undefined,
            arrivalTime: formData.arrivalTime ? new Date(formData.arrivalTime) : undefined
        })

        setFormData({ airline: "", flightNumber: "", locator: "", origin: "", destination: "", passengers: "", departureTime: "", arrivalTime: "" })
        setIsSaving(false)
    }

    const formatDateTime = (date: Date | null) => {
        if (!date) return "--:--"
        return new Date(date).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })
    }

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            {trips.length === 0 ? (
                <div className="text-center py-12 rounded-3xl border-2 border-dashed border-zinc-200 dark:border-zinc-800">
                    <Plane className="h-12 w-12 text-zinc-300 dark:text-zinc-700 mx-auto mb-4" />
                    <p className="text-zinc-500 font-medium">Nenhuma viagem cadastrada. Adicione uma na aba de Hotel antes de gerenciar voos.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Event Selector & Add Form */}
                    <div className="space-y-6 lg:col-span-1 border-r border-zinc-100 dark:border-zinc-800 lg:pr-8">
                        <div>
                            <label className="text-sm font-bold text-zinc-500 uppercase tracking-widest mb-3 block">Selecionar Logística Base</label>
                            <select
                                value={selectedTripId}
                                onChange={(e) => setSelectedTripId(e.target.value)}
                                className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none focus:ring-2 focus:ring-secondary/20 font-bold"
                            >
                                {trips.map(t => (
                                    <option key={t.id} value={t.id}>
                                        {t.eventName} ({t.city})
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className="bg-zinc-50 dark:bg-zinc-900/50 p-6 rounded-3xl space-y-4 ring-1 ring-zinc-200 dark:ring-zinc-800">
                            <h3 className="font-bold flex items-center gap-2 mb-2"><Plus className="h-4 w-4" /> Nova Passagem</h3>

                            <input
                                placeholder="Cia Aérea (ex: LATAM, GOL)"
                                value={formData.airline}
                                onChange={(e) => setFormData({ ...formData, airline: e.target.value })}
                                className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm"
                            />

                            <div className="flex gap-2">
                                <input
                                    placeholder="Nº Voo"
                                    value={formData.flightNumber}
                                    onChange={(e) => setFormData({ ...formData, flightNumber: e.target.value })}
                                    className="w-1/2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm"
                                />
                                <input
                                    placeholder="Localizador"
                                    value={formData.locator}
                                    onChange={(e) => setFormData({ ...formData, locator: e.target.value })}
                                    className="w-1/2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm font-bold text-secondary uppercase tracking-wider"
                                />
                            </div>

                            <div className="flex gap-2">
                                <input
                                    placeholder="Origem (GRU)"
                                    value={formData.origin}
                                    onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                                    className="w-1/2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm uppercase"
                                />
                                <input
                                    placeholder="Destino (SDU)"
                                    value={formData.destination}
                                    onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                                    className="w-1/2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm uppercase"
                                />
                            </div>

                            <div className="flex gap-2">
                                <div className="w-1/2">
                                    <label className="text-[10px] uppercase font-bold text-zinc-500 ml-1">Partida</label>
                                    <input
                                        type="datetime-local"
                                        value={formData.departureTime}
                                        onChange={(e) => setFormData({ ...formData, departureTime: e.target.value })}
                                        className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-xs"
                                    />
                                </div>
                                <div className="w-1/2">
                                    <label className="text-[10px] uppercase font-bold text-zinc-500 ml-1">Chegada</label>
                                    <input
                                        type="datetime-local"
                                        value={formData.arrivalTime}
                                        onChange={(e) => setFormData({ ...formData, arrivalTime: e.target.value })}
                                        className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-xs"
                                    />
                                </div>
                            </div>

                            <textarea
                                placeholder="Passageiros (ex: João M, Pedro S)"
                                value={formData.passengers}
                                onChange={(e) => setFormData({ ...formData, passengers: e.target.value })}
                                className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-3 outline-none text-sm min-h-[60px]"
                            />

                            <Button
                                onClick={handleAddFlight}
                                disabled={isSaving || !formData.airline.trim()}
                                className="w-full rounded-xl bg-zinc-900 text-white hover:bg-zinc-800 dark:bg-white dark:text-black dark:hover:bg-zinc-200 font-bold"
                            >
                                Adicionar Voo
                            </Button>
                        </div>
                    </div>

                    {/* Flights List */}
                    <div className="lg:col-span-2 space-y-4">
                        <div className="flex items-center gap-2 border-b border-zinc-100 dark:border-zinc-800 pb-2">
                            <h3 className="font-bold tracking-widest uppercase text-sm text-zinc-400">Próximos Voos Cadastrados</h3>
                            <span className="bg-zinc-100 dark:bg-zinc-800 text-zinc-500 text-xs px-2 py-0.5 rounded-full font-bold">
                                {selectedTrip?.flights.length || 0}
                            </span>
                        </div>

                        {!selectedTrip || selectedTrip.flights.length === 0 ? (
                            <p className="text-zinc-500 text-sm">Nenhum voo cadastrado para este evento.</p>
                        ) : (
                            <div className="space-y-4">
                                {selectedTrip.flights.map(flight => (
                                    <div key={flight.id} className="bg-white dark:bg-zinc-900 border border-zinc-100 dark:border-zinc-800 p-6 rounded-3xl shadow-sm hover:ring-1 hover:ring-secondary/50 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6 group">
                                        <div className="flex-1 space-y-4">
                                            <div className="flex items-center gap-4">
                                                <div className="h-10 w-10 shrink-0 rounded-full bg-secondary/10 flex items-center justify-center text-secondary">
                                                    <Plane className="h-5 w-5" />
                                                </div>
                                                <div>
                                                    <h4 className="font-bold text-lg">{flight.airline} {flight.flightNumber && <span className="text-zinc-400 font-normal ml-1">#{flight.flightNumber}</span>}</h4>
                                                    <p className="text-xs text-zinc-500 font-medium uppercase tracking-widest mt-0.5">Localizador: <span className="text-foreground font-black bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded ml-1">{flight.locator || "N/A"}</span></p>
                                                </div>
                                            </div>

                                            <div className="flex items-center gap-6 bg-zinc-50 dark:bg-zinc-800/50 p-4 rounded-2xl w-fit">
                                                <div className="flex flex-col items-center">
                                                    <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest mb-1">Origem</span>
                                                    <span className="font-black text-xl text-foreground">{flight.origin || "---"}</span>
                                                    <span className="text-xs text-zinc-500 flex items-center gap-1 mt-1"><Clock className="h-3 w-3" /> {formatDateTime(flight.departureTime)}</span>
                                                </div>

                                                <div className="flex flex-col items-center justify-center pt-2">
                                                    <Plane className="h-4 w-4 text-zinc-300 dark:text-zinc-600" />
                                                    <div className="h-px w-16 bg-zinc-200 dark:bg-zinc-700 mt-1" />
                                                </div>

                                                <div className="flex flex-col items-center">
                                                    <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest mb-1">Destino</span>
                                                    <span className="font-black text-xl text-foreground">{flight.destination || "---"}</span>
                                                    <span className="text-xs text-zinc-500 flex items-center gap-1 mt-1"><Clock className="h-3 w-3" /> {formatDateTime(flight.arrivalTime)}</span>
                                                </div>
                                            </div>

                                            {flight.passengers && (
                                                <p className="text-sm text-zinc-600 dark:text-zinc-400 bg-zinc-50 dark:bg-zinc-800/20 p-3 rounded-xl border border-zinc-100 dark:border-zinc-800/50">
                                                    <span className="font-bold text-xs uppercase tracking-widest block mb-1 text-zinc-400">Passageiros</span>
                                                    {flight.passengers}
                                                </p>
                                            )}
                                        </div>

                                        <div className="flex justify-end border-t border-zinc-100 dark:border-zinc-800 pt-4 md:border-0 md:pt-0">
                                            <button
                                                onClick={async () => await deleteFlight(flight.id)}
                                                className="h-10 w-10 rounded-full flex items-center justify-center shrink-0 mb-auto bg-red-50 text-red-500 hover:bg-red-500 hover:text-white transition-colors dark:bg-red-500/10 dark:hover:bg-red-500"
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    )
}
