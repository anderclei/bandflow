"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, Hotel, MapPin, Calendar as CalendarIcon, Trash2, Loader2 } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { createTrip, deleteTrip, createRoom, deleteRoom, assignMemberToRoom, removeAssignment } from "@/app/actions/trips"
import { useRouter } from "next/navigation"

type MemberType = { id: string; name: string | null; role: string; user?: { name: string | null } }
type RoomType = { id: string; name: string; type: string; assignments: { member: MemberType }[] }
type TripType = { id: string; eventName: string; city: string; date: string | null; hotel: string | null; rooms: RoomType[] }

interface Props {
    initialTrips: TripType[];
    members: MemberType[];
}

export function RoomingList({ initialTrips, members }: Props) {
    const router = useRouter();
    const [trips, setTrips] = useState<TripType[]>(initialTrips);
    const [loading, setLoading] = useState<string | null>(null);

    // Novo trip
    const [newTrip, setNewTrip] = useState({ eventName: "", city: "", date: "", hotel: "" });
    const [showNewTrip, setShowNewTrip] = useState(false);

    const handleCreateTrip = async () => {
        if (!newTrip.eventName || !newTrip.city) return toast.error("Nome e cidade são obrigatórios.");
        setLoading("create-trip");
        try {
            await createTrip(newTrip);
            setNewTrip({ eventName: "", city: "", date: "", hotel: "" });
            setShowNewTrip(false);
            router.refresh();
            toast.success("Evento de hospedagem criado!");
        } catch { toast.error("Erro ao criar evento."); }
        finally { setLoading(null); }
    };

    const handleDeleteTrip = async (id: string) => {
        if (!confirm("Excluir este evento e todos os quartos?")) return;
        setLoading("delete-" + id);
        try {
            await deleteTrip(id);
            setTrips(trips.filter(t => t.id !== id));
            toast.success("Evento excluído!");
        } catch { toast.error("Erro ao excluir."); }
        finally { setLoading(null); }
    };

    const handleCreateRoom = async (tripId: string) => {
        const name = prompt("Nome do quarto (ex: Quarto 204):");
        if (!name) return;
        setLoading("room-" + tripId);
        try {
            await createRoom(tripId, { name, type: "DOUBLE" });
            router.refresh();
            toast.success("Quarto criado!");
        } catch { toast.error("Erro ao criar quarto."); }
        finally { setLoading(null); }
    };

    const handleDeleteRoom = async (id: string) => {
        if (!confirm("Excluir este quarto?")) return;
        setLoading("room-del-" + id);
        try {
            await deleteRoom(id);
            router.refresh();
            toast.success("Quarto excluído!");
        } catch { toast.error("Erro ao excluir quarto."); }
        finally { setLoading(null); }
    };

    const handleAssign = async (roomId: string, memberId: string) => {
        try {
            await assignMemberToRoom(roomId, memberId);
            router.refresh();
        } catch { toast.error("Erro ao alocar membro."); }
    };

    const handleRemove = async (roomId: string, memberId: string) => {
        try {
            await removeAssignment(roomId, memberId);
            router.refresh();
        } catch { toast.error("Erro ao remover."); }
    };

    return (
        <div className="space-y-6">
            {/* Botão novo evento */}
            <div className="flex justify-end">
                <Button
                    className="gap-2 bg-secondary text-white hover:bg-secondary/90"
                    onClick={() => setShowNewTrip(!showNewTrip)}
                >
                    <Plus className="h-4 w-4" /> Novo Evento
                </Button>
            </div>

            {/* Form novo evento */}
            {showNewTrip && (
                <Card className="border-secondary/30 bg-secondary/5">
                    <CardContent className="pt-6 space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                                <Label>Nome do Evento *</Label>
                                <Input value={newTrip.eventName} onChange={e => setNewTrip({ ...newTrip, eventName: e.target.value })} placeholder="Ex: Show SP" />
                            </div>
                            <div className="space-y-1">
                                <Label>Cidade *</Label>
                                <Input value={newTrip.city} onChange={e => setNewTrip({ ...newTrip, city: e.target.value })} placeholder="Ex: São Paulo, SP" />
                            </div>
                            <div className="space-y-1">
                                <Label>Data</Label>
                                <Input type="date" value={newTrip.date} onChange={e => setNewTrip({ ...newTrip, date: e.target.value })} />
                            </div>
                            <div className="space-y-1">
                                <Label>Hotel</Label>
                                <Input value={newTrip.hotel} onChange={e => setNewTrip({ ...newTrip, hotel: e.target.value })} placeholder="Ex: Mercure Jardins" />
                            </div>
                        </div>
                        <div className="flex gap-2 justify-end">
                            <Button variant="ghost" onClick={() => setShowNewTrip(false)}>Cancelar</Button>
                            <Button
                                className="bg-secondary text-white"
                                onClick={handleCreateTrip}
                                disabled={loading === "create-trip"}
                            >
                                {loading === "create-trip" ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar Evento"}
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Lista de trips */}
            {trips.length === 0 ? (
                <div className="rounded-3xl bg-white dark:bg-zinc-900 ring-1 ring-zinc-200 dark:ring-zinc-800 p-12 text-center">
                    <div className="inline-flex p-4 rounded-full bg-secondary/10 text-secondary mb-4"><Hotel className="h-8 w-8" /></div>
                    <h3 className="text-lg font-bold text-foreground">Nenhum evento de hospedagem</h3>
                    <p className="mt-2 text-zinc-500">Crie um evento de hospedagem para organizar os quartos da equipe.</p>
                </div>
            ) : (
                <div className="grid gap-6">
                    {trips.map((trip) => (
                        <Card key={trip.id} className="border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950/40">
                            <CardHeader className="border-b border-zinc-100 dark:border-zinc-800/50 pb-4">
                                <div className="flex justify-between items-start">
                                    <div className="space-y-1">
                                        <div className="flex items-center gap-2">
                                            <CardTitle className="text-xl">{trip.eventName}</CardTitle>
                                            <Badge variant="secondary" className="bg-secondary/10 text-secondary border-none uppercase font-bold text-[10px]">
                                                {trip.rooms.length} Quartos
                                            </Badge>
                                        </div>
                                        <CardDescription className="flex items-center gap-4">
                                            <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {trip.city}</span>
                                            {trip.date && <span className="flex items-center gap-1"><CalendarIcon className="h-3.5 w-3.5" /> {trip.date}</span>}
                                            {trip.hotel && <span className="flex items-center gap-1"><Hotel className="h-3.5 w-3.5" /> {trip.hotel}</span>}
                                        </CardDescription>
                                    </div>
                                    <Button
                                        variant="ghost" size="icon"
                                        className="text-red-500 hover:bg-red-500/10"
                                        onClick={() => handleDeleteTrip(trip.id)}
                                        disabled={loading === "delete-" + trip.id}
                                    >
                                        {loading === "delete-" + trip.id
                                            ? <Loader2 className="h-4 w-4 animate-spin" />
                                            : <Trash2 className="h-4 w-4" />}
                                    </Button>
                                </div>
                            </CardHeader>
                            <CardContent className="pt-6">
                                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                                    {trip.rooms.map((room) => {
                                        const assigned = room.assignments.map(a => a.member);
                                        const unassigned = members.filter(m => !assigned.find(a => a.id === m.id));
                                        return (
                                            <div key={room.id} className="group relative flex flex-col gap-4 rounded-xl border border-zinc-200 dark:border-zinc-800 p-4 hover:border-secondary/50 transition-all bg-zinc-50/50 dark:bg-zinc-900/20">
                                                <div className="flex items-center justify-between">
                                                    <div className="flex items-center gap-2">
                                                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary/10 text-secondary">
                                                            <Hotel className="h-4 w-4" />
                                                        </div>
                                                        <span className="font-bold text-sm">{room.name}</span>
                                                    </div>
                                                    <div className="flex items-center gap-1">
                                                        <Badge variant="outline" className="text-[10px] uppercase">{room.type}</Badge>
                                                        <Button variant="ghost" size="icon" className="h-6 w-6 text-red-400 hover:text-red-500" onClick={() => handleDeleteRoom(room.id)}>
                                                            <Trash2 className="h-3 w-3" />
                                                        </Button>
                                                    </div>
                                                </div>

                                                {/* Membros alocados */}
                                                <div className="space-y-1">
                                                    {assigned.map(m => (
                                                        <div key={m.id} className="flex items-center justify-between text-xs bg-white dark:bg-zinc-800 rounded-lg px-2 py-1">
                                                            <span className="font-medium">{m.user?.name || m.name}</span>
                                                            <button onClick={() => handleRemove(room.id, m.id)} className="text-red-400 hover:text-red-500">✕</button>
                                                        </div>
                                                    ))}
                                                </div>

                                                {/* Alocar novo membro */}
                                                {unassigned.length > 0 && (
                                                    <select
                                                        className="w-full rounded-lg border border-dashed border-zinc-300 dark:border-zinc-700 bg-transparent text-xs p-1.5 text-zinc-500"
                                                        onChange={e => { if (e.target.value) handleAssign(room.id, e.target.value); e.target.value = ""; }}
                                                        defaultValue=""
                                                    >
                                                        <option value="">+ Adicionar membro</option>
                                                        {unassigned.map(m => (
                                                            <option key={m.id} value={m.id}>{m.user?.name || m.name}</option>
                                                        ))}
                                                    </select>
                                                )}
                                            </div>
                                        );
                                    })}

                                    <button
                                        onClick={() => handleCreateRoom(trip.id)}
                                        disabled={loading === "room-" + trip.id}
                                        className="flex h-full min-h-[120px] flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-900/40 hover:border-secondary/50 transition-all text-zinc-400 hover:text-secondary group"
                                    >
                                        {loading === "room-" + trip.id
                                            ? <Loader2 className="h-5 w-5 animate-spin" />
                                            : <Plus className="h-5 w-5" />}
                                        <span className="text-xs font-bold uppercase tracking-wider">Novo Quarto</span>
                                    </button>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    )
}
