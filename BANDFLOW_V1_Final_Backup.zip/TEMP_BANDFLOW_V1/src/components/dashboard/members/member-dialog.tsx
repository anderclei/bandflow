"use client"

import { useState, useRef, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createMember, updateMember } from "@/app/actions/members"
import { MemberDocumentsTab } from "./member-documents-tab"

interface MemberDialogProps {
    open: boolean
    onOpenChange: (open: boolean) => void
    member?: any
    formats: any[]
    onSuccess?: () => void
}

export function MemberDialog({ open, onOpenChange, member, formats, onSuccess }: MemberDialogProps) {
    const isEdit = !!member
    const [isPending, setIsPending] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const formRef = useRef<HTMLFormElement>(null)

    const [selectedFormats, setSelectedFormats] = useState<string[]>([])
    const [role, setRole] = useState<"ADMIN" | "MEMBER">(member?.role || "MEMBER")

    useEffect(() => {
        if (open) {
            setError(null)
            setIsPending(false)
            setRole(member?.role || "MEMBER")
            if (member?.formats) {
                setSelectedFormats(member.formats.map((f: any) => f.id))
            } else {
                setSelectedFormats([])
            }
        }
    }, [open, member])

    function toggleFormat(formatId: string) {
        setSelectedFormats(prev =>
            prev.includes(formatId)
                ? prev.filter(id => id !== formatId)
                : [...prev, formatId]
        )
    }

    async function handleSubmit(formData: FormData) {
        setIsPending(true)
        setError(null)
        formData.append("role", role)

        const result = isEdit
            ? await updateMember(member.id, formData, selectedFormats)
            : await createMember(formData, selectedFormats)

        if (result.success) {
            onSuccess?.()
            onOpenChange(false)
        } else {
            setError(result.error as string)
        }
        setIsPending(false)
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-[700px] w-[95vw] max-h-[90vh] overflow-y-auto outline-none">
                <DialogHeader>
                    <DialogTitle className="text-secondary">{isEdit ? "Editar Integrante" : "Cadastrar Integrante/Staff"}</DialogTitle>
                    <DialogDescription className="text-zinc-500">
                        Insira as informações gerais e logísticas da equipe.
                    </DialogDescription>
                </DialogHeader>

                {error && (
                    <div className="p-3 text-sm text-red-500 bg-red-100 dark:bg-red-500/10 rounded-xl mt-4">
                        {error}
                    </div>
                )}

                <form ref={formRef} action={handleSubmit} className="space-y-6 mt-4">
                    {/* VISÃO GERAL */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2 md:col-span-2">
                            <Label className="text-zinc-700 dark:text-zinc-300">Nome Completo *</Label>
                            <Input name="name" required defaultValue={member?.name || member?.user?.name || ""} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                        </div>

                        <div className="space-y-2">
                            <Label className="text-zinc-700 dark:text-zinc-300">Cargo / Função *</Label>
                            <Input name="position" required defaultValue={member?.position} placeholder="Ex: Baterista, Técnico de Som" className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                        </div>

                        <div className="space-y-2">
                            <Label className="text-zinc-700 dark:text-zinc-300">Nível de Acesso (Login)</Label>
                            <Select value={role} onValueChange={(v: any) => setRole(v)}>
                                <SelectTrigger className="w-full bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800">
                                    <SelectValue placeholder="Selecione um papel" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="MEMBER">Integrante (Leitura)</SelectItem>
                                    <SelectItem value="ADMIN">Administrador (Total)</SelectItem>
                                    <SelectItem value="PRODUCER">Produtor</SelectItem>
                                    <SelectItem value="FINANCIAL">Financeiro</SelectItem>
                                    <SelectItem value="ROADIE">Roadie / Técnico</SelectItem>
                                    <SelectItem value="MUSICIAN">Músico</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label className="text-zinc-700 dark:text-zinc-300">WhatsApp</Label>
                            <Input name="whatsapp" defaultValue={member?.whatsapp} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                        </div>

                        <div className="space-y-2">
                            <Label className="text-zinc-700 dark:text-zinc-300">Cachê Fixo Base (R$)</Label>
                            <Input name="cache" type="number" step="0.01" defaultValue={member?.cache || ""} placeholder="Ex: 500.00" className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                        </div>

                        <div className="space-y-2">
                            <Label className="text-zinc-700 dark:text-zinc-300">C.P.F.</Label>
                            <Input name="cpf" defaultValue={member?.cpf} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                        </div>

                        <div className="space-y-2">
                            <Label className="text-zinc-700 dark:text-zinc-300">R.G.</Label>
                            <Input name="rg" defaultValue={member?.rg} className="bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800" />
                        </div>
                    </div>

                    {/* SHOW FORMATS */}
                    <div className="space-y-4 pt-4 border-t border-zinc-200 dark:border-zinc-800">
                        <div className="text-sm font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                            Formatos de Show Participantes
                        </div>
                        {formats.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                {formats.map((format: any) => (
                                    <div key={format.id} className="flex flex-row items-start space-x-3 space-y-0 p-3 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 cursor-pointer" onClick={() => toggleFormat(format.id)}>
                                        <Checkbox
                                            id={`format-${format.id}`}
                                            checked={selectedFormats.includes(format.id)}
                                            onCheckedChange={() => toggleFormat(format.id)}
                                            className="mt-1"
                                        />
                                        <div className="space-y-1 leading-none">
                                            <Label htmlFor={`format-${format.id}`} className="cursor-pointer font-medium text-foreground">
                                                {format.name}
                                            </Label>
                                            {format.description && (
                                                <p className="text-xs text-zinc-500 line-clamp-1">{format.description}</p>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-zinc-500">Nenhum formato de show cadastrado na agenda ainda.</p>
                        )}
                    </div>

                    <div className="flex justify-end gap-2 pt-6 border-t border-zinc-200 dark:border-zinc-800 mt-6 md:col-span-2">
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancelar</Button>
                        <Button type="submit" disabled={isPending} className="bg-secondary text-white hover:opacity-90 transition-opacity">
                            {isPending ? "Salvando..." : (isEdit ? "Atualizar Integrante" : "Cadastrar Integrante")}
                        </Button>
                    </div>
                </form>

                {isEdit && (
                    <div className="space-y-4 pt-8 mt-4 border-t border-zinc-200 dark:border-zinc-800">
                        <div className="text-sm font-semibold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                            Documentos Pessoais & Contratos
                        </div>
                        <MemberDocumentsTab
                            memberId={member.id}
                            bandId={member.bandId}
                            initialDocuments={member.documents || []}
                        />
                    </div>
                )}
            </DialogContent>
        </Dialog>
    )
}
