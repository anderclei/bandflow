"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export interface ActivityItem {
    id: string
    user: string
    avatar?: string
    action: string
    target: string
    date: string
}

interface RecentActivityFeedProps {
    data: ActivityItem[]
}

export function RecentActivityFeed({ data }: RecentActivityFeedProps) {
    if (data.length === 0) {
        return (
            <p className="text-xs text-zinc-400 italic py-4 text-center">Nenhuma atividade recente encontrada.</p>
        );
    }

    return (
        <div className="space-y-5">
            {data.map((item) => (
                <div key={item.id} className="flex items-start">
                    <Avatar className="h-9 w-9 border border-zinc-200 dark:border-zinc-800">
                        <AvatarImage src={item.avatar} alt={item.user} />
                        <AvatarFallback className="bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 font-bold text-xs">{item.user.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="ml-4 space-y-1 flex-1">
                        <p className="text-sm font-medium leading-none text-foreground">
                            {item.user} <span className="text-zinc-500 font-normal">{item.action}</span> <span className="text-red-500 font-semibold">{item.target}</span>
                        </p>
                        <p className="text-[10px] text-zinc-400 font-medium">
                            {item.date}
                        </p>
                    </div>
                </div>
            ))}
        </div>
    )
}
