"use client"

import { useState } from "react"
import {
    DndContext,
    DragEndEvent,
    DragOverlay,
    closestCenter,
    PointerSensor,
    useSensor,
    useSensors,
} from "@dnd-kit/core"
import {
    arrayMove,
    SortableContext,
    useSortable,
    verticalListSortingStrategy,
} from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { GripVertical, Plus, Trash2, Save, Clock } from "lucide-react"

type Song = {
    id: string
    title: string
    artist: string | null
    key: string | null
    bpm: number | null
    duration: number | null
}

interface SetlistBuilderProps {
    songs: Song[]
}

export function SetlistBuilder({ songs }: SetlistBuilderProps) {
    const [setlistSongs, setSetlistSongs] = useState<Song[]>([])
    const sensors = useSensors(useSensor(PointerSensor))

    const formatDuration = (seconds: number | null) => {
        if (!seconds) return "0:00";
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, "0")}`;
    };
    function SortableSongItem({ song, onDelete }: { song: Song, onDelete: (id: string) => void }) {
        const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: song.id })
        const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 }

        return (
            <div ref={setNodeRef} style={style} className="flex items-center gap-3 p-3 bg-white dark:bg-zinc-950/40 border border-zinc-100 dark:border-zinc-800 rounded-xl mb-2 shadow-sm group hover:border-secondary/30 transition-all">
                <div {...attributes} {...listeners} className="cursor-grab text-muted-foreground hover:text-secondary transition-colors">
                    <GripVertical className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm tracking-tight truncate">{song.title}</div>
                    <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest truncate">
                        {song.key} • {song.bpm} BPM
                    </div>
                </div>
                <div className="text-xs font-mono font-bold text-muted-foreground">
                    {typeof song.duration === 'number' ? `${Math.floor(song.duration / 60)}:${(song.duration % 60).toString().padStart(2, "0")}` : song.duration}
                </div>
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDelete(song.id)}
                    className="h-8 w-8 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/10"
                >
                    <Trash2 className="h-4 w-4" />
                </Button>
            </div>
        )
    }

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event
        if (over && active.id !== over.id) {
            setSetlistSongs((items) => {
                const oldIndex = items.findIndex((item) => item.id === active.id)
                const newIndex = items.findIndex((item) => item.id === over.id)
                return arrayMove(items, oldIndex, newIndex)
            })
        }
    }

    const addToSetlist = (song: Song) => {
        if (setlistSongs.find(s => s.id === song.id)) return
        setSetlistSongs([...setlistSongs, song])
    }

    return (
        <div className="grid lg:grid-cols-2 gap-6 h-[650px]">
            <Card className="flex flex-col h-full border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950/40">
                <CardHeader>
                    <CardTitle className="text-lg">Biblioteca de Músicas</CardTitle>
                    <CardDescription>Escolha as músicas para compor o seu show.</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden p-0">
                    <ScrollArea className="h-full px-4">
                        <div className="space-y-1 pb-4">
                            {songs.map(song => (
                                <div key={song.id} className="flex items-center justify-between p-3 text-sm border-b border-zinc-50 dark:border-zinc-800/50 last:border-0 hover:bg-zinc-100/40 dark:hover:bg-zinc-800/40 rounded-lg transition-colors group">
                                    <div className="flex-1 min-w-0">
                                        <div className="font-bold tracking-tight">{song.title}</div>
                                        <div className="text-[10px] text-muted-foreground font-bold uppercase">{song.artist || "---"}</div>
                                    </div>
                                    <Button size="icon" variant="ghost" className="h-8 w-8 hover:text-secondary hover:bg-secondary/10" onClick={() => addToSetlist(song)}>
                                        <Plus className="h-4 w-4" />
                                    </Button>
                                </div>
                            ))}
                        </div>
                    </ScrollArea>
                </CardContent>
            </Card>

            <Card className="flex flex-col h-full border-secondary/20 bg-secondary/5">
                <CardHeader className="pb-3 border-b border-secondary/10">
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle className="text-lg">Ordem do Show (Setlist)</CardTitle>
                            <CardDescription className="text-secondary/70">Arraste para reordenar a sequência.</CardDescription>
                        </div>
                        <Badge variant="outline" className="flex items-center gap-1 font-mono font-bold bg-secondary/10 border-secondary/20 text-secondary">
                            <Clock className="h-3.5 w-3.5" />
                            60m estim.
                        </Badge>
                    </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden p-2">
                    <ScrollArea className="h-full p-2">
                        {setlistSongs.length === 0 ? (
                            <div className="h-[300px] flex flex-col items-center justify-center text-muted-foreground text-sm border-2 border-dashed border-secondary/20 rounded-xl">
                                <Plus className="h-8 w-8 mb-2 opacity-20" />
                                <p>Adicione músicas da biblioteca.</p>
                            </div>
                        ) : (
                            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                <SortableContext items={setlistSongs} strategy={verticalListSortingStrategy}>
                                    {setlistSongs.map(song => (
                                        <SortableSongItem key={song.id} song={song} onDelete={(id) => setSetlistSongs(s => s.filter(x => x.id !== id))} />
                                    ))}
                                </SortableContext>
                            </DndContext>
                        )}
                    </ScrollArea>
                </CardContent>
                <div className="p-4 pt-0">
                    <Button className="w-full gap-2 h-11 font-black italic uppercase tracking-tighter shadow-lg shadow-secondary/20 bg-secondary text-white hover:bg-secondary/90 border-0">
                        <Save className="h-4 w-4" />
                        Finalizar e Salvar Show
                    </Button>
                </div>
            </Card>
        </div>
    )
}
