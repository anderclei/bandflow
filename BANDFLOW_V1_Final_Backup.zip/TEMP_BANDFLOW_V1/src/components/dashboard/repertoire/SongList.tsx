"use client"

import { useEffect, useState } from "react"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { Search, Music2, Clock, Paperclip } from "lucide-react"

export type Song = {
    id: string
    title: string
    artist?: string | null
    key?: string | null
    bpm?: number | null
    duration?: number | null
    status: string
    iswc?: string | null
    workId?: string | null
    fileUrl?: string | null
}

interface SongListProps {
    initialSongs: Song[]
}

export function SongList({ initialSongs }: SongListProps) {
    const [searchTerm, setSearchTerm] = useState("")
    const [songs, setSongs] = useState(initialSongs)

    useEffect(() => {
        setSongs(initialSongs)
    }, [initialSongs])

    const filteredSongs = songs.filter(song =>
        song.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (song.artist?.toLowerCase() || "").includes(searchTerm.toLowerCase())
    )

    const formatDuration = (seconds: number | null) => {
        if (!seconds) return "--:--";
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, "0")}`;
    };

    const getStatusColor = (status: Song['status']) => {
        switch (status) {
            case 'ready': return 'bg-green-500/10 text-green-500 border-green-500/20'
            case 'rehearsing': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
            case 'new': return 'bg-blue-500/10 text-blue-500 border-blue-500/20'
            default: return 'bg-gray-500/10 text-gray-500'
        }
    }

    return (
        <div className="space-y-4">
            <div className="relative max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                    placeholder="Buscar músicas..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 h-9"
                />
            </div>

            <div className="rounded-xl border border-zinc-100 dark:border-zinc-800/50 overflow-hidden">
                <Table>
                    <TableHeader className="bg-zinc-50 dark:bg-zinc-800/50">
                        <TableRow className="hover:bg-transparent">
                            <TableHead className="font-bold text-zinc-500 text-xs uppercase">Música</TableHead>
                            <TableHead className="font-bold text-zinc-500 text-xs uppercase">Artista</TableHead>
                            <TableHead className="text-center font-bold text-zinc-500 text-xs uppercase">Tom</TableHead>
                            <TableHead className="text-center font-bold text-zinc-500 text-xs uppercase">BPM</TableHead>
                            <TableHead className="text-center font-bold text-zinc-500 text-xs uppercase">ECAD</TableHead>
                            <TableHead className="text-right font-bold text-zinc-500 text-xs uppercase">Status</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredSongs.map((song) => (
                            <TableRow key={song.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/20 transition-colors border-zinc-100 dark:border-zinc-800/50">
                                <TableCell>
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-3">
                                            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary/10 text-secondary">
                                                <Music2 className="h-4 w-4" />
                                            </div>
                                            <span className="font-bold text-sm tracking-tight">{song.title}</span>
                                        </div>
                                        {song.fileUrl && (
                                            <a
                                                href={song.fileUrl}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="ml-11 flex items-center gap-1 text-[10px] uppercase font-bold text-secondary hover:underline"
                                            >
                                                <Paperclip className="h-2.5 w-2.5" />
                                                Ver Anexo
                                            </a>
                                        )}
                                    </div>
                                </TableCell>
                                <TableCell className="text-sm text-zinc-500">{song.artist || "---"}</TableCell>
                                <TableCell className="text-center">
                                    {song.key ? (
                                        <span className="inline-flex items-center rounded-lg bg-zinc-100 px-2.5 py-1 text-xs font-bold text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300">
                                            {song.key}
                                        </span>
                                    ) : "---"}
                                </TableCell>
                                <TableCell className="text-center font-mono text-xs text-muted-foreground">{song.bpm || "---"}</TableCell>
                                <TableCell className="text-center">
                                    {(song.iswc || song.workId) ? (
                                        <div className="flex flex-col gap-0.5">
                                            {song.iswc && <span className="text-[9px] font-bold text-secondary">{song.iswc}</span>}
                                            {song.workId && <span className="text-[10px] font-medium text-zinc-400">ID: {song.workId}</span>}
                                        </div>
                                    ) : "---"}
                                </TableCell>
                                <TableCell className="text-right">
                                    <Badge variant="outline" className={cn(
                                        "text-[10px] font-bold uppercase tracking-wider border-none",
                                        song.status === "READY" && "bg-green-500/10 text-green-500 border-green-500/20",
                                        song.status === "IN_PROGRESS" && "bg-amber-500/10 text-amber-500 border-amber-500/20",
                                        song.status === "ARCHIVED" && "bg-zinc-500/10 text-zinc-500 border-zinc-500/20"
                                    )}>
                                        {song.status === 'READY' ? 'Pronto' : song.status === 'IN_PROGRESS' ? 'Ensaiando' : 'Arquivo'}
                                    </Badge>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}
