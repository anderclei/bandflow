"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import {
    LayoutDashboard,
    Calendar,
    FileText,
    Music,
    Map,
    Camera,
    LayoutTemplate,
    Clock,
    Hotel,
    DollarSign,
    Users,
    Package,
    MessageCircle,
    Settings,
    LogOut,
    ChevronLeft,
    PanelLeft,
    AudioLines,
    ChevronRight,
    Plus,
    User,
    Hammer,
    Shield,
    ShoppingBag,
    Briefcase,
    FolderOpen,
    Share2,
    BarChart3,
    Sparkles,
    Globe
} from "lucide-react";
import { signOut } from "next-auth/react";
import { BandSelector } from "./BandSelector";
import { useRoleStore, UserRole } from "@/store/useRoleStore";

interface SidebarProps {
    memberships: any[];
    activeBandId: string;
    activeBand?: any;
    isSuperAdmin?: boolean;
}

const navigationGroups = [
    {
        name: "GESTÃO CORE",
        items: [
            { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
            { name: "Agenda de Shows", href: "/dashboard/gigs", icon: Calendar },
            { name: "Financeiro", href: "/dashboard/finance", icon: DollarSign },
        ]
    },
    {
        name: "SHOW & PALCO",
        items: [
            { name: "Painel do EPK", href: "/dashboard/epk", icon: Globe },
            { name: "Rider Técnico", href: "/dashboard/rider", icon: AudioLines },
            { name: "Repertório", href: "/dashboard/repertoire", icon: Music },
            { name: "Logística", href: "/dashboard/logistics/schedule", icon: Map },
            { name: "Mídia", href: "/dashboard/media", icon: Camera },
        ]
    },
    {
        name: "COMERCIAL & VENDAS",
        items: [
            { name: "Inteligência & IA", href: "/dashboard/intelligence", icon: Sparkles },
            { name: "Contratos", href: "/dashboard/contracts", icon: FileText },
            { name: "Contratantes", href: "/dashboard/contractors", icon: Briefcase },
            { name: "Lojinha", href: "/dashboard/merch", icon: ShoppingBag },
        ]
    },
    {
        name: "EQUIPE & DOCS",
        items: [
            { name: "Equipe", href: "/dashboard/members", icon: Users },
            { name: "Documentação", href: "/dashboard/documents", icon: FolderOpen },
            { name: "Inventário", href: "/dashboard/inventory", icon: Package },
        ]
    }
];

export function Sidebar({ memberships, activeBandId, activeBand, isSuperAdmin = false }: SidebarProps) {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [isMounted, setIsMounted] = useState(false);
    const pathname = usePathname();
    const { currentRole } = useRoleStore();

    useEffect(() => {
        setIsMounted(true);
    }, []);

    let bands = memberships.map((m) => m.band);
    if (isSuperAdmin && activeBand && !bands.find(b => b.id === activeBand.id)) {
        bands = [activeBand, ...bands];
    }

    // Branding colors
    const primaryColor = activeBand?.primaryColor || "#dc2626";
    const secondaryColor = activeBand?.secondaryColor || "#ff0000";

    const filteredGroups = navigationGroups.filter(group => {
        // Para testes e demonstração do BandDemo, vamos liberar a visualização de todos os menus
        // independente do cargo atual, para que o usuário não ache que as funções sumiram.
        return true;
    }).map(group => {
        return { ...group, items: group.items };
    }).filter(group => group.items.length > 0);

    // Prevent hydration mismatch by not rendering the interactive part until mounted
    if (!isMounted) {
        return (
            <aside
                className={cn(
                    "relative flex flex-col border-r border-white/5 transition-all duration-300 ease-in-out",
                    isCollapsed ? "w-[72px]" : "w-64"
                )}
                style={{ backgroundColor: '#333333' }}
            />
        );
    }

    return (
        <aside
            className={cn(
                "relative flex flex-col border-r border-white/5 transition-all duration-300 ease-in-out",
                isCollapsed ? "w-[72px]" : "w-64"
            )}
            style={{ backgroundColor: '#333333' }}
        >
            <div className="flex h-12 items-center border-b border-white/5 px-6">
                <div className="flex-1 flex items-center justify-center -ml-1">
                    {!isCollapsed && (
                        isSuperAdmin ? (
                            <Link href="/super-admin" className="hover:opacity-80 transition-opacity">
                                <span className="text-[2.2rem] font-black tracking-tighter leading-none select-none">
                                    <span className="text-white">Band</span>
                                    <span style={{ color: secondaryColor }}>Flow</span>
                                </span>
                            </Link>
                        ) : (
                            <span className="text-[2.2rem] font-black tracking-tighter leading-none select-none">
                                <span className="text-white">Band</span>
                                <span style={{ color: secondaryColor }}>Flow</span>
                            </span>
                        )
                    )}
                </div>
                {!isCollapsed && (
                    <button
                        onClick={() => setIsCollapsed(true)}
                        className="ml-auto rounded-lg p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white"
                    >
                        <ChevronLeft className="h-5 w-5" />
                    </button>
                )}
            </div>

            {isCollapsed && (
                <div className="flex h-12 items-center justify-center">
                    <button
                        onClick={() => setIsCollapsed(false)}
                        className="rounded-lg p-1 text-zinc-500 hover:bg-zinc-800 hover:text-white"
                    >
                        <ChevronRight className="h-5 w-5" />
                    </button>
                </div>
            )}

            {(bands.length > 0 || isSuperAdmin) && (
                <>
                    <div className={cn("px-2 my-2 transition-all", isCollapsed && "px-1")}>
                        <BandSelector
                            bands={bands}
                            activeBandId={activeBandId}
                            isCollapsed={isCollapsed}
                            primaryColor={primaryColor}
                            secondaryColor={activeBand?.secondaryColor}
                        />
                    </div>

                    <nav className="flex-1 space-y-0.5 overflow-y-auto overflow-x-hidden p-2 scrollbar-hide">
                        {filteredGroups.map((group) => (
                            <div key={group.name} className="space-y-0.5">
                                {!isCollapsed && (
                                    <div
                                        className="px-2 pb-0.5 pt-2 text-[10px] font-bold uppercase tracking-[0.2em] text-white/40"
                                    >
                                        {group.name}
                                    </div>
                                )}
                                <div className="space-y-0.5">
                                    {group.items.map((item) => {
                                        const isActive = pathname === item.href;
                                        const Icon = item.icon;
                                        return (
                                            <Link
                                                key={item.name}
                                                href={item.href}
                                                className={cn(
                                                    "group flex items-center rounded-lg px-2 py-1 text-sm font-medium transition-all",
                                                    isActive
                                                        ? "bg-white/20 text-white shadow-sm"
                                                        : "text-zinc-400 hover:bg-white/10 hover:text-white",
                                                    isCollapsed && "justify-center px-0 py-1.5 w-10 mx-auto"
                                                )}
                                                title={isCollapsed ? item.name : ""}
                                            >
                                                <Icon
                                                    className={cn(
                                                        "h-4 w-4 transition-transform group-hover:scale-110 mr-2.5",
                                                        isCollapsed && "mr-0"
                                                    )}
                                                    style={{ color: secondaryColor }}
                                                />
                                                {!isCollapsed && <span>{item.name}</span>}
                                            </Link>
                                        );
                                    })}
                                </div>
                            </div>
                        ))}
                    </nav>
                </>
            )}

            <div className={cn("border-t border-white/5 p-2 space-y-1", isCollapsed && "p-2")}>
                <a
                    href="https://wa.me/550000000000"
                    target="_blank"
                    rel="noopener noreferrer"
                    title={isCollapsed ? "Ajuda no WhatsApp" : ""}
                    className={cn(
                        "group flex w-full items-center rounded-lg px-3 py-1.5 text-sm font-medium transition-all hover:bg-white/5",
                        isCollapsed && "justify-center px-0"
                    )}
                    style={{ color: secondaryColor }}
                >
                    <MessageCircle className={cn("h-4 w-4", !isCollapsed && "mr-3")} />
                    {!isCollapsed && <span>WhatsApp</span>}
                </a>

                <Link
                    href="/dashboard/settings"
                    title={isCollapsed ? "Configurações" : ""}
                    className={cn(
                        "group flex w-full items-center rounded-lg px-3 py-1.5 text-sm font-medium text-zinc-400 hover:bg-white/5 hover:text-white transition-all",
                        isCollapsed && "justify-center px-0"
                    )}
                >
                    <Settings className={cn("h-4 w-4", !isCollapsed && "mr-3")} />
                    {!isCollapsed && <span>Configurações</span>}
                </Link>
                <button
                    onClick={() => signOut({ callbackUrl: "/login" })}
                    title={isCollapsed ? "Sair" : ""}
                    className={cn(
                        "group flex w-full items-center rounded-lg px-3 py-1.5 text-sm font-medium text-zinc-500 hover:bg-red-500/10 hover:text-red-400 transition-all",
                        isCollapsed && "justify-center px-0"
                    )}
                >
                    <LogOut className={cn("h-4 w-4", !isCollapsed && "mr-3")} />
                    {!isCollapsed && <span>Sair</span>}
                </button>
            </div>
        </aside>
    );
}
