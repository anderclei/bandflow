"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LucideIcon } from "lucide-react"

interface DashboardStatCardProps {
    title: string
    value: string
    description: string
    icon: React.ReactNode
    trend?: "up" | "down" | "neutral"
    trendValue?: string
}

export function DashboardStatCard({ title, value, description, icon: Icon, trend, trendValue }: DashboardStatCardProps) {
    return (
        <Card className="hover:shadow-md transition-shadow rounded-3xl bg-white ring-1 ring-zinc-200 border-0 shadow-sm dark:bg-zinc-900 dark:ring-zinc-800">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-zinc-500 dark:text-zinc-400">
                    {title}
                </CardTitle>
                {typeof Icon === 'string' ? (
                    <span className="text-xl">{Icon}</span>
                ) : (
                    <div className="p-2 rounded-xl bg-secondary/10 text-secondary">
                        {Icon}
                    </div>
                )}
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold text-foreground">{value}</div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 flex items-center gap-1">
                    {trend === "up" && <span className="text-secondary font-bold">↑ {trendValue}</span>}
                    {trend === "down" && <span className="text-red-500 dark:text-red-400 font-bold">↓ {trendValue}</span>}
                    {description}
                </p>
            </CardContent>
        </Card>
    )
}
