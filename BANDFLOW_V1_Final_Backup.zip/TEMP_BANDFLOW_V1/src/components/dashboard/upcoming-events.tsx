"use client"

import { MapPin } from "lucide-react"

export interface UpcomingEvent {
    id: string
    title: string
    date: string // DD/MMM like "25/ABR"
    location: string
    status: "confirmed" | "pending"
}

interface UpcomingEventsListProps {
    data: UpcomingEvent[]
}

export function UpcomingEventsList({ data }: UpcomingEventsListProps) {
    if (data.length === 0) {
        return (
            <div className="py-8 text-center">
                <p className="text-sm text-zinc-500">Nenhum evento próximo.</p>
            </div>
        );
    }

    return (
        <div className="space-y-3">
            {data.map((event) => (
                <div key={event.id} className="flex items-center justify-between p-3 rounded-2xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-900/50 hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors">
                    <div className="flex items-center gap-3">
                        <div className="flex flex-col items-center justify-center p-2 rounded-xl bg-secondary/10 text-secondary min-w-[50px] min-h-[50px]">
                            <span className="text-[10px] uppercase font-bold">{event.date.split('/')[1]}</span>
                            <span className="text-sm font-bold leading-none">{event.date.split('/')[0]}</span>
                        </div>
                        <div className="min-w-0">
                            <h4 className="font-semibold text-sm text-foreground truncate">{event.title}</h4>
                            <div className="flex items-center text-[10px] text-zinc-500 mt-1 truncate">
                                <MapPin className="mr-1 h-3 w-3 shrink-0" />
                                <span className="truncate">{event.location}</span>
                            </div>
                        </div>
                    </div>
                    <div className="ml-2 shrink-0 flex items-center">
                        <div className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded-full ${event.status === 'confirmed'
                            ? 'bg-secondary/10 text-secondary'
                            : 'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-400'
                            }`}>
                            {event.status === 'confirmed' ? 'Confirmado' : 'Pendente'}
                        </div>
                    </div>
                </div>
            ))}
        </div>
    )
}
