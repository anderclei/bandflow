"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { KeyRound } from "lucide-react";
import { updateSuperAdminPassword } from "@/app/actions/super-admin";

export function ChangePasswordForm() {
    const [saving, setSaving] = useState(false);
    const [formData, setFormData] = useState({
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSave = async () => {
        if (formData.newPassword !== formData.confirmPassword) {
            toast.error("A nova senha e a confirmação não coincidem.");
            return;
        }

        if (formData.newPassword.length < 6) {
            toast.error("A nova senha deve ter pelo menos 6 caracteres.");
            return;
        }

        setSaving(true);
        try {
            const result = await updateSuperAdminPassword(formData.currentPassword, formData.newPassword);
            if (result.success) {
                toast.success("Senha alterada com sucesso!");
                setFormData({ currentPassword: "", newPassword: "", confirmPassword: "" });
            } else {
                toast.error(result.error);
            }
        } catch (error) {
            toast.error("Ocorreu um erro ao alterar a senha.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="bg-white dark:bg-zinc-900/50 rounded-xl border border-zinc-200 dark:border-white/5 overflow-hidden mt-6">
            <div className="p-6 md:p-8 space-y-6">
                <div>
                    <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-1">Alterar Senha do Super Admin</h2>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Atualize sua credencial de acesso.</p>
                </div>

                <div className="space-y-4 max-w-xl">
                    <div className="space-y-2">
                        <Label htmlFor="currentPassword">Senha Atual</Label>
                        <Input
                            id="currentPassword"
                            name="currentPassword"
                            type="password"
                            value={formData.currentPassword}
                            onChange={handleChange}
                            placeholder="*************"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="newPassword">Nova Senha</Label>
                        <Input
                            id="newPassword"
                            name="newPassword"
                            type="password"
                            value={formData.newPassword}
                            onChange={handleChange}
                            placeholder="*************"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                        <Input
                            id="confirmPassword"
                            name="confirmPassword"
                            type="password"
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            placeholder="*************"
                        />
                    </div>
                </div>

                <div className="pt-6">
                    <Button
                        onClick={handleSave}
                        disabled={saving || !formData.currentPassword || !formData.newPassword || !formData.confirmPassword}
                        className="bg-zinc-900 hover:bg-zinc-800 text-white min-w-[150px]"
                    >
                        <KeyRound className="h-4 w-4 mr-2" />
                        {saving ? "Alterando..." : "Alterar Senha"}
                    </Button>
                </div>
            </div>
        </div>
    );
}
