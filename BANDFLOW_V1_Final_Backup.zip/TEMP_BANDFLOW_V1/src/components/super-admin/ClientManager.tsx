"use client";

import { useState } from "react";
import { updateUserLicense } from "@/app/actions/super-admin";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ShieldAlert, ShieldCheck, Save, Search } from "lucide-react";

export function ClientManager({ initialUsers }: { initialUsers: any[] }) {
    const [search, setSearch] = useState("");
    const [users, setUsers] = useState(initialUsers);
    const [saving, setSaving] = useState<Record<string, boolean>>({});

    const handleSave = async (userId: string, data: any) => {
        setSaving(prev => ({ ...prev, [userId]: true }));
        try {
            const result = await updateUserLicense(userId, data);
            if (result.success) {
                toast.success("Licença atualizada com sucesso!");
                setUsers(users.map(u => u.id === userId ? { ...u, ...data } : u));
            } else {
                toast.error(result.error);
            }
        } catch (e) {
            toast.error("Erro inesperado ao salvar");
        } finally {
            setSaving(prev => ({ ...prev, [userId]: false }));
        }
    };

    const filteredUsers = users.filter(u =>
        u.name?.toLowerCase().includes(search.toLowerCase()) ||
        u.email?.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 justify-between">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-white">Clientes & Licenças</h1>
                    <p className="text-zinc-500 dark:text-zinc-400">Gerencie assinaturas e limites de bandas por usuário.</p>
                </div>
                <div className="relative md:w-72">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
                    <Input
                        placeholder="Buscar por nome ou e-mail..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="pl-9 bg-white dark:bg-zinc-900 border-zinc-200 dark:border-white/10"
                    />
                </div>
            </div>

            <div className="bg-white dark:bg-zinc-900/50 rounded-xl border border-zinc-200 dark:border-white/5 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs uppercase bg-zinc-50 dark:bg-zinc-950/50 text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-white/5">
                            <tr>
                                <th className="px-6 py-4 font-semibold">Usuário</th>
                                <th className="px-6 py-4 font-semibold text-center">Permissão</th>
                                <th className="px-6 py-4 font-semibold text-center">Status (Licença)</th>
                                <th className="px-6 py-4 font-semibold text-center">Máx Bandas</th>
                                <th className="px-6 py-4 font-semibold text-right">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredUsers.map(user => (
                                <tr key={user.id} className="border-b border-zinc-200 dark:border-white/5 hover:bg-zinc-50 dark:hover:bg-white/5 transition-colors">
                                    <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                            <div className="h-8 w-8 rounded-full bg-zinc-200 dark:bg-zinc-800 flex items-center justify-center overflow-hidden">
                                                {user.image ? (
                                                    <img src={user.image} alt={user.name} className="h-full w-full object-cover" />
                                                ) : (
                                                    <span className="font-bold text-zinc-500">{user.name?.charAt(0) || "U"}</span>
                                                )}
                                            </div>
                                            <div>
                                                <div className="font-semibold text-zinc-900 dark:text-white">{user.name}</div>
                                                <div className="text-xs text-zinc-500">{user.email}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-center">
                                        <div className="flex items-center justify-center gap-2">
                                            <Switch
                                                checked={user.isSuperAdmin}
                                                onCheckedChange={(val) => setUsers(users.map(u => u.id === user.id ? { ...u, isSuperAdmin: val } : u))}
                                            />
                                            <Label className="text-xs font-semibold">Super Admin</Label>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex justify-center">
                                            <Select
                                                value={user.licenseStatus}
                                                onValueChange={(val) => setUsers(users.map(u => u.id === user.id ? { ...u, licenseStatus: val } : u))}
                                            >
                                                <SelectTrigger className="w-[130px] h-8 text-xs bg-white dark:bg-black/40">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="ACTIVE" className="text-red-600 dark:text-red-400 font-semibold">Ativo</SelectItem>
                                                    <SelectItem value="TRIAL" className="text-blue-600 dark:text-blue-400 font-semibold">Teste (Trial)</SelectItem>
                                                    <SelectItem value="BLOCKED" className="text-red-600 dark:text-red-400 font-semibold">Bloqueado</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex justify-center">
                                            <Input
                                                type="number"
                                                min={1}
                                                value={user.maxBands}
                                                onChange={(e) => setUsers(users.map(u => u.id === user.id ? { ...u, maxBands: parseInt(e.target.value) || 1 } : u))}
                                                className="w-20 h-8 text-center bg-white dark:bg-black/40"
                                            />
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <Button
                                            size="sm"
                                            disabled={saving[user.id]}
                                            onClick={() => handleSave(user.id, {
                                                licenseStatus: user.licenseStatus,
                                                maxBands: user.maxBands,
                                                isSuperAdmin: user.isSuperAdmin
                                            })}
                                            className="bg-zinc-900 hover:bg-zinc-800 text-white dark:bg-white dark:hover:bg-zinc-200 dark:text-zinc-900 gap-2 h-8"
                                        >
                                            <Save className="h-3 w-3" />
                                            {saving[user.id] ? "Salvando..." : "Salvar"}
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                            {filteredUsers.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="px-6 py-8 text-center text-zinc-500">
                                        Nenhum usuário encontrado.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
