"use client";

import { useState } from "react";
import { updateSystemSettings } from "@/app/actions/super-admin";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";

export function SettingsForm({ initialSettings }: { initialSettings: any }) {
    const [saving, setSaving] = useState(false);
    const [formData, setFormData] = useState({
        appName: initialSettings?.appName || "BandFlow",
        logoUrl: initialSettings?.logoUrl || "",
        primaryColor: initialSettings?.primaryColor || "",
        adminEmail: initialSettings?.adminEmail || "",
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSave = async () => {
        setSaving(true);
        try {
            const result = await updateSystemSettings(formData);
            if (result.success) {
                toast.success("Configurações salvas com sucesso!");
            } else {
                toast.error(result.error);
            }
        } catch (error) {
            toast.error("Ocorreu um erro ao salvar as configurações.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <div className="bg-white dark:bg-zinc-900/50 rounded-xl border border-zinc-200 dark:border-white/5 overflow-hidden">
            <div className="p-6 md:p-8 space-y-6">
                <div>
                    <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-1">Identidade e Marca</h2>
                    <p className="text-sm text-zinc-500 dark:text-zinc-400">Configure como o sistema aparecerá globalmente.</p>
                </div>

                <div className="space-y-4 max-w-xl">
                    <div className="space-y-2">
                        <Label htmlFor="appName">Nome da Aplicação</Label>
                        <Input
                            id="appName"
                            name="appName"
                            value={formData.appName}
                            onChange={handleChange}
                            placeholder="Ex: BandFlow Pro"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="logoUrl">URL da Logo Principal (Opcional)</Label>
                        <Input
                            id="logoUrl"
                            name="logoUrl"
                            value={formData.logoUrl}
                            onChange={handleChange}
                            placeholder="https://..."
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="primaryColor">Cor Primária (Hexadecimal - Opcional)</Label>
                        <div className="flex gap-2">
                            <Input
                                type="color"
                                id="colorPicker"
                                value={formData.primaryColor || "#dc2626"}
                                onChange={(e) => setFormData(old => ({ ...old, primaryColor: e.target.value }))}
                                className="w-12 h-10 p-1 cursor-pointer"
                            />
                            <Input
                                id="primaryColor"
                                name="primaryColor"
                                value={formData.primaryColor}
                                onChange={handleChange}
                                placeholder="Ex: #dc2626"
                                className="flex-1"
                            />
                        </div>
                    </div>
                </div>

                <div className="pt-6 border-t border-zinc-200 dark:border-white/5 space-y-6">
                    <div>
                        <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-1">Contato do Sistema</h2>
                        <p className="text-sm text-zinc-500 dark:text-zinc-400">E-mail global de contato do administrador do SaaS.</p>
                    </div>

                    <div className="space-y-4 max-w-xl">
                        <div className="space-y-2">
                            <Label htmlFor="adminEmail">E-mail Administrativo Oficial</Label>
                            <Input
                                type="email"
                                id="adminEmail"
                                name="adminEmail"
                                value={formData.adminEmail}
                                onChange={handleChange}
                                placeholder="contato@bandflow.com"
                            />
                        </div>
                    </div>
                </div>

                <div className="pt-6">
                    <Button
                        onClick={handleSave}
                        disabled={saving}
                        className="bg-red-600 hover:bg-red-700 text-white min-w-[150px] shadow-lg shadow-red-600/20"
                    >
                        <Save className="h-4 w-4 mr-2" />
                        {saving ? "Salvando..." : "Salvar Configurações"}
                    </Button>
                </div>
            </div>
        </div>
    );
}
