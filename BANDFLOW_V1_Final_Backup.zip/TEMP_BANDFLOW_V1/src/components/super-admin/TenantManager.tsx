"use client";

import { useState, useRef } from "react";
import { toast } from "sonner";
import { Plus, Search, Users, Globe, Trash2, Edit, Building2, Music, ImagePlus, X, RotateCcw } from "lucide-react";
import { createTenant, updateTenant, deleteTenant, impersonateTenant, resetBandData } from "@/app/actions/super-admin";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export function TenantManager({ initialBands }: { initialBands: any[] }) {
    const [bands, setBands] = useState(initialBands);
    const [searchQuery, setSearchQuery] = useState("");
    const [isCreating, setIsCreating] = useState(false);
    const [editingBand, setEditingBand] = useState<any | null>(null);
    const [saving, setSaving] = useState(false);
    const [tenantType, setTenantType] = useState<"BANDA" | "OFFICE">("BANDA");
    const logoInputRef = useRef<HTMLInputElement>(null);
    const firstBandLogoInputRef = useRef<HTMLInputElement>(null);

    // Generator function for slug based on name
    const generateSlug = (name: string) => {
        return name
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "") // Remove accents
            .replace(/[^\w\s-]/g, "") // Remove special characters
            .replace(/\s+/g, "-") // Replace spaces with hyphens
            .replace(/-+/g, "-") // Remove consecutive hyphens
            .trim();
    };

    const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>, field: "logoUrl" | "firstBandLogo") => {
        const file = e.target.files?.[0];
        if (!file) return;
        if (file.size > 2 * 1024 * 1024) {
            toast.error("A imagem deve ter menos de 2MB.");
            return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
            setFormData(prev => ({ ...prev, [field]: ev.target?.result as string }));
        };
        reader.readAsDataURL(file);
    };

    const defaultFormData = {
        name: "",
        slug: "",
        logoUrl: "",
        primaryColor: "#333333",
        secondaryColor: "#dc2626",

        // Responsável
        respName: "",
        respDocument: "",
        respPhone: "",
        respEmail: "",
        addressStreet: "",
        addressNumber: "",
        addressNeighborhood: "",
        addressZipCode: "",
        addressCity: "",
        addressState: "",

        // Office Only - these fields are not directly used in the form, but kept for context
        contactEmail: "",
        contactPhone: "",
        address: "",
        city: "",

        adminEmail: "",
        firstBandName: "",
        firstBandLogo: "",
    };

    const [formData, setFormData] = useState(defaultFormData);

    const filteredBands = bands.filter(b =>
        b.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.slug.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => {
            const newData = { ...prev, [name]: value };
            // Auto-generate slug when name changes for new tenants
            if (name === "name" && !editingBand) {
                newData.slug = generateSlug(value);
            }
            return newData;
        });
    };

    const handleCreate = async () => {
        setSaving(true);
        try {
            const result = await createTenant({
                ...formData,
                type: tenantType,
                // Default password logic is now handled in the backend action
            });
            if (result.success) {
                toast.success(`${tenantType === "OFFICE" ? "Escritório" : "Banda"} Criada com sucesso!`);
                window.location.reload();
            } else {
                toast.error(result.error);
            }
        } catch (error) {
            toast.error("Ocorreu um erro na solicitação.");
        } finally {
            setSaving(false);
        }
    };

    const handleUpdate = async () => {
        if (!editingBand) return;
        setSaving(true);
        try {
            const result = await updateTenant(editingBand.id, {
                name: formData.name,
                slug: formData.slug,
                logoUrl: formData.logoUrl,
                secondaryColor: formData.secondaryColor,
                respName: formData.respName,
                respDocument: formData.respDocument,
                respPhone: formData.respPhone,
                respEmail: formData.respEmail,
                addressStreet: formData.addressStreet,
                addressNumber: formData.addressNumber,
                addressNeighborhood: formData.addressNeighborhood,
                addressZipCode: formData.addressZipCode,
                addressCity: formData.addressCity,
                addressState: formData.addressState,

            });
            if (result.success) {
                toast.success("Conta atualizada com sucesso!");
                window.location.reload();
            } else {
                toast.error(result.error);
            }
        } catch (error) {
            toast.error("Ocorreu um erro ao atualizar.");
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async (id: string, name: string) => {
        if (confirm(`Tem certeza que deseja excluir a conta ${name}? Essa ação apagará a banda e membros associados (o usuário administrador permanecerá ativo no sistema sem banda).`)) {
            try {
                const result = await deleteTenant(id);
                if (result.success) {
                    toast.success("Conta excluída.");
                    window.location.reload();
                } else {
                    toast.error(result.error);
                }
            } catch (error) {
                toast.error("Erro ao excluir.");
            }
        }
    };

    const handleReset = async (id: string, name: string) => {
        if (confirm(`ATENÇÃO: Deseja realmente RESETAR todos os dados da banda ${name}? \n\nIsso apagará permanentemente:\n- Todos os Shows e Setlists\n- Todo o Repertório de Músicas\n- Todos os Documentos e Gastos\n- Equipamentos e Vendas de Merch\n\nPortanto, a conta ficará vazia, mas os MEMBROS continuarão tendo acesso.`)) {
            setSaving(true);
            try {
                const result = await resetBandData(id);
                if (result.success) {
                    toast.success("Dados resetados com sucesso!");
                    window.location.reload();
                } else {
                    toast.error(result.error);
                }
            } catch (error) {
                toast.error("Erro ao resetar dados.");
            } finally {
                setSaving(false);
            }
        }
    };

    const openEdit = (band: any) => {
        setEditingBand(band);
        setTenantType(band.type || "BANDA");
        setFormData({
            ...defaultFormData,
            name: band.name,
            slug: band.slug,
            logoUrl: band.imageUrl || "",
            primaryColor: "#333333",
            secondaryColor: band.secondaryColor || "#dc2626",
            respName: band.respName || "",
            respDocument: band.respDocument || "",
            respPhone: band.respPhone || "",
            respEmail: band.respEmail || "",
            addressStreet: band.addressStreet || "",
            addressNumber: band.addressNumber || "",
            addressNeighborhood: band.addressNeighborhood || "",
            addressZipCode: band.addressZipCode || "",
            addressCity: band.addressCity || "",
            addressState: band.addressState || "",

        });
        setIsCreating(true);
    };

    const closeForm = () => {
        setIsCreating(false);
        setEditingBand(null);
        setTenantType("BANDA");
        setFormData(defaultFormData);
    };

    return (
        <div className="space-y-6">
            {!isCreating && (
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-between bg-white dark:bg-zinc-900/50 p-4 rounded-xl border border-zinc-200 dark:border-white/5">
                    <div className="relative w-full sm:w-96">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
                        <Input
                            placeholder="Buscar por nome ou slug..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="pl-9 bg-zinc-50 dark:bg-black/20"
                        />
                    </div>
                    <Button onClick={() => setIsCreating(true)} className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white shadow-lg shadow-red-600/20">
                        <Plus className="h-4 w-4 mr-2" />
                        Nova Conta/Escritório
                    </Button>
                </div>
            )}

            {isCreating && (
                <div className="bg-white dark:bg-zinc-900/50 rounded-xl border border-zinc-200 dark:border-white/5 overflow-hidden">
                    <div className="p-6 md:p-8 space-y-6">
                        <div className="flex justify-between items-center">
                            <div>
                                <h2 className="text-xl font-bold text-zinc-900 dark:text-white">
                                    {editingBand ? "Editar Instância" : "Nova Instância"}
                                </h2>
                                <p className="text-sm text-zinc-500">
                                    {editingBand ? "Altere as configurações de acesso e visualizações" : "Escolha o tipo de instância e preencha os dados."}
                                </p>
                            </div>
                            <Button variant="ghost" onClick={closeForm}>Cancelar</Button>
                        </div>

                        {!editingBand && (
                            <div className="flex gap-4 border-b border-zinc-200 dark:border-zinc-800 pb-4">
                                <Button
                                    variant={tenantType === "BANDA" ? "default" : "outline"}
                                    className={tenantType === "BANDA" ? "bg-red-600 hover:bg-red-700 shadow-md shadow-red-600/20" : ""}
                                    onClick={() => setTenantType("BANDA")}
                                >
                                    <Music className="w-4 h-4 mr-2" />
                                    Banda Avulsa
                                </Button>
                                <Button
                                    variant={tenantType === "OFFICE" ? "default" : "outline"}
                                    className={tenantType === "OFFICE" ? "bg-red-600 hover:bg-red-700 shadow-md shadow-red-600/20" : ""}
                                    onClick={() => setTenantType("OFFICE")}
                                >
                                    <Building2 className="w-4 h-4 mr-2" />
                                    Escritório
                                </Button>
                            </div>
                        )}

                        <div className="grid md:grid-cols-2 gap-8 pt-4">
                            {/* Coluna Esquerda: Dados Principais */}
                            <div className="space-y-6">
                                <div className="space-y-4">
                                    <h3 className="font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                                        {tenantType === "OFFICE" ? <Building2 className="w-4 h-4 text-red-500" /> : <Music className="w-4 h-4 text-red-500" />}
                                        {tenantType === "OFFICE" ? "Dados do Escritório" : "Dados da Banda"}
                                    </h3>

                                    <div className="space-y-3">
                                        <div className="space-y-1">
                                            <Label>Nome {tenantType === "OFFICE" ? "do Escritório" : "da Banda"}</Label>
                                            <Input name="name" value={formData.name} onChange={handleChange} placeholder="Ex: Nome da Empresa/Banda" />
                                        </div>

                                        <div className="space-y-1">
                                            <Label>Slug (URL) <span className="text-xs text-zinc-500 font-normal ml-2">Gerado Automaticamente</span></Label>
                                            <Input name="slug" value={formData.slug} onChange={handleChange} className="bg-zinc-50 dark:bg-zinc-900" />
                                        </div>

                                        {tenantType === "BANDA" && (
                                            <>
                                                <div className="space-y-1">
                                                    <Label>Logomarca da Banda</Label>
                                                    <input
                                                        type="file"
                                                        accept="image/*"
                                                        ref={logoInputRef}
                                                        onChange={(e) => handleLogoUpload(e, "logoUrl")}
                                                        className="hidden"
                                                    />
                                                    <div
                                                        onClick={() => logoInputRef.current?.click()}
                                                        className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 rounded-lg p-4 flex items-center gap-3 cursor-pointer hover:border-red-500 hover:bg-red-50/50 dark:hover:bg-red-500/5 transition-colors"
                                                    >
                                                        {formData.logoUrl ? (
                                                            <>
                                                                <img src={formData.logoUrl} alt="preview" className="w-12 h-12 rounded-md object-contain bg-zinc-100" />
                                                                <div className="flex-1 min-w-0">
                                                                    <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Logo carregada</p>
                                                                    <p className="text-xs text-zinc-400">Clique para trocar</p>
                                                                </div>
                                                                <button type="button" onClick={(e) => { e.stopPropagation(); setFormData(prev => ({ ...prev, logoUrl: "" })); }} className="text-zinc-400 hover:text-red-500">
                                                                    <X className="w-4 h-4" />
                                                                </button>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <div className="w-12 h-12 rounded-md bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center">
                                                                    <ImagePlus className="w-5 h-5 text-zinc-400" />
                                                                </div>
                                                                <div>
                                                                    <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">Enviar logo</p>

                                                                    <p className="text-xs text-zinc-400">PNG, JPG até 2MB. Clique para selecionar</p>
                                                                </div>
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                                <div className="space-y-1">
                                                    <Label>Cor Principal</Label>
                                                    <div className="flex gap-2">
                                                        <Input type="color" value={formData.secondaryColor || "#dc2626"} onChange={(e) => setFormData(old => ({ ...old, secondaryColor: e.target.value }))} className="w-12 h-10 p-1 cursor-pointer" />
                                                        <Input name="secondaryColor" value={formData.secondaryColor} onChange={handleChange} className="flex-1" />
                                                    </div>
                                                </div>
                                            </>
                                        )}

                                        {tenantType === "OFFICE" && (
                                            <>
                                                <div className="space-y-1">
                                                    <Label>Rua / Logradouro</Label>
                                                    <Input name="addressStreet" value={formData.addressStreet} onChange={handleChange} placeholder="Ex: Rua das Flores" />
                                                </div>
                                                <div className="grid grid-cols-2 gap-4">
                                                    <div className="space-y-1">
                                                        <Label>Número</Label>
                                                        <Input name="addressNumber" value={formData.addressNumber} onChange={handleChange} placeholder="Ex: 123" />
                                                    </div>
                                                    <div className="space-y-1">
                                                        <Label>Bairro</Label>
                                                        <Input name="addressNeighborhood" value={formData.addressNeighborhood} onChange={handleChange} placeholder="Ex: Centro" />
                                                    </div>
                                                </div>
                                                <div className="grid grid-cols-2 gap-4">
                                                    <div className="space-y-1">
                                                        <Label>CEP</Label>
                                                        <Input name="addressZipCode" value={formData.addressZipCode} onChange={handleChange} placeholder="Ex: 00000-000" />
                                                    </div>
                                                    <div className="space-y-1">
                                                        <Label>Cidade</Label>
                                                        <Input name="addressCity" value={formData.addressCity} onChange={handleChange} placeholder="Ex: São Paulo" />
                                                    </div>
                                                </div>
                                                <div className="space-y-1">
                                                    <Label>Estado (UF)</Label>
                                                    <Input name="addressState" value={formData.addressState} onChange={handleChange} placeholder="Ex: SP" />
                                                </div>
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>


                            {/* Coluna Direita: Responsável e Setup */}
                            <div className="space-y-6">
                                <div className="space-y-4">
                                    <h3 className="font-bold text-zinc-900 dark:text-white flex items-center gap-2"><Users className="w-4 h-4 text-red-500" /> Responsável Legal</h3>

                                    <div className="space-y-3">
                                        <div className="space-y-1">
                                            <Label>Nome Completo</Label>
                                            <Input name="respName" value={formData.respName} onChange={handleChange} placeholder="Nome do Responsável" />
                                        </div>
                                        <div className="space-y-1">
                                            <Label>CPF / CNPJ</Label>
                                            <Input name="respDocument" value={formData.respDocument} onChange={handleChange} placeholder="000.000.000-00" />
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="space-y-1">
                                                <Label>Telefone</Label>
                                                <Input name="respPhone" value={formData.respPhone} onChange={handleChange} placeholder="(00) 00000-0000" />
                                            </div>
                                            <div className="space-y-1">
                                                <Label>Email</Label>
                                                <Input name="respEmail" type="email" value={formData.respEmail} onChange={handleChange} placeholder="email@exemplo.com" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {!editingBand ? (
                                    <div className="space-y-4 pt-4 border-t border-zinc-200 dark:border-white/5 bg-red-500/5 p-4 rounded-xl border-dashed">
                                        <h3 className="font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                                            <Globe className="w-4 h-4 text-red-500" /> Configuração Inicial (Acesso e Banda)
                                        </h3>
                                        {tenantType === "OFFICE" && (
                                            <>
                                                <div className="space-y-1">
                                                    <Label>Nome da 1ª Banda</Label>
                                                    <Input name="firstBandName" value={formData.firstBandName} onChange={handleChange} placeholder="Banda Principal" />
                                                </div>
                                                <div className="space-y-1">
                                                    <Label>Logomarca da 1ª Banda</Label>
                                                    <input
                                                        type="file"
                                                        accept="image/*"
                                                        ref={firstBandLogoInputRef}
                                                        onChange={(e) => handleLogoUpload(e, "firstBandLogo")}
                                                        className="hidden"
                                                    />
                                                    <div
                                                        onClick={() => firstBandLogoInputRef.current?.click()}
                                                        className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 rounded-lg p-3 flex items-center gap-3 cursor-pointer hover:border-red-500 hover:bg-red-50/50 dark:hover:bg-red-500/5 transition-colors"
                                                    >
                                                        {formData.firstBandLogo ? (
                                                            <>
                                                                <img src={formData.firstBandLogo} alt="preview" className="w-10 h-10 rounded-md object-contain bg-zinc-100" />
                                                                <div className="flex-1 min-w-0">
                                                                    <p className="text-sm text-zinc-700 dark:text-zinc-300">Logo carregada</p>
                                                                    <p className="text-xs text-zinc-400">Clique para trocar</p>
                                                                </div>
                                                                <button type="button" onClick={(e) => { e.stopPropagation(); setFormData(prev => ({ ...prev, firstBandLogo: "" })); }} className="text-zinc-400 hover:text-red-500">
                                                                    <X className="w-4 h-4" />
                                                                </button>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <div className="w-10 h-10 rounded-md bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center">
                                                                    <ImagePlus className="w-4 h-4 text-zinc-400" />
                                                                </div>
                                                                <p className="text-sm text-zinc-500">PNG, JPG até 2MB</p>
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                            </>
                                        )}
                                        <p className="text-xs text-zinc-500 mt-2">
                                            Será criada uma conta de admin com a senha padrão <strong>"123456"</strong>. Ele deverá alterar no primeiro acesso.
                                        </p>
                                        <div className="space-y-1 mt-2">
                                            <Label>E-mail {tenantType === "OFFICE" ? "do Admin Geral do Escritório" : "do Administrador da Banda"}</Label>
                                            <Input name="adminEmail" type="email" value={formData.adminEmail} onChange={handleChange} placeholder="admin@dominio.com" />
                                        </div>

                                        <Button onClick={handleCreate} disabled={saving || !formData.name || !formData.slug || !formData.adminEmail || (tenantType === "OFFICE" && !formData.firstBandName)} className="w-full mt-4 bg-red-600 hover:bg-red-700 shadow-md shadow-red-600/20">
                                            {saving ? "Contratando..." : `Cadastrar ${tenantType === "OFFICE" ? "Escritório e Banda Base" : "Banda"}`}
                                        </Button>
                                    </div>
                                ) : (
                                    <div className="space-y-4 pt-10 border-t border-zinc-200 dark:border-white/5 mt-4">
                                        <Button onClick={handleUpdate} disabled={saving || !formData.name || !formData.slug} className="w-full bg-red-600 hover:bg-red-700 text-white font-bold h-12 shadow-md shadow-red-600/20">
                                            {saving ? "Salvando..." : "Salvar Alterações"}
                                        </Button>

                                        <div className="pt-6 mt-6 border-t border-zinc-200 dark:border-white/5">
                                            <h4 className="text-sm font-bold text-red-500 mb-2 uppercase tracking-wider">Zona de Perigo</h4>
                                            <Button
                                                variant="outline"
                                                onClick={() => handleReset(editingBand.id, editingBand.name)}
                                                className="w-full border-red-200 dark:border-red-900/30 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 hover:text-red-600"
                                            >
                                                <RotateCcw className="w-4 h-4 mr-2" />
                                                Resetar Dados da Banda (Limpar tudo)
                                            </Button>
                                            <p className="text-[10px] text-zinc-500 mt-2 text-center">
                                                Isso apagará todas as músicas, shows, documentos e financeiro desta banda.
                                            </p>
                                        </div>

                                        <Button variant="ghost" onClick={closeForm} className="w-full h-10 mt-4">
                                            Cancelar
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {!isCreating && (
                <div className="bg-white dark:bg-zinc-900/50 rounded-xl border border-zinc-200 dark:border-white/5 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <thead className="bg-zinc-50 dark:bg-zinc-900/50 text-zinc-500 border-b border-zinc-200 dark:border-white/5 uppercase text-xs tracking-wider font-semibold">
                                <tr>
                                    <th className="px-6 py-4">Instância</th>
                                    <th className="px-6 py-4">URL (Slug)</th>
                                    <th className="px-6 py-4">Tipo</th>
                                    <th className="px-6 py-4">Responsável</th>
                                    <th className="px-6 py-4 text-right">Ações</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-zinc-200 dark:divide-white/5">
                                {filteredBands.length === 0 ? (
                                    <tr>
                                        <td colSpan={5} className="px-6 py-8 text-center text-zinc-500">
                                            Nenhuma instância encontrada.
                                        </td>
                                    </tr>
                                ) : (
                                    filteredBands.map((band) => {
                                        const type = band.type || "BANDA";
                                        return (
                                            <tr key={band.id} className="hover:bg-zinc-50 dark:hover:bg-white/[0.02] transition-colors">
                                                <td className="px-6 py-4">
                                                    <div className="flex items-center gap-3">
                                                        {band.imageUrl ? (
                                                            <img src={band.imageUrl} alt={band.name} className="w-8 h-8 rounded-md object-cover" />
                                                        ) : (
                                                            <div
                                                                className="w-8 h-8 rounded-md flex items-center justify-center text-white font-bold"
                                                                style={{ backgroundColor: band.primaryColor || (type === "OFFICE" ? "#3b82f6" : "#dc2626") }}
                                                            >
                                                                {band.name.charAt(0)}
                                                            </div>
                                                        )}
                                                        <div className="font-medium text-zinc-900 dark:text-zinc-100">{band.name}</div>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 text-zinc-500">/{band.slug}</td>
                                                <td className="px-6 py-4">
                                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${type === "OFFICE" ? "bg-blue-500/10 text-blue-500" : "bg-red-500/10 text-red-500"}`}>
                                                        {type === "OFFICE" ? "Escritório" : "Banda"}
                                                    </span>
                                                </td>
                                                <td className="px-6 py-4">
                                                    <div className="font-medium text-zinc-900 dark:text-zinc-100">{band.respName || "-"}</div>
                                                    <div className="text-xs text-zinc-500">{band.respEmail || "-"}</div>
                                                </td>
                                                <td className="px-6 py-4 text-right">
                                                    <div className="flex justify-end gap-2">
                                                        <Button variant="ghost" size="sm" onClick={async () => {
                                                            const result = await impersonateTenant(band.id);
                                                            if (result.success) {
                                                                window.location.href = "/dashboard";
                                                            } else {
                                                                toast.error(result.error || "Erro ao acessar o sistema da banda.");
                                                            }
                                                        }} className="text-zinc-900 dark:text-zinc-100 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-500/10 px-2" title="Acessar Sistema da Banda">
                                                            <Globe className="w-4 h-4" />
                                                        </Button>

                                                        <Button variant="ghost" size="sm" onClick={() => openEdit(band)} className="text-zinc-900 dark:text-zinc-100 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10 px-2" title="Editar Instância">
                                                            <Edit className="w-4 h-4" />
                                                        </Button>
                                                        <Button variant="ghost" size="sm" onClick={() => handleReset(band.id, band.name)} className="text-zinc-900 dark:text-zinc-100 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-500/10 px-2" title="Resetar Dados (Limpar Conta)">
                                                            <RotateCcw className="w-4 h-4" />
                                                        </Button>
                                                        <Button variant="ghost" size="sm" onClick={() => handleDelete(band.id, band.name)} className="text-zinc-900 dark:text-zinc-100 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10 px-2" title="Excluir Definitivamente">
                                                            <Trash2 className="w-4 h-4" />
                                                        </Button>
                                                    </div>
                                                </td>
                                            </tr>
                                        )
                                    })
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}
